# BarcerlonaDO #

## Derechos y obligaciones en Barcelona ##

Recopilación de información y sus enlaces, a proyectos, organismos y datos relacionados con campañas de sensibilización ciudadana, dirigidas por el ayuntamiento de Barcelona u otros organismos vinculados al desarrollo digital.

***************
- _Mapa ciudadano_.
***************

_Noticias Jur'idiccas_
- Nueva ley de protección de datos.

_Derechos_
- Firma digital.
- Certificados de claves digitales.
- CityOS.
- Ecosistema de dades obertes de la ciutat.
- Oficina de análisis.


_Obligaciones_
- Impuestos sobre empresas digitales.
- Términos y privacidad(documentos digitales).



<ul id="firma">
	<li><i>por</i> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
