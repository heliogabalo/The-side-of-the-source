#### BIOS
#### UEFI --- Unified Extensible Firmware Interface
#### GUID --- Globally Unique Identifier
#### GPT --- GUID Partition Table
#### EEPROM --- Electrically Erasable Programmable Read Only Memory
#### ESP --- EFI System Partition