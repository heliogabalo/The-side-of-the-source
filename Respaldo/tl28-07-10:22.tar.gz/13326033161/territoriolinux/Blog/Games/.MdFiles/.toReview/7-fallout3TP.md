23/02/15

Aquí empieza el módulo, The Pitt. La segunda expansión de Fallout 3, que fue lanzada al mercado, el 24 de marzo del 2009. En esta nueva entrga, podremos disfrutar de nuevas y apasionantes aventuras, al más puro estilo Fallout.
Contenido

 [ocultar] 

    1 Encuentra el origen de las transmisiones de radio
    2 Hazte con un atuendo de esclavo
    3 Reúnete con Wernher.
    4 Viaja a la Fosa

Encuentra el origen de las transmisiones de radio

Empizan las misiones cuando hablamos por primera vez con Wernher. Nos explica el origen de la Fosa. Un lugar horrible lleno de esclavistas y de esclavos.

Al parecer el origen de la ciudad es algo turvio, -en más de un sentido- sin embargo, Wernher nos cuenta que tras la guerra mundial, Pittsburgh, Pennsylvania, se convirtió en un lugar desolado, mugriento y donde los pocos habitantes que sobrevivieros a las bombas, sufrieron todo tipo de enfermedades letales.

240px-Deserted Shack

Nada más hablar con Wernher, solicita nuestra ayuda, para conseguir liberar a los esclavos, su gente. El jefe se los esclavistas, un tal Ashur, posee una especie de cura, que deberemos robar, para dársela a losesclavos enfermos.

&lt;&lt; Se trata de una especie de remedio, que purificará el agua  contaminada por la radiación, algo parecido a lo que ya hicimos en Yermo Capital, REVISAR &gt;&gt;


Hazte con un atuendo de esclavo

Lo primero que deberemos hacer tras encontrarnos con Wernher, será localizar la vieja y destartalada estación de ferrocarril, que nos abrirá paso hasta "La Fosa". Ésto, no supone ningún problema, pués aparece claramente señalado el punto, en nuestro PipBoy.

Una vez allí, y siguiendo los consejos de Wernher, debemos conseguir un disfraz de esclavo. Lo cuál podremos hacer de dos modos distintos:

    Si hablamos con el jefe de los negreros, nos pedirá 600 chapas por los tres esclavos que tiene bajo llave, en una jaula.

    Aunque lo más rentable, será terminar rápidamente con el problema, deshaciéndonos de esos indeseables.

Uno se de ellos tiene la llave de la jaula, donde están presos los esclavos.

Si optamos por pagar tal dineral, deberemos apañárnoslas para abrir una cerradura de nivel "muy difícil", o robar la llave...

Al liberar a los esclavos presos en la jaula, uno de ellos mantiene una pequeña conversación con nosotros. Da las gracias por su liberación y nos indica que las ropas de uno de ellos, están disponibles en el cuerpo de un esclavo, muerto la noche anterior.



Pitt Marco

Wte subAdded by Wte sub

Reúnete con Wernher.

Seguidamente los esclavos salen huyendo a toda prisa, dejando la jaula llena de aire, y de pedazos de carne muerta y en descomposición.

Más adelante podrán encontrarse más atuendos de esclavo, aunque para poder subirnos a la vagoneta que nos conducirá a La Fosa, será necesario hacernos con el vestuario del cadaver.

Dirigiéndonos a la estación de ferrocarril, descubrimos que Wernher está ya dentro, esperándonos para comenzar el viaje. También nos advierte que cojamos todo aquello que necesitemos antes de proseguir con la aventura. Aunque de poco nos servirá, hacer acopio de munición y armas, pués al llegar a la entrada de la ciudad, el guarda vaciará por completo nuestra mochila, depositando el ajuar, en una caja fuerte,cerrada a calicanto.


64px-Into the Pitt
Viaja a la Fosa

Subimos a la vagoneta, que nos lleva directos al otro lado. Deberemos sortear un puente, completamente minado. Es recomendable no deshacernos de nuestras armas todvía, ya que encontraremos algo de resistencia, antes de cruzar el puente.

Si conseguis no pisar ninguna mina, ni hacer saltar en pedazos el maldito puente, llegaréis a la entrada de La Fosa. Al acercarnos, comprobaremos que algún esclavo menos cauto, salta en pedazos al eludir una mina.

El guarda de la entrada queda realmente impresionado con nuestros pertrechos y, sin dudarlo, abre y cierra la caja fuerte; en un abrir y cerrar de ojos.


 Con esto termina la misión En la Fosa. Ciento cincuenta puntos de experiencia y un trofeo "En la Fosa".

http://jugonespuntocom.blogspot.com.es/
