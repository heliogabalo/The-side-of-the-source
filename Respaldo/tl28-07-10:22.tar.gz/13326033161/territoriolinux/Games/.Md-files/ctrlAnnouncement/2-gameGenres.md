
>> hay que implementar los _badges_ de _bootstrap_


    1 Action
        1.1 Platform games
     [x]1.2 Shooter games
        1.3 Fighting games and beat 'em ups
        1.4 Stealth game
        1.5 Survival games
        1.6 Rhythm games
 [x]2 Action-adventure
        2.1 Survival horror
        2.2 Metroidvania
    3 Adventure
        3.1 Text adventures
        3.2 Graphic adventures
        3.3 Visual novels
        3.4 Interactive movie
        3.5 Real-time 3D adventures
    4 Role-playing
        4.1 Action RPG
        4.2 MMORPG
        4.3 Roguelikes
        4.4 Tactical RPG
        4.5 Sandbox RPG
        4.6 First-person party-based RPG
        4.7 Cultural differences
        4.8 Choices
        4.9 Fantasy
    5 Simulation
        5.1 Construction and management simulation
        5.2 Life simulation
        5.3 Vehicle simulation
 [x]6 Strategy
        6.1 4X game
        6.2 Artillery game
        6.3 Real-time strategy (RTS)
        6.4 Real-time tactics (RTT)
        6.5 Multiplayer online battle arena (MOBA)
        6.6 Tower defense
        6.7 Turn-based strategy (TBS)
        6.8 Turn-based tactics (TBT)
        6.9 Wargame
        6.10 Grand strategy wargame
    7 Sports
        7.1 Racing
        7.2 Sports game
        7.3 Competitive
        7.4 Sports-based fighting
    8 Other notable genres
        8.1 MMO
        8.2 Casual game
        8.3 Party game
        8.4 Programming game
        8.5 Logic game
        8.6 Trivia game
        8.7 Board game / Card game
    9 Idle gaming
    10 Video game genres by purpose
        10.1 Advergame
        10.2 Art game
        10.3 Casual game
        10.4 Christian game[banned porn games!! not allowed]
        10.5 Educational game
        10.6 Electronic sports
        10.7 Exergame
        10.8 Serious game
    11 Scientific studies
    12 See also
        12.1 Game interfaces
        12.2 Game platforms
        12.3 Other related topics
    13 Notes
    14 References
    15 Bibliography

