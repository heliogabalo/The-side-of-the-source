[Tabla de contenidos](#iT)
[Introducción](#i1)
[Cómo construir módulos externos](#i2)
[Sintaxis de comandos](#i2i1)
[Opciones](#i2i2)
[Objetivos](#2i3)




[Referencias y agradecimientos](#i99)

---

## Construcción de módulos externos ##

Este documento describe como construir módulos del kernel, de forma externa

### [Tabla de contenidos](#i1) ###

1. Introducción
2. Cómo construir módulos externos
		2.1 Sintaxis de comandos
		2.2 Opciones
		2.3 Objetivos
		2.4 Construiccón de archivos separados
3. Crear un archivo `Kbuild` para un módulo externo
		3.1 `Makefile` compartido
		3.2 Archivos `Kbuild` y `Makefile` separados.
		3.3 Blobs[f1](#f1) binarios
		3.4 Construcción de múltiples módulos
4. Archivos `include`s
		4.1 Kernel `include`s
		4.2 Un único subdirectorio
		4.3 Distintos subdirectorio
5. Instalación de módulos
		5.1 `INSTALL_MOD_PATH`
		5.2 `INSTALL_MOD_DIR`
6. Versionando módulos
		6.1 Símbolos desde el kernel (_vmlinux_ + módulos)
		6.2 Símbolos	y módulos externos
		6.3 Símbolos desde un módulo externo
7. Truco o trato
		7.1 Prueba `CONFIG_FOO_BAR`


### [Introducción](i1) ###

_Kbuild_ es el sistema de construcción utilizado por el kernel de Linux. Los módulos deben usar 
_Kbuild_ a efectos de compatibilidad, con sucesivos cambios en la infraestructura del mismo y, aportar las opciones adecuadas al compilador -`gcc`. Funcionalmente, en el momento de construir los módulos, tanto dentro como fuera del árbol, deberá estar presente. 

El método de construcción es similar en ambos casos. Todos los módulos son desarrollados y construidos inicialmente, _fuera del árbol_.

La información cubierta por este documento, está destinada a desarrolladores que trabajen en la construción de módulos, _externos_. El autor de un módulo externo, debería aportar un `makefile` que oculte su complejidad. Tan sólo escribiendo `make`, será construido el módulo.
Esto se consigue facilmente; será presentado un ejemplo en la sección 3.


### [Cómo construir módulos externos](#i2) ###

Para la construcción de módulos externos, es necesarios disponer de un _kernel_ anterior, conteniendo los archivos de cabecera y configuración utilizados en la misma.
Igualmente, el kernel deberá haber sido construido con tal capacidad: <kbd>módulos activos</kbd> -enabled modules. Si es utilizada una distribución del núcleo, habrá un paquete para el kernel utilizado, provisto por la distribución en uso.

Una alternativa es el empleo de `make <target> modules_prepare`, garantizando que el kernel contendrá la información requerida. El `<target>` existe únicamente, con la intención de preparar la _fuente_ del kernel, para la construcción de módulos externos.

> __Nota__: `modules_prepare`, no construirá `Module.symvers` incluso si `CONFIG_MODVERSIONS` fué establecido; es más, será necesaria una construcción completa del kernel para conseguir que el _versionado_ del módulo funcione.


### [Sintaxis de comandos](#i2i1) ###

El comando para la construcción de un módulo externo es:

		$ make -C <path_to_kernel_src> M=$PWD

El sistema _kbuild_ reconoce que está siendo construido un módulo, puesto que la opción `M=<dir>`, así lo indica.

Utilizar lo siguiente, sobre un kernel en uso:

		$ make -C /lib/modules/`uname -r`/build M=$PWD

Instalar entonces, el módulo recién construido y, añadir el _objetivo_ `modules_install` a la líne de comandos:

		$ make -C /lib/modules/`uname -r`/build M=$PWD modules_install
		
		
### [Opciones](#i2i2) ###

> `$KDIR` hace referencia a la ruta, fuente del kernel.
		
		make -C $KDIR M=$PWD		
		
		-C $KDIR
- El directorio donde es localizada la fuente del kernel.
`make` apuntará hacia el directorio especificado, regresando, al terminar.
		
		M=$PWD
- Informa a _kbuild_, que un módulo externo está siendo construido.
El valor de `M`, denota la ruta hacia el direcotorio, donde es localizado el módulo externo -el archivo _kbuild_.
		
		
### [Objetivos](#2i3) ###

Al construir un módulo externo, sólo un subconjunto de objetivos en el `make`, estarán disponibles.
		
		make -C $KDIR M=$PWD [target]
- 


### [Referencias y agradecimientos](i99) ###

[f1](f1) __blobs__: son una especie de archivos "condensados/pequeños"!!!!!!! [cita requerida]


<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
