[Montando el sistema de ficheros raíz, vía NFS(nfsroot)](#i1)
[Activando las capacidades de NFS](#i1i1)
[Línea de comando del kernel](#i1i2)

[Referencias y agradecimientos](#i99)


### [Montando el sistema de ficheros raíz, vía NFS(nfsroot)](i99) ###

Con objeto de utilizar un sistema sin disco de arranque -diskless system, como una _terminal para las X_, o un servidor de impresoras -por ejemplo, es necesario que el sistema de ficheros raíz, esté presente en un dispositivo "zero-disco". Podría tratarse de _initramfs_ -ver [rams-rootfs-initramfs.html](/TerritorioLinux/kernel/SistemaFicheros/rams-rootfs-initramfs.html), un [disco ram](/TerritorioLinux/SO/Boot/GestorDeArranque/initrd.html), o un FS montado vía NFS. El siguiente texto, describe cómo usar NFS en un FS raíz. En adelante, el término "cliente" significa: _sistema sin disco de arranque_ y, "server" significa: _NFS server_.

### [Activando las capacidades de NFS](i1i1) ###

Para utilizar _nfsroot_, debe ser activada la característica <kbd>NFS client support</kbd> durante la configuración del kernel. Una vez hecho esto, la opción <kbd>nfsroot</kbd> aparecerá disponible, para ser selecionada después.

Dentro de las opciones de red, podrá selecionarse el nivel de _autoconfiguración_ del kernel, junto al el tipo de soporte para la _autoconfiguración_. Es seguro activar todo en DHCP, BOOTP y RARP.


### [Línea de comando del kernel](#i1i2) ###

Una vez el kernel haya sido cargado por el gestor de arranque -ver abajo, _debe decirse_, qué FS raíz usar. En el caso de _nfsroot_, dónde encontrar al _servidor_ y el nombre del directorio utilizado para el montaje del raíz (`/`).
Esto puede concretarse mediante el siguiente parámetro para la línea de comandos:

		root=/dev/nfs

Es esto necesario para activar el _pseudo-dispositivo_ NFS. Nótese que no se trata de un dispositivo real, sino de un sinónimo para _decir al kernel_ el usar NFS, en lugar de dispositivo real.

		nfsroot=[<server-ip>:]<root-dir>[,<nfs-options>]

			If the `nfsroot' parameter is NOT given on the command line,
			the default "/tftpboot/%s" will be usad.

			<server-ip>	Specifies the IP address of the NFS server.
				The default address is determined by the `ip' parameter
				(see below). This parameter allows the usa of different
				servers for IP autoconfiguration and NFS.

			<root-dir>	Name of the directory on the server to mount as root.
				If there is a "%s" token in the string, it will be
				replaced by the ASCII-representation of the client's
				IP address.

			<nfs-options>	Standard NFS options. All options are separated by commas.
				The following defaults are usad:
					port		= as given by server portmap daemon
					rsize		= 4096
					wsize		= 4096
					timeo		= 7
					retrans		= 3
					acregmin	= 3
					acregmax	= 60
					acdirmin	= 30
					acdirmax	= 60
					flags		= hard, nointr, noposix, cto, ac


		ip=<client-ip>:<server-ip>:<gw-ip>:<netmask>:<hostname>:<device>:<autoconf>:
			 <dns0-ip>:<dns1-ip>:<ntp0-ip>

El parámetro indica al kernel cómo configurar la dirección IP del dispositivo. También cómo configurar la IP de la_tabla de ruta_. Fué originalmente llamada _nfsaddrs_, pero ahora, la configuración la IP durante el arranque, funciona de manera independiente de NFS, por lo que cambió su nombre por "ip" y, el anterior nombre permanece como alias por razones de compatibilidad.

Si es omitido este parámetro, desde la línea de comandos del kernel, todos los campos serán asumidos como vacíos y serán aplicados los valores por defecto, más abajo. En general, significa que el kernel intentará configurar todo, utilizando la autoconfiguración.

El parámetro `<autoconf>`, puede aparecer sólo, como valor del parámetro `ip` -sin los carácteres `:` antes. Si el valor es `ip=off` o `ip=none`, la autoconfiguración no tomará lugar, al contrario si lo hará. La forma habitual de utilizarlo es `ip=dhcp`.

`<client-ip>` 	IP address of the client.

> Por defecto: determinado utilizando la autoconfiguración.

`<server-ip>` Dirección IP del servidor NFS. Si es utilizado RARP para determinar la dirección del cliente y, este parámetro __no__ está vacío, sólo las respuestas desde el servidor especificado, serán aceptadas.

Únicamente es requerido por _la raíz NFS_ . Ésta autoconfiguración no será disparada si está omitida y, _la raíz NFS_ no estuviese operando.

El valor es exportado a `/proc/net/pnp` con el prefijo "bootserver". Ver más abajo.

Por defecto(Default): determinado mediante la autoconfiguración.
> quitar el guión
- Será utilizada la dirección de la autoconfiguración del servidor.

`<gw-ip>` Dirección IP de la puerta de enlace -gatewawy, si el servidor se encuentra en una _subnet_ distinta.

> Por defecto: determinado utilizando la autoconfiguración.

`<netmask>` máscara de red, para la interfase de red local. Si no está especificada, la máscara será derivada desde la dirección IP del _cliente_, asumiendo el direccionamiento de clase? -classfull addressing.

> Por defecto: determinado utilizando la autoconfiguración.

`<hostname>` Nombre del cliente. Estando presente un `.` -punto, cualquier cosa delante del mismo, será utilizado como el nombre de máquina del cliente y, la _cadena_ tras el punto, utilizado como su nombre de dominio NIS. Podría ser proporcionado mediante la autoconfiguración, pero su ausancia no _disparará_ la autoconfiguración.
De estar especificado y el DHCP en uso, el nombre de máquina provisto por el usuario -y nombre de dominio, será _enlazado_ a una solicitud DHCP; acarreando la creación o actualización de un registro DNS, para el cliente.

> ejemplo(fqdn/full qualified domain name): 
		https							fedoraproject  .  org
			|													|									|
		protocolo				maquina			dominio

> Por defecto: determinado utilizando la autoconfiguración.

`<device>` Nombre del dispositivo de red a utilizar.

Por defecto: si el _host_ sólo consta de un dispositivo, éste será utilizado.
De cualquier otro modo, el dispositivo será determinado mediante la autoconfiguración. 
Realizado mediante el envío de la petición de autoconfiguración de todos los dipositivos y, utilizando aquel que primero reciba la respuesta.

`<autoconf>` Método de uso, para la autoconfiguración. En caso de opciones que especifiquen múltiples protocolos de autoconfiguración, las peticiones serán enviadas utilizando todos los protocolos y, usado el primero en responder.

Serán utilizados aquellos protocolos que hayan sido compilados junto al kernel, independientemente del valor de la opción.

`off` o `none` apagado/ninguno. No utilizar la autoconfiguración -en su lugar determina una asignación estática de la IP. 

`on` o `any` encendido/cualquiera. Utilizar cualquier protocolo disponible en el kernel.

				(default)
		dhcp:       usa DHCP
		bootp:      usa BOOTP
		rarp:        usa RARP
		both: 			 usa ambos, BOOT y RARP, pero no DHCP
									 (opición obsoleta, mantenida por compatibilidad)

Si es utilizado el DHCP, podrá emplearse el identificador de cliente con el siguiente formato:
`ip=dhcp,client-id-type,client-id-value`.

		Default: any

`<dns0-ip>` Dirección IP del servidor de nombres primario.
Su valor será exportado a `/proc/net/pnp` con prefijo `nameserver`
Ver más abajo.

Por defecto: Ninguno, si no es utilizada la autoconfiguración; determinado automáticamente si es utilizada.

`<dns1-ip>` Dirección IP del servidor de nombres secundario.
Ver `<dns0-ip>`

<ntp0-ip> dirección IP para servidor del protocolo de red de tiempo -NTP Network Time Protocol. Su valor es exportado a `/proc/net/ipconfig/ntp_servers`, de otra forma no será usado. Ver abajo.

Por defecto: Ninguno, si no es utilizada la autoconfiguración; determinado automáticamente si es utilizada.

Después de que la configuración -tanto manual como guiada, sea completada, serán creados dos archivos con el siguiente formato; serán omitidas las líneas, de aquellos valores vacios:

`/proc/net/pnp`:

		#PROTO: <DHCP|BOOTP|RARP|MANUAL>	(depending on configuration method)
		domain <dns-domain>			(if autoconfigured, the DNS domain)
		nameserver <dns0-ip>			(primary name server IP)
		nameserver <dns1-ip>			(secondary name server IP)
		nameserver <dns2-ip>			(tertiary name server IP)
		bootserver <server-ip>			(NFS server IP)

		- /proc/net/ipconfig/ntp_servers:

		<ntp0-ip>				(NTP server IP)
		<ntp1-ip>				(NTP server IP)
		<ntp2-ip>				(NTP server IP)





### [Referencias y agradecimientos](i99) ###

Written 1996 by Gero Kuhlmann <gero@gkminix.han.de>
Updated 1997 by Martin Mares <mj@atrey.karlin.mff.cuni.cz>
Updated 2006 by Nico Schottelius <nico-kernel-nfsroot@schottelius.org>
Updated 2006 by Horms <horms@verge.net.au>
Updated 2018 by Chris Novakovic <chris@chrisn.me.uk>







<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
