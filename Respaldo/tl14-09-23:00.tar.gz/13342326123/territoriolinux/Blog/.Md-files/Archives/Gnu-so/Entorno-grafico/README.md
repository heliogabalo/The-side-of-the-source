## Indice

1. Referencias documentación
	- Http

---

#### 1. Referencias documentación
[libreport-gtk](https://abrt.readthedocs.org)
