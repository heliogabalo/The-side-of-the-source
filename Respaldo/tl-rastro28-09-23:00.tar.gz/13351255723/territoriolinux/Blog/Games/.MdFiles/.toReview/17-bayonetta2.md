bayonetta 2


Los desarrolladores de PlatinumGames, vienen acumulando éxitos desde hace ya varios años. Con títulos como MetalGear: Rising, en colaboración con Konami. Vanquish o la saga Bayonetta, aportan diversidad y "frescura", al medio.


El ritmo frenético, mantiene constante la acción, donde los tiempos de carga son nulos o prácticamente inexistentes, -con la salvedad de los necesarios, entre nivel y nivel.

Los eventos rápidos de tiempo (o quick time events) se suceden con mucha naturalidad y dinamismo, aportando fluidez a la mecánica natural del videojuego.


En la anterior entrega de este mismo juego, Bayonetta, el contraste resultaba bastante mas apagado y oscuro. Dificultad que parecen haber resuelto, con mucha eficacia.

En bayonetta 2, el contraste de colores es verdaderamente más brillante y variado, ayudando a obtener mayor colorido tanto en personajes como en la interfase de usuario(UI).



Otro rasgo peculiar son los detalles picarones, o subidos de tono. Introducidos en los eventos rápidos, con buen gusto, y sin que esto llegue a resultar ofensivo para nadie.

El apartado artístico, por así decirlo, es realmente sorprendente. Unos gráficos muy elaborados, llenos de color e imaginación.


La dificultad es apropiada, asequible. Esto es también un rasgo favorable del juego, ya que no hay que olvidar, que la interacción entre el jugador y la máquina, se realiza a través de un dispositivo portable,  que es la Wii U. Igualmente, el control de personaje es fácilmente configurable, entre el panel táctil y el mando habitual de botones.



Debo confesar que el rosa no es mi color predilecto. Es cierto que también es un color y que para muchas personas si lo és. Su color.

Sin embarbo, la idea de embutirme en unas mayas ajustadas, constriñendo unas nalgas vigorosamente pobladas, es cuanto menos, una idea perturbadora. Es quizás la crítica al rosa, el punto negativo que inevitablemente debíamos mencionar.






                                                              Amazon                       Amazon

                                                        Bayoneta 1 y 2            Bayonetta 2










plataforma: Wii U


EscenarioDeJuego
