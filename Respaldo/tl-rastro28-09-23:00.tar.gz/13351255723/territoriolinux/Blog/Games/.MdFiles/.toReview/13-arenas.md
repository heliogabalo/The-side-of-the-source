08/10/13

 Arenas son áreas en las que equipos de jugadores, pueden competir unos contra otros, en combate a muerte. En






Ice
 este tipo de desafios, el objetivo principal, consiste en eliminar al equipo contrario. Por lo que cada facción, debe centrar sus esfuerzos en consolidar un equipo fuerte, que sea capaz de hacer frente al enemigo. Es decir, el juego en equipo es un factor determinante a la hora de ganar o perder el desafio. Esta modalidad de combate, está basada más en el trabajo conjunto que en la consecución de objetivos.


El sistema PvP (jugador contra jugador), empareja equipos de igual tamaño y nivel. Logrando que las facciones enfrentadas, mantengan un nivel equiparable.

La Arena permite emparejamientos de 2c2, 3c3 y 5 contra 5.

Un equipo puede llegar a tener hasta el doble de la cantidad requerida, por ejemplo, así, un equipo de 2c2 puede llegar a tener hasta 4 personajes en el mismo bando. A diferencia delPvP normal, la modalidad de combates en Arena, permite la competición entre personajes de una misma facción. Sólamente personajes de nivel 85, - el máximo nivel- pueden clasificarse para los combates en Arena. Los personajes por debajo de este nivel, también puede participar, aunque en combates de práctica.Para poder participar, los equipos deben adquirir el“Estatuto de arena” de 2, 3 o 5 jugadores y, conseguir las firmas suficientes para validarlo. Los puntos de Arena se utilizan como moneda, para adquirir recompensas de Arena. Estasrecompensas son similares a otras recompensas conseguidas en PvE(medio/alto nivel).Las recompensas están divididas en rangos o niveles de recompensa, de igual forma que se agrupan a los personajes. Por ejemplo, un personaje ente los niveles 19-27, estará considerado dentro del rango 2.


As of Cataclysm

Tier
	

Talent Points
	

Level Required

1
	

1-5
	

10, 11, 13, 15, 17

2
	

6-10
	

19, 21, 23, 25, 27

3
	

11-15
	

29, 31, 33, 35, 37

4
	

16-20
	

39, 41, 43, 45, 47

5
	

21-25
	

49, 51, 53, 55, 57

6
	

26-30
	

59, 61, 63, 65, 67

7
	

31
	

69

Hay muchas y diferentes recompensas, repartidas en diferentes zonas y desafíos. Puede que un personaje NPC (personaje no jugador), administre una recompensa exclusiva, que solamente podrá obtenerse, consiguiendo el desafio que propone. Así que sal ahí fuera, y explora las diferentes zonas, en busca de tu recompensa.

Actualmente hay cinco Arenas disponibles:

    El círculo del Valor en Ogrimar.
    Las Ruinas de Lordaeron en Claros de Tisfal, publicado en el parche v2.1.
    El círculos de los Retos en Nagrand. 
    El círculo de Sangreen Montañas Filosas. 
    La Arena de Dalaran en el vajovientre de Dalaran. 


Contenido

 [ocultar] 

    1 En el Parche 5.4
    2 Objetivo
    3 Tipos
        3.1 Añadida por Mat7Tipo 1 – Escaramuzas
        3.2 Tipo 2- Combate por emparejamiento.
    4 Creación de un equipo
        4.1 Equipo de Arena
    5 Limitaciones
    6 Juego en equipo
        6.1 Antes del combate

En el Parche 5.4Editar sección
ObjetivoEditar sección

Artículo principal: Estrategia Arena PvP

Otros modos de PvP, etán más enfocados a tratar sobre objetivos o banderas, los cuáles hacen mayor énfasis en el apartado visual, que en hablar sobre estrategias de combate.

El principal objetivo en Arenas PvP, es simplemente, acabar con el enemigo, antes de que él acabe contigo. Por lo tanto, la sinergia entre clases es fundamental, y aún mas importantes, son la táctica de equipo y coordinación.


TiposEditar sección

Los jugadores pueden participar en la Arena de dos maneras. El tipo de batalla que haya sido seleccionado, se tratará en un tema aparte, Arena Battlemaster.


Highelvenarcher
Tipo 1 – EscaramuzasEditar sección

Los jugadores de cualquier nivel, podrán participar en las escaramuzas, sin necesidad de calificación de equipo, o puntos de Arena.

Así mismo, no será necesario pertenecer a ningún equipo de Arena para entrar a participar de las Escaramuzas.

Nota: Debido a las nuevas reglas de combate, introducidas en recientes parches como Cataclysm, el modo Escaramuza, ya no existe.

N. t. de t. : recursos.


Tipo 2- Combate por emparejamiento.Editar sección

Los jugadores de nivel 85 y un equipo de Arena -creado con una carta de Equipo de Arena-, podrán participar en partidas calificables.

Una vez terminada la partida, cada equipo obtendrá su propia puntación (ver detalles mas abajo. Cálculo de clasificación de equipo).


Creación de un equipoEditar sección
Equipo de ArenaEditar sección

A partir de la temporada 9 con Cataclysm, los equipos de arena pueden crearse fácilmente desde la ficha honor, en la hoja de personaje. Haciendo click en el cartel vacío, se abre un nuevo menú para la creación del equipo.

Debe seleccionarse entonces, el nombre del equipo y diseño de su bandera, a continuación, el botón crear, terminará el proceso.

Tras crear el equipo, puede seleccionarse la bandera en la ficha de Equipos de Arena para ver sus listas y estadísticas. También incluye un botón para agregar otro miembro al equipo.

El jugador invitado, debe estar en línea, en el momento de la invitación. Para crear el equipo su personaje debe estar entre los niveles 80-85.

Desde la temporada 6 (parche 3.1), los equipos recién formados, empiezan desde cero, en la tabla de puntuación. Para mejorar sus estadísticas, tendrán que luchar contra otros equipos. 

Antes del parche 3.1, al crear el Equipo de Arena, la tabla de puntos empezaba la clasificación en los 1500 puntos. 

Para disolver el equipo de Arena, debe escribir &lt;/teamquit_type&gt;, donde “type” es 2v2, 3v3 o 5v5.


LimitacionesEditar sección

No pueden utilizarse objetos de mejora temporal, como “Pergamino de la Fortitud” o [[“Tambores salvajes”]], sin






Pocion
 embargo objetos de equipotales como “Tarjeta Lunaoscura de la grandeza”, seguirán funcionando.

Las pociones, frascos y elixires, están prohibidos, a excepción de “Frasco del norte” y pociones específicas de Arena. Estas pócimas deberán adquirirse a través de los vendedores de honor.

Los explosivos del tipo “Granada congelante”, tampoco podrán usarse.

Otros calderos de ingeniería, tales como “Disco mental de ampliación” tampoco pueden usarse.

Cualquier habilidad con un tiempo de reutilización de 10 minutos o mayores, no pueden usarse.

Dentro de un Estadio no podrá cambiarse de especialización, pero podrán intercambiarseconjuntos de equipo.


Juego en equipoEditar sección
Antes del combateEditar sección

Al entrar en zona, alternativamente llamada Instancia de Arena, los jugadores entran en una especie de sala de espera. Donde su salud, maná y energía, serán restaurados. 

Todos los conjuros son eliminados y las mascotas guardadas. 

Los jugadores son preparados para entrar a luchar, otorgándose a todos los jugadores una mejora propia de la zona de Arena.

Tras sesenta segundos de preparación, el encuentro comienza. Todas las mejoras de menos de 25 segundos se quitan, y la ira/poder rúnico queda restablecido a 0.


La lucha.

Los jugadores se enfrentan hasta que todos los miembros de un equipo son derrotados, deciden abandonar, o transcurren 45 minutos.

Las habilidades con tiempo de reutilización de más de ocho minutos, no pueden utilizarse durante el combate en la Arena. 

Sólo pueden utilizarse determinadas pociones curativas de nivel ochenta y cinco (85), así como vendas y otros objetos similares. Lo cierto, es que hay varias limitaciones en cuanto al uso de consumibles.

Una vez que el jugador muere, puede optar por la liberación del espíritu, y observar el resto del encuentro como   fantasma. 


Después de la lucha

Igual que en los campos de batalla, después de completar un encuentro, aparece una ventana con las  estadísticas de arena. Daños totales, sanación, golpes mortíferos. Así como el resultado del combate.
