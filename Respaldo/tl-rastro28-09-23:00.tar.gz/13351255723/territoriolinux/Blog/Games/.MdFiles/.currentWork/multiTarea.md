https://en.wikipedia.org/wiki/Computer_multitasking
