Vocabulario:

  - strace: siguimiento de llamadas al sistema.
  - ltrace: siguimiento de llamadas a librerias, (binario compilado dinámicamente).
  - ptrace: seguimiento de llamadas a procesos.


