## Action Adventure Games - Febrero 2018

- gravity Rush 2(T)
  gravity Daze 2(japones)
- Agents of Mayhem(T)
- Yakuza 0 (G)
- Horizon: Zero Down (*)
- The Legend of Zelda: Breath
- Sea of Thieves
- sCumVm
- call of cthulhu
- A Way Out(T)
- fade to Silence
- Days Gone(T)
- Spiderman
- Death Stranding
- In the valley of gods (2019)
- Nier Automata
- Biomutant(q1-18)x-pc-p4
- Nioh(T)
- Prey (*)
- Super Mario Odyssey
- Red Dead Redemption 2 (*F)
- Crackdown 3



***************




| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Spiderman | Imsomniac G. | https://insomniac.games/ | n/d 18 | T-pre | email-contact | options | PS4 | 5-9 | 
| Agents of Mayhem| RAD Games Tools | http://www.aomthegame.com/ | ready| T | info@deepsilver.com | option | 8 |
| Nioh | Team Ninja |https://www.gamecity.ne.jp/nioh/outline.html | 071118 | T | mail | option | 8 |
| Yakuza 0 | sega | http://yakuza.sega.com/yakuza0/home.html| 240118 | G | mail | option | 8 |
| Red Dead Redemption 2 | Rock Star Games | https://www.rockstargames.com/reddeadredemption2/ | 261018 |pre G| mail | option | 8 |
| fade to Silence | balckForest G. | https://fadetosilence.com/ | fecha | anunciado | info@bfgames.biz | ec/dlc | 8 |
| A Way Out| EA games | https://www.ea.com/games/a-way-out | 23/03/18 | T | mail | 9 |
| Days Gone | Bend Studio | http://bendstudio.com/ | n/d | T | mail | ErlAcc/dlc | 9 |
| Death Stranding | Kojima P. | www.kojimaproductions.jp/en/ | n/d | anunciado | mail | ErlAcc/dlc | week nº |



---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |
| options -- earlyAccess/DLC |

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
*******************
## Fantsy Games - Febrero 2018

- Pine
- Rune: Ragnarok*(pre-T)
- Valnir Rok
- Exzore: Rising
- Midle Earth:Shadow o'War(*G)
- Ashes of Creation--FostosMalas
- Dark and Light
- Elex (T)
- Project Wight*
- Shadow of the colossus remake
- Babylon Project**
- GreedFall (T)
- Monster Hunter: World
- Vampyr (T*)
- Wild(T)	muy verde!
- Ealdorlight(T*)
- War of rights(T)
- Black Room

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Project Wight | The outsiders | http://theoutside.rs/ | n/d | T | mail | option | 8 |
| Elex| Piranha Bytes | https://elexgame.com/ | n/d | T | mail | option | 8 |
| Wild| WILD SHEEP STUDIO | http://wildsheepstudio.com/ | n/d| T | mail | option | 8 |
| Rune: Ragnarok| Human Head Studios | https://www.runeragnarok.com/media/| n/d | T | mail | option | 9 |






---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>

*******************
## First Person Shooter - Febrero 2018

- War of rights(T)
- Black Room
- Serious Sam	(G)
- Witchfire(T)
- Warhammer Vermintide 2
- Hell let Loose
- Deep rock Galactic(T)
- Scorn (T)
- Ready or not
- Atomic Heart II(T)
- GTFO (T)
- Hunt: Showdown
- Border Lands 3
- System Shock (**I-c) 
- Overkills the Walking Dead
- Escape from Tarkov
- Batalion 1944
- unannonuced Call of Duty -treyarch
- Metro Exodus*
- Far cry 5 (*T)
- Kingdom Come: Deliverance
- Witchfire
---

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| War of Rights | CampFire G. | https://warofrights.com/ | n/d | T-G | mail | ErlAcc/dlc | plataforma | 6-9 |
| Atomic Heart II| n/d |http://www.mundfish.com/#| n/d | T | partners@mundfish.com | option | 8 |
| Scorn | Ebb Software | https://scorn-game.com/pages/media | n/d | T | mail | option | 8 |
| Witchfire | The Astronauts | http://www.theastronauts.com/ | n/d | T | mail | option | 9 |
| Metro Exodus | 4A Games | http://www.metrothegame.com/ | 31/12/18 | T | mail | ErlAcc/dlc | 9 |







---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | plataforma |week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |

*******************
#### Simulation Games ####



-The crew 2
-- MX vs ATV all Out	(270319-ps4,x1,pc)




***************

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| The Crew 2 | Ivory Tower | https://thecrew-game.ubisoft.com/the-crew-2/en-GB/home/ | n/d | T | mail | ErlAcc | 9 |






---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
*******************
## Strategy Games - Febrero 2018

- ancestors (T)
- Jurasic World Evolution*(T)
- Surviving Mars(T)
- The Guild 3(T)
- Ancient Cities
- Anno 1800
- SpellForce 3(G)
- Iron Harvest 1920*
- Age of Empires
- Age of Empires IV*
  Definitive Edition
- Age of Mythology
- ancestorsS



| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
|	Ancestors Legacy	|	Destructive Creations	|	https://destructivecreations.pl/	| 220518 | T | info@destructivecreations.pl | option | 8 |
|	Surviving Mars | Haemimont G.	|	https://www.survivingmars.com/	| 150318 | T | mail | option | 8 |
| The Guild 3 | Golemlabs | https://theguildgame.com/#about-the-guild-3 | n/d | T | mail | option | 8 |
| SpellForce 3 | | https://spellforce.com/| n/d | G | bandera | mail | option | 8 |
| Jurasic World Evolutions | company | page | summer18 | anunciado | mail | option | 9 |
| Ancient Cities | UncasualGames | https://www.ancient-cities.com/ | n/d | T | mail | option | 9 |

---
| name | company | page | n/d | anunciado | mail | ec/dlc |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |

Jurasic World Evolutions
***************

## RPG ##

- kingdom come deliverance 






| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| kingdom come deliverance | WarHorse S. | https://www.kingdomcomerpg.com/ | DISPONIBLE | anunciado | mail | ec/dlc | ps4,x1 | week nº|


---
| name | company | page | n/d | anunciado | mail | ec/dlc | plataforma | week nº|

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |



***************

#### DISPONIBLE ####

- Dreams



***************
## Not Defined Games ##

- bloodborne 2 (FromSoftware's)NOTHING YET
- Battle Royale
- Extintion*
- The Last of Us
- God of War**
- Ghost of Tsushima
- Beyond Good & Eveil 2
- The crew 2(ps4,x1,pc)
- Assassin's Creed: Origins
- Skull and Bones(q4-18-ps4-xb1-pc)
- For Honor
- Crackdown 3
- Dragon B. FighterZ ps4(26/01/18)
- Detroit become Human(q1/q2/18)
- Agony(30-03-18) pc-p4-x
- Bloodstained: ritual of the night
- Monster Hunter: World(210108-ps4,x1,pc)
- Anthem*(ps4,x1,pc)
- The las Night- Death Stranding(ideo kohima?)
- Code Vein
- DarkSiders*!
- Attack on Titan 2(03-18)xb1-switch-pc-p4
- Shadow of Colossus(remake)060218-ps4
- Fist of North Star (18 ps4)
- Agony(ps4-xb1-pc-300318)
- Days Gone (ps4)
- Jurasi Worl Evolution
	(q2-18 ps4-xb1-pc)		
- Skull
- DEvil may cray HD C(pc,x1,ps4-130318)
- Pure Farming(130318-ps4,x1,pc)
- Golem(070318-ps4)
- Bravo Team(070318-ps4)
- Surviving Mars(150318)
- Kirby: Star Allies(160318-switch)
- Wild West Online(early18- pc)
- Far Cry 5 (270318-ps4,x1,pc)
- State of Decay(primavera18-ps4,x1,pc)
