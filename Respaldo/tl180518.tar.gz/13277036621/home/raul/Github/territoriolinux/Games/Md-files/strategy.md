
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
|	Ancestors Legacy	|	Destructive Creations	|	https://destructivecreations.pl/	| 220518 | T | info@destructivecreations.pl | option | 8 |
|	Surviving Mars | Haemimont G.	|	https://www.survivingmars.com/	| 150318 | T | mail | option | 8 |
| The Guild 3 | Golemlabs | https://theguildgame.com/#about-the-guild-3 | n/d | T | mail | option | 8 |
| SpellForce 3 | | https://spellforce.com/| n/d | G | bandera | mail | option | 8 |
| Jurasic World Evolutions | company | page | summer18 | T | mail | option | ps4-xb1-pc | 9 |
| Ancient Cities | UncasualGames | https://www.ancient-cities.com/ | n/d | T | mail | option | ps4-xb1-pc | 9 |
| Battletech | Harebrained Schemes | http://battletechgame.com/ | 24/04/18 | A | email-contact | pre | pc-mac | A |
| Phantome Doctrine | CreativeForge G. | http://www.creativeforge.pl/pdgame/ | 2018 | Gc | info@creativeforge.pl | options | PC | 20 |

| Phoenix Point | Snapshot Games | https://phoenixpoint.info/home/ | 30/04/18 | ? | contact@snapshotgames.com | pre | PC-LINUX-MAC | ? |



***************

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|
