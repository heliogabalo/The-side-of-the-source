> "All of these news organisations around the world, all of these publishers 
were trying to get a piece of the story. There was only one publisher that 
actually said: We want to help the source, we want to make sure he’s ok, we 
want to make sure that, no matter what happens, he has somebody on his side, 
and that was WikiLeaks." – Edward Snowden

"Ever tried. Ever failed. No matter. Try again. Fail again. Fail better" - Samuel Beckett
