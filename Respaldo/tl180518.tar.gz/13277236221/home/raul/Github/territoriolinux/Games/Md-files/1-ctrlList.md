#### Indie Games ####

- [x]The Great Zoo scape 2 								- [T6]In the valley of gods(action/adventure)
- [x]Way To The Woods (PS4,Xbox One,PC)   - [x]Planet Alpha
- [x]FAR: Lone Sails(PS4,Xbox One)				- [?]Abandon Ship(aventura)

#### Plataforma ####

- [T5]Bloodstained: ritual of the night 					- [A]Donkey Kong Country: Tropical Freeze
- [?]johnny's turbos arcade: super burger time		- [T7]Little Nightmares
- [T2]Mega Man Legacy Collection 1-6

#### Acción Aventura - 2018

- [x]MineCraft(T4)								- [T4]Insomnia: The Ark
- [x]gravity Rush 2(T)						- [x]Nier Automata
     gravity Daze 2(japones)			- [x] Biomutant(q1-18)x-pc-p4(G1)
- [x]Agents of Mayhem(T)					- [x]Nioh(T)
- [x]Yakuza 0 (G)									- Prey (*)
- [A]Horizon: Zero Down (*)				- [A]Super Mario Odyssey
- [A]The Legend of Zelda: Breath	- [x] Red Dead Redemption 2 (*F)
- [A]Sea of Thieves								- [x]Crackdown 3
- [x]sCumVm												- [x]call of cthulhu
- [x]A Way Out(T1x2)							- [x]fade to Silence(pre)
- [x]Days Gone(T)									- [x]Spiderman(Tpre)
- [x]God of War**(T2)							- [x]State of Decay(T1)
- [x]Wild West Online(G)					- [x]Golem (T3)
- [x]Devil May Cry (T4)						- [A]Shadow of Colossus(remake)(Availabel-060218-ps4)
- [x]Days Gone (ps4)							- [x]Cyber Punk(G2)
- [x]Bayoneta 3(A)								- [x]Dreams s
- [A]The Last of Us								- [x]DarkSiders*!
- [T3]Detroit become Human				- [x]Mutant Year Zero: Road to Eden (PS4,Xbox One,PC)
- [x]Scavengers 
- [x]Anthem**											- [x]Shadow of the Tomb Raider
- [A]Monster Hunter: World
- [A]subnautica										- [T1]Extintion
- [A]Dragon B. FighterZ ps4				- [T8]Conan Exiles
- [T9]Ghost of Tsushima						- [A]Dynasty Warrior 9
- [T9]LEGO The Incredibles				- [T8]BlazBlue: Cross Tag Battle
- [T7]Shaq Fu: A Legend Reborn		- [T6]New Gundam Breaker
- [T7-Gd]DeathGarden							- [T4]Vahall
- [T5]Forest Of Liars							- [T5]Rage 2


#### RPG ####

- [x]Dark souls remastered					- [x]Call of Cthulhu
- [x]fade to Silence								- [x]Code Vein
- [x]System Shock 3									- [x]Ni no Kuni 2 Revenant Kingdom
- [?]Dark and Ligh									- [T1]Dauntless 
- [x]The elder Scroll Online				- [A]Pillars of Eternity II: Deadfire
- [A]Kingdom Come Deliverance				- [T3]Swtor: knights of the fallen empire
- [T9]Dangerous Rushers

***************

## Fantsy Games - 2018

- [x]Pine												- [x]Rune: Ragnarok*(pre-T)
- [x]Exzore: Rising								- [x] The Last Night
- [x]Midle Earth:Shadow o'War(*G)	- [x] Ashes of Creation
- [x]Elex (T)										- 
- [x]Project Wight*							- Shadow of the colossus remake
- Babylon Project**							- [x]GreedFall (T)
- Monster Hunter: World					- [x]Vampyr (T*)
- [x]Wild(T)	muy verde!				- [x]Ealdorlight(T*)
- [x]War of rights(T)						- Black Room
- 


***************
## First Person Shooter(FPS) - 2018

- [x]War of rights(T)									- Black Room(kickstart)
- [x]Serious Sam	(G)									- [x]Witchfire(T)
- [x]Hell let Loose										- [T7]Death Garden
- [x]Deep rock Galactic(T)						- [x]Scorn (T)
- [?]Ready or not											- [x]Atomic Heart II(T)
- [x]GTFO (T-pc)											- [x]Hunt: Showdown(tba-pc-ps4-xb1)
- [?]Border Lands 3										- []
- Escape from Tarkov
- [A]Warhammer Vermintide 2
- [x]Batalion 1944										- [?]Left Alive
- [T2]Metro Exodus								- [x]Far Cry 5 (270318-ps4,x1,pc) (*T)
- [A]Kingdom Come: Deliverance				- [x]Call of Duty Black Ops 4 
- [x]Bravo Team												- [?]Freeman Star Edge
- [T2]Insurgency: Sandstorm 				  - [T]EarthFall
- [A]Wolfenstein 2: The new Colossus  - [?]Rico
- [x]Hellbound(PC)										- [A]Hunt: Showdown
- []Genesis Alpha One(PS4 Xbox PC)

#### Simulation Games - 2018 ####

- [x]The crew 2																	- [x]Dual Universe Spring (PC)
- [x]MX vs ATV all Out	(270319-ps4,x1,pc)			- [x]Frostpunk (WARNING NO PUBLICAR)
- [A]The Hunter CAll of the Wild								- [x]Pure Farming
- [x]Skull & Bones															- [T4]Industries of Titan
- [?]Ace Combat 7																- [?]Tropico 6
- [x]ONRUSH																			- [Gi]MXGP
- [?]Uboot																			-
- [T1]Pro Evolution Soccer 2019

## Strategy Games - 2018

- [x]ancestors (T)									- [x]Jurasic World Evolution*(T)
- [x]Surviving Mars(T)							- [x]The Guild 3(T)
- [x]Ancient Cities									- Anno 1800
- [x]SpellForce 3(G)								- Iron Harvest 1920*
- Age of Empires IV*								- [A]battletech(pc-mac) 
  Definitive Edition								- [Gc]Phantome Doctrine
- Age of Mythology									- [?]Phoenix Point


#### Horror 2018-2019 ####

- [x]The Blackout Club								 - []The Beast Inside(pc)19*
- []Today is Birthday
- []Project Nightmares								 - []Ad Infinitum(tba'pc)
- [x]Moons of Madness		 							 - []Reborn(tba-pc)
- []Forbidden Forgiveness							 - []Pathologic 2*(tba-pc-ps4-xb1)
- []The Sinking City 									 - [BG-T3]Overkills the Walking Dead
- [x]Agony														 - [x]Death Stranding (PS4,PC)
- [?]Daemonical												 - [T8]Gray Dawn

#### Free to play

- []Europa(pc-2018)										- Ascent: Infinite Realm(pc-q2-2018)
- []Conqueror's Blade(pc-tba18)				- Defiance 2050(ps4-xb1-pc)tba
- []Bless Online(pc-tba)							- Total War: arena(pc-2018)
- []Soldiers: arena(pc-q2-2018)				- Gwent: The Witcher Card Game(ps4-xb1-pc/18)
- []Tera: consoles(ps4-xb1/18)				- Unreal Tournament(pc/18)
- []Dauntless(pc/tba)									- Paladins: Batlegrounds(pc-2018)
- [T6]hyper Universe


#### No definidos ####





JunkYard Simulator(PC)
Warhammer 40.000: inquisitor(PC)
Space Hulk: Deathwining(PS4 Xbox PC)
Street Fighter 30th anniversary Collection(PS4 Xbox PC Switch)
Identity
Dragon Ball FighterZ
Final Fantsy 15


#### palestra ####

- The Good Life(kickStarter OjO No hay media)
- Fist of North Star (18 ps4)
- Battle field 2018(?) verde
- Metal Gear Survive(?) verde
- Pray For Gods(?) muy verde!
- Bright Memory(PC) ??
- Ready or Not(PC)??

- cyberPunk 2077
- System Shock
- Metro Exodus 

#### These people don't want i speak about it ####

Soul Calibur							- [A]WoW 
black desert online				- Lineage Eternal (projectTL)
[A]EVE online							- [A] Valnir Rok
Blade and Soul						- [A] Dark and Light
Secret World legends			- Crackdown 3
RuneScape									- Skull and Bones(q4-18-ps4-xb1-pc)
Tera
Final Fantasy XIV					- halo

###### UbiSoft(These people don't want i speak about it)

- [ALERTA]UbiSoft-mafiaConCuentaIntervenida
- Beyond Good & Eveil 2				-anno 1800
- Assassin's Creed: Origins
- For Honor
- Ghost Recon

***************



<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
