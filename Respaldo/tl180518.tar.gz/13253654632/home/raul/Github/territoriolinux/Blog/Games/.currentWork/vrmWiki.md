	
Voltage regulator module
From Wikipedia, the free encyclopedia
Voltage regulator module for an IBM Netfinity 7000 M10 server running an Intel Xeon 500 MHz processor

A voltage regulator module (VRM), sometimes called processor power module (PPM), is a buck converter that provides a microprocessor the appropriate supply voltage, converting +5 V or +12 V to a much lower voltage required by the CPU, allowing processors with different supply voltage to be mounted on the same motherboard.

Contents

    1 Overview
    2 Voltage identification
    3 See also
    4 References
    5 External links

Overview
Haswell featured a FIVR.
Voltage regulator module (parts external to the processor's fully integrated voltage regulator) on a computer motherboard, covered with heat sinks

Some voltage regulator modules are soldered onto the motherboard, while others are installed in an open slot designed especially to accept modular voltage regulators. Some processors, such as Intel Haswell CPUs, feature voltage regulation components on the same package (or die) as the CPU, instead of having a VRM as part of the motherboard; such a design brings certain levels of simplification to complex voltage regulation involving numerous CPU supply voltages and dynamic powering up and down of various areas of a CPU.[1] A voltage regulator integrated on-package or on-die is usually referred to as fully integrated voltage regulator (FIVR) or simply an integrated voltage regulator (IVR).

Most modern CPUs require less than 1.5 V,[2] as CPU designers tend to use lower CPU core voltages; lower voltages help in reducing CPU power dissipation, which is often specified through thermal design power (TDP) that serves as the nominal value for designing CPU cooling systems.[3]

Some voltage regulators provide a fixed supply voltage to the processor, but most of them sense the required supply voltage from the processor, essentially acting as a continuously-variable adjustable regulator. In particular, VRMs that are soldered to the motherboard are supposed to do the sensing, according to the Intel specification.

Modern graphics processing units (GPU) also use a VRM due to higher power and current requirements. These VRMs may generate a significant amount of heat and require heat sinks separate from the GPU.[4]
Voltage identification

The correct supply voltage is communicated by the microprocessor to the VRM at startup via a number of bits called VID (voltage identification). In particular, the VRM initially provides a standard supply voltage to the VID logic, which is the part of the processor whose only aim is to then send the VID to the VRM. When the VRM has received the VID identifying the required supply voltage, it starts acting as a voltage regulator, providing the required constant voltage supply to the processor.

Instead of having a power supply unit generate some fixed voltage, the CPU uses a small set of digital signals, the VID lines, to instruct an on-board power converter of the desired voltage level. The switch-mode buck converter then adjusts its output accordingly. The flexibility so obtained makes it possible to use the same power supply unit for CPUs with somewhat different nominal supply voltages and to reduce power consumption during idle periods by lowering the supply voltage.[5]

For example, a unit with 5-bit VID would output one of at most 32 (25) distinct output voltages. These voltages are usually (but not always) evenly spaced within a given range. Some of the code words may be reserved for special functions such as shutting down the unit, hence a 5-bit VID unit may have fewer than 32 output voltage levels. How the numerical codes map to supply voltages is typically specified in tables provided by component manufacturers. As of 2008 VID comes in 5-, 6- and 8-bit varieties and is mostly applied to power modules outputting between 0.5 V and 3.5 V.
See also

    Switched-mode power supply applications (SMPS) applications
    Pulse-width modulation

References

"Intel's Haswell Takes A Major Step Forward, Integrates Voltage Regulator". hothardware.com. 2013-05-13. Retrieved 2013-11-14.
Bob Dobkin, John Hamburger. "Analog Circuit Design Volume Three: Design Note Collection". John Seago. Chapter 16: "2-step voltage regulation improves performance and decreases CPU temperature in portable computers." 2014. p. 37.
Mike Chin (2004-06-15). "Athlon 64 for Quiet Power". silentpcreview.com. p. 3. Retrieved 2013-12-21. "Thermal Design Power (TDP) should be used for processor thermal solution design targets. The TDP is not the maximum power that the processor can dissipate."
"Graphics Cards Voltage Regulator Modules (VRM) Explained". geeks3d.com. 2010. Retrieved 2013-11-28.

    Intel document "Voltage Regulator-Down (VRD)" 11.0 http://www.intel.com/assets/pdf/designguide/313214.pdf dated November 2006.

External links

    "Microprocessor Power Management"

Categories:

    Voltage regulationDigital electronics


