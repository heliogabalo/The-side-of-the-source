- referencias a memorias revisar esto
	- hbm2[] fpga[x]

- hay que terminar los apuntes de Qemu, acuerdate de meter los _esquemas_.

- Intercambiables!!
- error404, hay que hacerla!!

Los simberguenzas de Ubisoft, estan permitiendo que otro utilice mi cuenta
esto es, probablemente han vinculado el correo a otra cuenta, y la info esta
en sus bases de datos. A por ellos.
