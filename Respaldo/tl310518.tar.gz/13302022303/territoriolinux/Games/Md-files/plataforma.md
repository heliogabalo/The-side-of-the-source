
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Bloodstained: ritual of the night | bandai namco | https://505games.com/games/bloodstained | 2018 | T5 | email-contact | pre | ps4-xb1-switch-pSvita | 15 |
| Donkey Kong Country: Tropical Freeze | Retro Std. & Monster G. | http://donkeykong.nintendo.com/tropical-freeze/ | A | bandera | email-contact | options | Nintendo Switch | week nº |
| Mega Man Legacy Collection 1-6 | Capcom | https://www.nintendo.com/ | 22/05/18 | T2 | email-contact | options | N Switch | 20 |


| Little Nightmares | Tarsier Std. | https://www.nintendo.com/games/detail/little-nightmares-complete-edition-switch | 18/05/18 | Bandera | email-contact | options | Nintendo Switch | 21 |
| johnny's turbos arcade: super burger time  | Flying Tiger | https://www.flyingtigerentertainment.com/super-burger-time.html | 17/05/18 | @ | ? | pre | Switch | ? |




---

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
