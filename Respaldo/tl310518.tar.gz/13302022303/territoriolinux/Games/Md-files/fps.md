
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| War of Rights | CampFire G. | https://warofrights.com/ | n/d | T-G | mail | ErlAcc/dlc | plataforma | 6-9 |
| Atomic Heart II| n/d |http://www.mundfish.com/#| n/d | T | partners@mundfish.com | option | 8 |
| Scorn | Ebb Software | https://scorn-game.com/pages/media | n/d | T | mail | option | 8 |
| Witchfire | The Astronauts | http://www.theastronauts.com/ | n/d | T | mail | option | 9 |
| Metro Exodus | 4A Games | http://www.metrothegame.com/ | 31/12/18 | T-T2 | mail | ErlAcc/dlc | ps4-xb1-pc | 9-21 |
| Bravo Team -VR | Supermassive Games | http://www.supermassivegames.com/games/bravo-team | 070318 | T5 | email-contact | options | ps4 | 11 |
| Hunt: Showdown | Crytek | https://www.huntshowdown.com/ | tba | T6 | email-contact | earlA. | pc-ps4-xb1 | 12-13 |
| Batalion 1944 | BulkHead Int. | http://battaliongame.com/ | q2-2018 | ? | info@bulkheadinteractive.com | EarlA. | pc | ? |
| Moons of Madness | Rock Pocket G. | http://www.moonsofmadness.com/moons/ | q2-2018 | T3 | natascha@rockpocketgames.com | options | pc-ps4-xb1 | 12-13 |
| Call of Duty Black Ops 4 | Treyarch | https://www.treyarch.com/ | 12/10/18 | ? | email-contact | options | PS4,Xbox One,PC | 14 |
| Hell let Loose | Black Matter | https://www.hellletloose.com/ | q2-2018 | T7 | email-contact | options | pc | 14 |
| Death Garden | Behaviour Int. | deathgardengame.com | tbc | T7 | email-contact | pre | pc | 15 |
| Insurgency: Sndstorm | New Worl Int. | http://www.insurgency-sandstorm.com/ | tbc | T2 | email-contact | options | pc-ps4-xone | 15 |
| EarthFall | Hollopark | https://www.earthfall.com/ | 26/04/18 | T | email-contact | pre | PS4,Xbox One | 15 |
| Wolfenstein 2: The new Colossus | MachineGames | https://wolfenstein.bethesda.net/ | 29/06/18 | A | email-contact | pre | ps4-xb1-pc-nintendo-Switch | 20 |

| Left Alive | Esquare Enix | https://www.left-alive.com/na | 2018 | ? | email-contact | options | PS4s | ? |
| Freeman Star Edge | kk Games Std. | https://www.freeman-game.com/ | 2018 | ?? | email-contact | pre | plataforma | ?? |
| Rico | Ground Shgatter | http://rico-game.com/ | 2018 | ? | james@groundshatter.com | options | ps4 Xbox PC | ? |
| Hellbound | Saibot Std | http://hellboundgame.com/ | 2018 | ? | contact@hellboundgame.com | options | PC | ? |
| Hunt: Showdown | Crytek | https://www.huntshowdown.com/ | A | ? | email-contact | A | PS4 Xbox PC | ? |
| Genesis Alpha One | CompanyName | Pagina | verano 18 | ? | email-contact | pre | PS4 Xbox PC | ? |


()
---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | plataforma |week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|
