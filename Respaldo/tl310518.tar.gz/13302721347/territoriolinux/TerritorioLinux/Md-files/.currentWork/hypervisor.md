[](URL)
[Referencias y agradecimientos](i#99)

#### instalación de Xen ####

- hypervisor, kernel modificado
- dom0, kernel preparado para correr bajo un hipervisor
- herramietas, para gestionar el entorno.



#### <a name="i99">Referencias y agradecimientos</a> ####


