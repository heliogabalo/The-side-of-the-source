






 Antes de ser un Dios, fue un hombre


                                                                          


La venganza nace del fuego de la traición. Y el Dios de la guerra, retorna una vez más en esta franquicia.


Seis meses han pasado desde que acudió al cuerpo de su espesa e hijo, con las manos ensangrentadas.
kratos rompió el juramento de sangre que le unía a Ares y, lo maldijo. Aunque los juramentos en el Olimpo, no se rompen tan fácilmente...


Arrastrado a pasar la eternidad, encadenado a una prisión mortal. Kratos, se revelará contra las Furias, protagonizando épicas batallas. En una búsqueda por encontrar su libertad, la redención de sus pecados y, la ansiada venganza por el cruel asesinato de su familia.





Una mitológica historia.



 

Ésta nueva entrega del Dios de la Guerra, representa un sorpredente y fascinante viaje, al pasado más oscuro de Kratos. Pero también nos acerca a su lado más humano. Antes de convertirse en el "Fantasma de Esparta".


La firma de éste juego histórico, conserva la esencia de una auténtica campaña para jugador.




Ascenso multijugador



Conviértete en un campeón entre los Dioses! Nunca antes, humanos  y Dioses   se enfrentaron en una batalla tan visceral. 


Protagoniza el combate en línea, de la mano del Dios de la Guerra, y equipa a tu gerrero, adquiriendo experiencia en batallas.


En el modo multijugador, empezarás con un sencillo guerrero, comprometido con los Dioses, por alcanzar gloria y honor.
Zeus, Ares, Poseidón, Hades. Gana su favor, para lograr nuevas habilidades, poderes mágicos, armas y armaduras únicas. Convierte a tu guerrero, en la mayor leyenda del Olimpo.












