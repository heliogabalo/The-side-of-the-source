 Dinero y experiencia en Far Cry 4.


Habrá que llegar al puesto de avanzada Este, el campo de entrenamiento Shanath. Nada mas entrar en el campamento, aparece un guardia fuertemente armado, patrullando el puente.

Hay que deshacerse de él, con C-4. La recompensa por eliminar al objetivo son 240 puntos de experiencia.


Un poco mas abajo hay dos tigres, que habrá que neutralizar igualmente. Las pieles son valiosas.

Sin ninguna duda, debemos recogerlas y cambiarlas por 7000 créditos o monedas cada una. Al terminar de despellejar a los tigres, hay que pausar el juego y grabar la partida. Acto seguido, es necesario dejarse matar.


La mejor alternativa en estos casos, es encontrar un risco alto por el que despeñarse o un enemigo violento, con ganas de probar el arma.

Reapareceremos a unos 320 metros de distancia del campamento de entrenamiento, con la experiencia obtenida de los enemigos anulados.


Hay que volver al puesto de avanzada y repetir el proceso, hasta conseguir la habilidad "Heavy Takedown".


Una vez conseguida, en lugar de matar al enemigo con C-4, es mejor acercarse sigilosamente hasta él, y eliminarlo con la habilidad recién conseguida, "Heavy Takedown".


Ahora la experiencia recibida serán 400 puntos de experiencia por muerte.


Bastará con volver a repetir el proceso, tantas veces como sean necesarias.

No hay que preocuparse por obtener el  C-4, ya que tras cada enemigo eliminado, hay una unidad extra del explosivo.





Modo Dios y munición infinita.


Éste es un truco que funcionó en Far Cry 3, utilizable igualmente en Far Cry 4.

Hay que abrir la carpeta donde se guardan las partidas. Por defecto, está localizada en

C: \ Users \ Usuario \ Documents \ My Games \ Far Cry 4


Abre el archivo "GamerProfile.xml" con el bloc de notas, y busca la cadena "&lt; GameProfile /&gt;".


La edición de las líneas debe quedar así:

    &lt; GameProfile

       GodMode = "1"

       UnlimitedAmmo = "1" /&gt;


Sólo queda guardar el archivo y divertirse.





EscenarioDeJuego








