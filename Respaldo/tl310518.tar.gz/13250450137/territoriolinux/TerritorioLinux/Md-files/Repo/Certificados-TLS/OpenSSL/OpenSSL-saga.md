# OpenSSL Certificado de Autoridad

Con este archivo, empezamos en Territorio Linux, ha trabajar en una _serie_ de
artículos, para la gestión de certificados.

En anteriores entregas, habiamos hablado de la configuración _TLS_, para máquinas
virtuales, con la librería _Libvirt_. Con esta nueva serie de artículos,
pretendemos cubrir un uso más generalizado, para este protocolo.

El método usado es prácticamente idéntico, cambiaremos algunas herramientas y,
hablaremos de otras normas o consejos de seguridad, que se quedaron en el tintero.

Como siempre, para aquellos que prefieran la lectura en versión original, podrán
encontrar todas las referencias al final del artículo.
