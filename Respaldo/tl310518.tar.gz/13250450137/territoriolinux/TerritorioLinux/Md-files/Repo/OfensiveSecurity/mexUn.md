
- Conceptos y vocabulario

    * Plugins: pueden ser cargados en tiempo de ejecución.
    * Scripts: Meterpreter y otros.
    * Payloads: código que se ejecuta de forma remota.
    * Rex: biblioteca básica.
    * Codificadores. asegura que los payloads lleguen a su destino.
    * Nops: mantienen el tamaño de los payloads constante.
    * Mixins: Concepto de Ruby. Mezcla de clases, 'incluye una clase en otra'.

## Msfconsole commands
  - Desde la línea de comandos
  ~~~  
  # ./msfconsole -r name_of_resource_script.rc  
  ~~~  

Desde la aplicación:
  ~~~  
  msf > resource name_of_resource_script.rc
  ~~~  





- Materiales 
    * basico SO target
    * basico VM
    * basico LAN/VLAN/BRIDGE
    * http://www.metasploit.com/express/community
    * https://sourceforge.net/projects/metasploitable/files/Metasploitable2/
    * Equipo de desarrolladores:
    * login/pasword: msfadmin:msfadmin

> _notas:_ Desde rapid7 hay una nota sobre el comando msfcli que ha quedado obsoleto  
> https://community.rapid7.com/community/metasploit/blog/2015/07/10/msfcli-is-no-longer-available-in-metasploit  

