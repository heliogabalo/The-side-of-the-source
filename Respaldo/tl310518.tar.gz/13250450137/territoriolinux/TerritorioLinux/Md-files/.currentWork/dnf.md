A1-so/rpm/dnf

## DNF 

- Qué es

#### Intrucciones útiles

- dnf history
- dnf kernel update?

---

#### Referencias
[Magazine][https://fedoramagazine.org/managing-packages-fedor-dnf]
[dnf][readthedocs.io/es/latest]

