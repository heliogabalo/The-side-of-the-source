#### Header ####

También existe la posibilidad de crear una imagen ISO:

		$ make -j8 isoimage


- parches, gestión, etc  
	- aplicar o revertir cambios.	 
- DVCS? como vamos a descargar la fuente  
- configuración, construcción e instalación  
	- instalación en el dom0  
	- Reconfiguración en caliente; con el sistema en funcionamiento.  
	- reconfiguración por medio de archivos `conf`  
	- Configuración con ncurses	 
	- hay otras, desde la consola debe poder hacerse  
- creacion imagen(paquete).  

---

#### < a name="#i6">Referencias</a>

[https://docs.fedoraproject.org/f26/install-guide]:[Fedora Installation Guide]
[https://en.wikibooks.org/wiki/How_To_Backup_Operating_Systems]:[How_To_Backup_Operating_Systems]
[https://www.kernel.org/doc]:[kernel-docs]
#### Reconstruir el kernel
[https://boot.fedoraproject.org/downloads]:[Reconstruir?]
#### DOWNLOAD
[https://dl.fedoraproject.org/pub/alt/bfo/bfo.iso]:[Downloads]
#### net isntall
[http://ipxe.org]:[Net-install]
