			ARROZ  CON COSTILLA IBERICA

600   Gr. Costilla Ibérica
    4   Tazas de arroz bomba
    9   Tazas de caldo de verduras o Agua
    2   Dientes de Ajo
    1   Cebolla mediana
    1   Pimiento Verde o Rojo
    2   Tomates pelados
    1   Higado de pollo
        Azafrán -  Sal -  Pimienta 
        Aceite de AOVE

				PROCEDER

Picar los ajos, cebolla, pimiento, tomate y reservar.
En una sartén con aceite cocinar el higado, y cuando este hecho, 
desmenuzar y reservar.

En ese mismo aceite dorar la costilla y reservar.
En una Paellera sofreir la cebolla y cuando esté transparente añadir 
los ajos, el pimiento y seguir sofriendo hasta que esté hecho. 

Añadir el tomate y sofreir durante 10 minutosy por último añadir el 
higado que teniamos reservado.

Poner el caldo a calentar y mientras tanto, en la paellera con las 
verduras, añadir el arroz, el azafrán y sofreir todo junto; para que 
coja color y sabor.

Salpimentar, añadir la costilla ,y revolver todo junto durante 6 o 7 minutos.
Cuando el caldo esté caliente añadir a la paellera y cocer todo durante 
20 minutos.
