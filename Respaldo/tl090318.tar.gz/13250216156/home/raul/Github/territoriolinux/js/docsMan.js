// Menu Toggle Script

    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    
    
/*
// Menu Toggle Script 
			$(document).ready(function(){
				
				$("#toggler").click(function(){
					$(this).toggleClass('active, inactive');
				})
			})
*/



