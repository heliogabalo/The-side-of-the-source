## First Person Shooter - Febrero 2018

- War of rights(T)							- Black Room
- Serious Sam	(G)								- Witchfire(T)
- Warhammer Vermintide 2				- Hell let Loose
- Deep rock Galactic(T)					- Scorn (T)
- Ready or not									- Atomic Heart II(T)
- GTFO (T)											- Hunt: Showdown
- Border Lands 3								- System Shock (**I-c) 
- Overkills the Walking Dead		- Escape from Tarkov
- Batalion 1944									- unannonuced Call of Duty -treyarch
- Metro Exodus*	(T2)						- Far Cry 5 (270318-ps4,x1,pc) (*T)
- Kingdom Come: Deliverance			- Witchfire
---

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| War of Rights | CampFire G. | https://warofrights.com/ | n/d | T-G | mail | ErlAcc/dlc | plataforma | 6-9 |
| Atomic Heart II| n/d |http://www.mundfish.com/#| n/d | T | partners@mundfish.com | option | 8 |
| Scorn | Ebb Software | https://scorn-game.com/pages/media | n/d | T | mail | option | 8 |
| Witchfire | The Astronauts | http://www.theastronauts.com/ | n/d | T | mail | option | 9 |
| Metro Exodus | 4A Games | http://www.metrothegame.com/ | 31/12/18 | T | mail | ErlAcc/dlc | 9 |







---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | plataforma |week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |

