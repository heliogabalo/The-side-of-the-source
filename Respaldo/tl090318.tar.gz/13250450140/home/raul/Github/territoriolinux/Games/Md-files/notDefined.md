Soul Calibur							- WoW 
black desert online				- Lineage Eternal (projectTL)
EVE online								-
Blade and Soul						-
Secret World legends			-
RuneScape									-
Tera											-
Final Fantasy XIV					-

--- 
- Death Stranding														- World War Z
- Bayoneta 3
- kingdom come deliverance
- FromSoftware's new project(bloodborne 2?) -Dreams 
- In the valley of gods 										- Battle Royale
- Extintion*																- The Last of Us
- 
- Ghost of Tsushima													-
- Beyond Good & Eveil 2											- The crew 2(ps4,x1,pc)
- Assassin's Creed: Origins 								- Skull and Bones(q4-18-ps4-xb1-pc)
- For Honor										 							- Crackdown 3
- Dragon B. FighterZ ps4(26/01/18)					- Detroit become Human(q1/q2/18)
- Agony(30-03-18) pc-p4-x										- Bloodstained: ritual of the night
- Monster Hunter: World(210108-ps4,x1,pc)											- Anthem*(ps4,x1,pc)
- The las Night															- Death Stranding(ideo kohima?)
- Code Vein																	- DarkSiders*!
- 										-Attack on Titan 2(03-18)xb1-switch-pc-p4
- Shadow of Colossus(remake)060218-ps4			- Fist of North Star (18 ps4)
- Agony(ps4-xb1-pc-300318)									- Days Gone (ps4)
-Jurasi Worl Evolution											- Skull
	(q2-18 ps4-xb1-pc)												- DEvil may cray HD C(pc,x1,ps4-130318)
			- Pure Farming(130318-ps4,x1,pc)
- Golem(070318-ps4)													- Bravo Team(070318-ps4)
- Surviving Mars(150318)										- Kirby: Star Allies(160318-switch)
- 

