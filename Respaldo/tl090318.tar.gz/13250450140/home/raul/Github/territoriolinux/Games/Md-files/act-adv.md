## Action Adventure Games - Febrero 2018

- gravity Rush 2(T)								- Nier Automata
  gravity Daze 2(japones)					- Biomutant(q1-18)x-pc-p4
- Agents of Mayhem(T)							- Nioh(T)
- Yakuza 0 (G)										- Prey (*)
- Horizon: Zero Down (*)					- Super Mario Odyssey
- The Legend of Zelda: Breath			- Red Dead Redemption 2 (*F)
- Sea of Thieves									- Crackdown 3
- sCumVm													- call of cthulhu
- A Way Out(T1x2)										- fade to Silence
- Days Gone(T)										- Spiderman
- God of War**(T2)								- State of Decay(T1)
- Wild West Online(G)
***************




| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Spiderman | Imsomniac G. | https://insomniac.games/ | n/d 18 | T-pre | email-contact | options | PS4 | 5-9 | 
| Agents of Mayhem| RAD Games Tools | http://www.aomthegame.com/ | ready| T | info@deepsilver.com | option | | 8 |
| Nioh | Team Ninja |https://www.gamecity.ne.jp/nioh/outline.html | 071118 | T | mail | option | | 8 |
| Yakuza 0 | sega | http://yakuza.sega.com/yakuza0/home.html| 240118 | G | mail | option | | 8 |
| Red Dead Redemption 2 | Rock Star Games | https://www.rockstargames.com/reddeadredemption2/ | 261018 |pre G| mail | option | | 8 |
| fade to Silence | balckForest G. | https://fadetosilence.com/ | fecha | anunciado | info@bfgames.biz | ec/dlc | |8T 11pre |
| A Way Out| EA games | https://www.ea.com/games/a-way-out | 23/03/18 | T | mail | | 9 |
| Days Gone | Bend Studio | http://bendstudio.com/ | n/d | T | mail | ErlAcc/dlc | | 9 |
| CyberPunk 2077 | CdProjekt | http://cyberpunk.net/ | F. lanzamiento | Bandera | marcin.momot@cdprojektred.com | options | plataforma | 11Gc |
| State of Decay | Undead Labs | https://www.stateofdecay.com/ | primavera18 | Bandera | email-contact | options | ps4,x1,pc | 11T1 |
| God of War | Santa M. std. | http://sms.playstation.com/ | 20/04/18 | Bandera | email-contact | options | PS4 | 11T2 |
| Wild West Online | 612 Games | http://buy.playwwo.com/ | 15/11/18 | Gr | support@playwwo.com | ErlAcc | PC | 11 |

(early18- pc)

---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G <lcr>-- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |
| options -- earlyAccess/DLC |

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
