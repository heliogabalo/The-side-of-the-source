13/03/15

ShadowOfMordor



Quitar secuencias animadas.


Abrir la carpeta de instalación del juego "\ShadowOfMordor\game\interface\videos\"

Mover los siguientes archivos a una carpeta temporal.


"intro_cz.vib"

"intro_de.vib"

"intro_fr.vib"

"intro_hu.vib"

"intro_ja.vib"

"intro_mx.vib"

"intro_pl.vib"

"intro_po.vib"

"intro_ru.vib"

"intro_sp.vib"

"intro.vib"

"nvidia_splash.vib"

"WBPlay.vib"

"legal\legaltext.vib"

"legal\legaltext_fr.vib"

"legal\middleware.vib"


Cuando sea abierto el juego, el menú principal aparecerá inmediatamente.


Mensajes de Celebrimbor:


El fantasma Celebrimbor, a menudo cita frases del Señor de los Anillo, al hacer referencia a los acontecimientos que suceden en el juego.



    En los recuerdos borrosos, despés de despertar, habiéndose encontrado con Graug, Celebrimbor grita "corred, estúpidos, corred". En alusión a los acontecimientos ocurridos durante la lucha con Balrog, el dragón. Insta a la Compañía a huir.
    A su regreso a la forja de la Torre, Talión, pregunta qué son las Torres. Celebrimbor, responderá que son una luz en la oscuridad de Mordor, cuando todas las demás se han extinguido. Ésta es una referencia al vial de Galadriel, dado a Frodo Bolsón.
    Talión, hace un comentario sobre si Torvin es un vagabundo. Calimbor responde: "No todos los que vagan, están perdidos". Es una frase del poema, No es oro todo lo que reluce, escrito por JRR Tolkien.







Amazon

Middle Earth:
Shadow of Mordor









Plataforma: PC, PS3, PS4, Xbox360, Xbox One


EscenarioDeJuego
