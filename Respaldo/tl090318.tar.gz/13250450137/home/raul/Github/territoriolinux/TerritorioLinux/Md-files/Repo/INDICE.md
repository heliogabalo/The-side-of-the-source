
Deberías pensar en ir creando un índice para la documentación

- A1-SO
- A2-Supuestos
- A3-Programación
- A4-Hardware
- Certificados
- ISO9660
- Leyes
- OfensiveSecurity
- Servidor
...

** idea -- dos rutas a la documentacion
	** el Indice general(porTema)
	** busqueda a traves de siglas(siglas.md)
	
---

siglas.md
