## Disco Ram de inicio

_Extraido de wikipedia:_

En computación, `initrd`(disco de inicio Ram) es un esquema para cargar 
temporalmente en memoria, el sistema de ficheros _root_, el cuál podría ser
utilizado como parte del proceso de arranque de _Linux_. 

Referidos a métodos distintos de conseguir ésto `initrd` e `initramfs`, son
comunmente usados, durante los preparativos de inicio de sistema y, que 
finalmente permitirán al _SO_ poder montar el sistema de ficheros `root`
definitivo.

#### Configuración

El `/dev/initrd` es un dispositivo de bloque de _solo lectura_ el cual viene siendo  
asignado con un número mayour `1` y uno menor `250`. El propietario de `/dev/initrd`  
es root.disk con modo 0400(acceso lectura sólo por el root). Si el sistema _Linux_ no  
tiene creado `/dev/initrd` puede crearse con:

		mknod -m 400 /dev/initrd b 1 250
		chown root:disk /dev/initrd

De igual forma, es posible configurar el soporte para `RAM disk` y `Initial RAM disk`,  
aunque para ello, habrá que configurar tales características compilándolas directamente  
en el núcleo del sistema:  

		CONFIG_BLK_DEV_RAM=yes
		CONFIG_BLK_DEV_INITRD=yes

Cuando se use `/dev/initrd` el _controlador del disco RAM_, no podrá ser cargado como
módulo.

#### Descripción ####

El archivo especial `/dev/initrd` es un dispositivo de bloque de sólo lectura. Éste  
dispositivo, es un _disco RAM_ inicializado(cargado) por el gestor de arranque, antes  
del _kernel_. Es entonces cuando el _núcleo_ podrá usar el contenido de `/dev/initrd`
para _levantar_ el sistema en dos fases.

En la primera fase, el _núcleo_ monta el sistema de archivos raíz `root` con el  
contenido de `/dev/initrd` -ejem. disco _RAM_ inicializado por el gestor de arranque.
En la segunda fase, otros controladores y módulos adicionales, serán cargados desde el
contenido del _dispositivo_ raíz. 
Después de cargar los módulos adicionales, un nuevo _FS_ raíz(ejem. el _FS_ raíz normal)  
será montado desde uns dispositivo distinto.

__Operación de arranque__

Cuando se arranca el sistema con _initrd_, lo hace de la siguiente forma:

1. El gestor de arranque carga el programa del núcleo y el contenido `/dev/initrd` en
memoria.
2. Al inicio del _núcleo_, éste descomprime y copia el contenido del dispositivo
`/dev/initrd` dentro del dispositivo `/dev/ram0` y libera la memoria utilizada por
`/dev/initrd`.
3. El núcleo monta en modo _lectura-escritura_ el dispositivo `/dev/ram0` como _FS_
inicial raíz.
4. Si el _FS_ normal indicado, es también el _FS_ raíz inicial, -ejem. `/dev/ram0`  
entonces el _kernel_ evita el último paso, en cuanto a la secuencia de arranque.
5. Si el archivo ejecutable `/linuxrc` está presente en el _FS_ raíz inicial, 
`/linuxrc` es ejecutado con `UID 0`. El archivo `/linuxrc` debe tener permisos de
ejecución -ppuede ser cualquier ejecutable válido, incluído un `shell script`. 
6. si `/linuxrc` no es ejecutado o al terminar, el FS ráiz normal será montado. Si
`/linurrc` sale con un FS montado en el FS raíz inicial, entonces el comportamiento 
del _kernel_ será `UNSPECIFIED`(no especificado). Ver la sección de __notas__ para
el _comportamiento corriente del kernel_.
7. Si el FS raíz normal, tiene un directorio `/initrd`, el dispositivo `/dev/ram0` es  
movido desde `/` a `/initrd`. De otra forma, si el directorio `/initrd` no existe, 
el dispositivo `/dev/ram0` será montado. Cuando sea movido `/` a `/initrd`, `/dev/ram0`  
no será _desmontado_, además, el proceso podrá continuar _corriendo_ desde `/dev/ram0`.  
Si el directorio `/initrd` no existe en el FS normal y, cualquier proceso sigue 
corriendo desde `/dev/ram0`, cuando `linuxrc` salga, el comportamiento del núcleo será
`UNSPECIFIED`. Ver la sección de __notas__ para el _comportamiento corriente del  
kernel_.  
8. La secuencia habitual de arranque -ejem. invocatioón de `/sbin/init`, será llevada  
a cabo por el FS raíz normal.

__Opciones__

Las siguientes opciones del cargador de arranque, cuando sea usado __initrd__,  
afectarán a las operaciones de arranque del kernel:











#### notas

El gestor de arranque, leerá el núcleo junto a un sistema de ficheros 
inicial llamado raíz(root), -como una imágen en memoria, y después activará
el núcleo, pasando a la memoria, la dirección de la imagen.

- Carga estática
- Carga dinámica
- initrd
- initramfs
- Gestor de arranque

---




		
		













<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>




