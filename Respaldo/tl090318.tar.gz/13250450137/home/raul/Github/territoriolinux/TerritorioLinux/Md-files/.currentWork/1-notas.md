- referencias a memorias revisar esto
	- hbm2 fpga

