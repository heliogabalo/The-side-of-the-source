## Strategy Games - Febrero 2018

- ancestors (T)											- Jurasic World Evolution*(T)
- Surviving Mars(T)									- The Guild 3(T)
- Ancient Cities										- Anno 1800
- SpellForce 3(G)										- Iron Harvest 1920*
- Age of Empires										- Age of Empires IV*
  Definitive Edition
- Age of Mythology									-
- ancestors													-



| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
|	Ancestors Legacy	|	Destructive Creations	|	https://destructivecreations.pl/	| 220518 | T | info@destructivecreations.pl | option | 8 |
|	Surviving Mars | Haemimont G.	|	https://www.survivingmars.com/	| 150318 | T | mail | option | 8 |
| The Guild 3 | Golemlabs | https://theguildgame.com/#about-the-guild-3 | n/d | T | mail | option | 8 |
| SpellForce 3 | | https://spellforce.com/| n/d | G | bandera | mail | option | 8 |
| Jurasic World Evolutions | company | page | summer18 | anunciado | mail | option | 9 |
| Ancient Cities | UncasualGames | https://www.ancient-cities.com/ | n/d | T | mail | option | 9 |

---
| name | company | page | n/d | anunciado | mail | ec/dlc |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |

Jurasic World Evolutions
