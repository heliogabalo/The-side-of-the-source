1. [Tabla de contenidos](#i1)
2. [Información acerca de las _revisiones_](#i2)
3. [Introducción](#i3)
4. [Punto de entrada en `arch/powerpc`](#i4)

99. [Referencias y agradecimientos](#i99)


# El arranque del núcleo deLinux/ppc sin Open Firmware #

#### <a name="i1">Tabla de contenidos</a> ####

1. Introducción
   1. [Punto de entrada en `arch/arm`](#i1i1)
   2. [Punto de entrada en `arch/powerpc`](#i1i2)
   3. [Punto de entrada en `arch/x86`](i1i3)
   4. [Punto de entrada en `arch/mips/bmips`](#i1i4)
   5. [Punto de entrada en `arch/sh`](#i1i5)
2. [El formato de bloque en _DT_](#i2)
   1. [Cabecera](#i2i1)
   2. Generalidades del árbol de dispositivo
   3. "Estructura de bloque" del árbol de dispositivo
   4. "Cadenas" de bloque del árbol de dispositivo
3. Contenido necesario en el árbol de dispositivo
   1. Notas sobre la representación de celdas y direcciones
   2. Notas sobre propiedades compatibles
   3. Notas sobre nombres de propiedades
   4. Notas sobre node, propiedades y conjuntos de caractéres
   5. Notas sobre nodos y propiedades
      - El nodo raíz
      * El nodo `/cpus`
      - El nodo `/cpus/*`
      - El nodo/s `/memory`
      - El nodo `chosen`
      - El nodo `/soc<SOCname>`
4. `dtc`, el compilador del árbol de dispositivo
5. Recomendaciones para el _gestor de arranque_
6. Dispositivos _systemas-en-chip(SoC)_ y nodos
	 1. Definiendo nodos _descendientes_, en un _SoC_
	 2. Representando dispositivos, _sin la especificación_
7. Especificando información de interrupción, en dispositivos
	 1. Propiedades de las _interrupciones_
	 2. Propiedades de las _interrupciones ascendentes_
	 3. Controladores de interrupcion `OpenPIC`
	 4. Controladores de interrupcion `ISA`
8. Especificando información, para la gestión de energía 
del _dispositivo(estado durmiente)_
9. Especificando información para el _bus dma(memoria de acceso directo)_
10. Apéndice A - Ejemplo de nodo _SoC_ para un _chip_ `MPC8540`

***************

#### <a name="i2">Información acerca de las _revisiones_</a> ####

* 18 Mayo, 2005: Rev 0.1 
  - Borrador inicial, aún no hay capítulo III
* 19 Mayo, 2005: Rev 0.2 
  - Añadido el capítulo III, notas y aclarariones
  sobre multitud _opciones_; el kernel necesita un árbol de disporitivo
  _muy pequeño_, aunque es oportuno, proporcionar uno, tan completo como
  sea posible.
* 24 Mayo, 2005: Rev 0.3 
  - Precisar que el bloque _DT_ debe estar en _RAM_
  - Reparaciones misceláneas
  - Definición de la versión 3 y, nuevo formato en la version 16
  para el bloque _DT_ -la versión 16, necesita _parches_, será 
  tratada por separado.
  Las cadenas de bloque, tienen ahora _tamaño_ y, la ruta absoluta
  será reemplazada por _nombre de unidad_, por simplificación.
  Será opcional el _phandle_ de Linux. Únicamente los nodos 
  referenciados por otros nodos, los requerirán.
  La propiedad `name` será deducida mediante el _nombre de unidad_.
* 1 Junio, 2005: Rev 0.4 
	- Corregida la confusión entre `OF_DT_END` y `OF_DT_EN_NODE` en
	la definición de la estructura.
	- Cambio en el formato de la versión 16, para que siempre alinée 
	la propiedad de datos a `4 bytes`. Puesto que los _objetos_, han 
	sido alineados, no será necesario ningún otro alineamiento 
	específico entre, el tamaño de la propiedad y, los datos de la 
	misma.
	El anterior _estilo_ variable, imposibilita una simple inserción
	de propiedades, a través de `memmove`. Agradecimiento a __Milton__
	por notificarlo. Actualizado el parche al _kernel_.
	- Corregidas _otras pocas_ restricciones de alineamiento.
	- Añadido el capítulo sobre el compilador del árbol de dispositivo y, 
	la representación textual del _árbol_, pudiendo ser compilado por _dtc_.
* 21 Noviembre, 2005: Rev 0.5
	- Generalidades y adiciones, en `32-bit`.
	- Cambio para reflejar la nueva estructura `arch/powerpc`.
	- Añadido el capítulo VI.
	
TODO:
	- Añadidas definiciones de interrupción, en el _árbol_(simples/complejas).
	- Añadidas definiciones en el puente _huesped_ del _PCI_.
	- Añadidos ejemplos de formato de dirección común. 
	- Añadidas definiciones de propiedades y _nombres_ `compatible`, en 
	_celdas_ aún no definidas en especifiaciones existentes.
	- Comparación del uso de `FSL SOC` en _PCI_ para estandarizarlo y,
	asegurar que ninguna otra definición es necesaria.
	- Añadida información sobre definiciones de nodo, en dispositivos
	`SoC`, actualmente no _estandarizados_, tales como `FSL CPM`.

#### <a name="i3">Introducción</a> ####

Durante el desarrollo del núcleo de _Linux/ppc64_ y, más específicamente, en la adición  
de nuevos tipos de plataforma,   fuera del par _IBM pSeries/iSeries_,   fué decidio  
reforzar algunas reglas estrictas, respecto a la entrada en el _kernel_ y en el gestor  
de arranque   `<->`   en las interfases del mismo(kernel);  con objeto de evitar la  
degeneración, en la que se ha convertido el punto de entrada del _kernel ppc32_ y, la  
forma en que debería ser añadida una nueva plataforma, al _núcleo_. Las plataformas  
_legadas_ por la plataforma _iSeries_, rompen estas reglas, puesto que predicen el  
esquema, pero no será aceptado nuevo soporte a placas, dentro del _árbol_ principal,  
que no siga las reglas, apropiadamente. Como añadido, será requisito el uso de estas  
reglas,  en la   _confluencia_ de arquitecturas  _arch/powerpc_  sobre plataformas  
ppc32/ppc64.  

El reqquisito principal, definido en detalle más abajo, será la presencia de un árbol  
de dispositivo cuyo formato sea instruido tras la especificación _Open Firmware_.  
Con el fin de facilitar su implementación, a fabricantes de placas embebidas, el  
kernel no _requerirá_ la representación _DT_, de cada uno de los dispositivos en  
el sistema, solicitando -eso sí, la presencia de algunos nodos y propiedades. Explicado  
en detalle en la sección III. Por ejemplo, el _kernel_ no requerirá ser creado un nodo  
por cada dispositivo _PCI_. Únicamente es requisito, definir un nodo para el _puente_  
_huesped PCI(PCI host bridge)_, a fin de proporcionar la información de _enrutado_ y  
rangos de memoria _I/O_, entre otros.  
Es igualmente más flexible para fabricantes de placas,   el hacer actualizaciones  
menores, sin causar un impacto significativo, al código del núcleo o, atestarlo con  
casos especiales.  

#### <a name="i1i1">Punto de entrada en `arch/arm`</a> ####

Existe un único punto de entrada al _kernel_; al principio de la imagen del núcleo.  
El punto de entrada soporta dos lamadas convencionales. El sumario de la interfase  
será aquí descrita. Podrá encontrarse una completa descripción de los requisitos para  
el arranque, documentada en `Documentation/arm/Booting`[[f1]](#f1).  

1. Interfase ATAGS. Mínima información, pasada por el _firmware_ al _kernel_, con una  
lista etiquetada, de parámetros predefinidos.
	 - `r0` : 0
	 - `r1` : Número, para el tipo de máquina
	 - `r2` : Dirección física, de la lista etiquetada en el _sistema RAM_
	 
2. Entrada con el bloque _DT_ alineado . El _firmware_, cargará la dirección física del  
_dtb_[[f2]](#f2) en `r2`, `r1` no es usado, aunque es considerada una buena práctica  
utilizar un nmero de máquina válido, tal y como se describe en `Documentation/arm/Booting`.  

	- `r0` : 0
	- `r1` : Número válido para el tipo de máquina. Cuanmdo se emplea un árbol de  
	dispositivo, será asignado un único número para el tipo de máquina, con el fin 
	de representar una _clase o familia_ de _SoC_s.
	- `r2` : Puntero físico al _dtb_(definido en el capítulo II) de la _RAM_. El árbol
	de dispositivo, podría encontrarsee en cualquier parte dentro de systema RAM, 
	pero debería ser alineado en un límite de _64 bit_.
	
El núcleo hará la distinción entre _ATAGS_ y el _dt_, arrancando(el sistema) con la  
lectura de memoria apuntada por `r2` y, _buscando_ el valor[f3] _dtb_ `0xd00dfeed` ó 
en `ATAG_CORE`, el valor _offset_ `0x4` de `r2` - `0x54410001`.


#### <a name="i1i2">Punto de entrada en `arch/powerpc`</a> ####

Hay un único punto de entrada al _kernel_, al principio de la imagen del mismo. Dicha  
entrada, soporta dos convencionalismos:

	a. El arranque desde _Open Firmware_. Si el _firmware_ de la máquina, es compatible  
	con (IEEE 1275) o proporciona, _una interfase de cliente(API), compatible_;  el  
	soporte para el _intérprete_ de llamadas de palabras adelantadas(forth), no será  
	necesario. Podrá indicarse el _kernel_ de esta forma:
	
	- `r5` : _puntero de llamada_ definido en (IEEE 1275) enlaces a _powerpc_. Únicamente  
	la interfase de cliente de `32-bit`, es coportada actualmente.
	
	- `r2, r4` : dirección y tamaño del `initrd`, si hay  alguno ó, `0`.
	El `MMU` está apagado -o encendido; el _kernel_, lanzará el _trampolín_, localizado  
	en `arch/powerpc/kernel/prom_init.c` para extraer el _dt_, junto a cierta información  
	del _Open Firmware_ y, construirá el _fdt_, tal y como está descrito en _b)_. 
	Por medio de un segundo método, será _reentrado_ `prom_init()`. Éste código 
	_trampolín_ correrá en el contexto del _firmware_, el cuál pretende gestionar todas  
	las excepciones durante _ese tiempo_.
	
	b. Entrada directa con _dtb_. Este punto de entrada, es llamado por _a)_, después  
	del _trampolín_ y, podrá ser llamado directamente por el _gestor de arranque_ que  
	__no soporta__ la interfase de cliente _Open Firmware_. Es también usado por `kexec`  
	para implementar el arranque en _caliente_ de un nuevo núcleo, desde otro previamente  
	_corrriendo_. Éste método está descrito un poco más adelante, en el mismo documento.  
	Cómo metodo, __a)__, _OpenFirmware_ es un simple estandar y, por lo tanto, debería  
	estar implementado, en consonancia a las vinculaciones de la plataforma _powerpc_.  
	La definición del punto de entrada, serían entonces:
	
	- `r3` : puntero físico al bloque _DT_(definido en capítulo II) en _RAM_.
	
	- `r4` : puntero físico al mismo _kernel_. Esto es usado por la propiedad del
	código ensamblador, para desactivar apropiadamente el _MMU_, en caso de estar
	_entrando_ el kernel con _MMU_ activado y, un mapa que no es `1:1`.
	
	- `r5` : `NULL`, para diferenciarlo del método __a)__.
	
	> __nota sobre la entrada SMP,__ tanto si el _firmware_, pone _la otra_ CPU en  
	> algún tipo de _bucle durmiente_ u otro _tipo de bucle en la ROM_; el cuál podrá  
	> extraerse por medio de un "reinicio suabe(soft reset)" o, de alguna otra manera.  
	> En tal caso no haríamos más caso de esto. O prodíamos entrar al _kernel_, con todas  
	> CPUs. La forma de llevar esto a cabo a través del método b) será descrita será  
	> descrita en una próxima revisión del mismo documento.
	
El soporte de placas -o plataformas, no es exclusiva de las opciones de configuración.  
Un arbitrario conjunto de soporte a placas, podrá contruirse en una sóla imagen del  
kernel. El kernel, sabe que conjunto de _funciones_ debe utilizar, en el contexto del  
árbol de dispositivo. Por lo que:

	1. Añadir soporte a _la plataforma_, como opción boleana en `arch/powerpc/Kconfig`,  
	siguiendo el siguiente ejemplo de `PPC_PSERIES`, `PPC_PMAC`, `PPC_MAPLE`.
	
	2. Crear el archivo principal para la _plataforma_ como:
	 `arch/powerpc/platforms/myplatform/myboard_setup.c` y añadirlo al `Makefile`[f4]  
	 bajo la condición de la opción `CONFIG_`. Éste archivo, definirá el tipo de estruc-  
	 tura de `ppc_md`, conteniendo distintas llamadas al código genérico que será usado  
	 en el código específico de plataforma.
	 
	 La imagen del kernel podría dar soporte a múltiples plataformas, pero sólo si las  
	 características de la misma, coinciden con la _arquitectura_.  
	 Una sóla _construcción_ -la imagen, no puede dar sopoerte en ambos casos: esto es  
	 sobre una configuración tipo `Book E` o el clásico `powerPc`.  

#### <a name="i1i3">Punto de entrada para `arch/x86`</a> ####

Existe un sólo punto de entrada de `32bit` para el código del kernel en `code32_start`,  
el "de-compresor" -el modo, _punto de entrada real_, va al mismo punto de entrada de  
`32bit`, una vez _intercamiado_ al modo _protegido_. El punto de entrada soporta una  
convención de llamada -o llamada canónica, documentada en `Documentation/x86/boot.txt`.  
El puntero físico al bloque del árbol de dispositivo -definido en capítulo II, es  
_pasado_ vía `setup_data`, cuya función requiere, por lo menos, de la versión `v2.09`.
El tipo de campo es definido como:

`#define SETUP_DTB                      2`

Tal árbol de dispositivo es utilizado como extensión a _página de arranque_. Ya que no  
traduce `/`(ruta raíz), considera los datos _de hecho_, cubiertos por la _página de_  
_arranque_. Ésto incluye el tamaño de memoria, rangos reservados, argumentos de _línea_  
y direcciones `initrd`. Simplemente conserva infromación que de otra forma no sería  
recuperada, como enrutado de interrupciones o, una lista de dispositivos detrás del  
bus `I2C`.

#### [Punto de entrada para `arch/mips/bmips`](i1i4) ####

Algunos gestores de arranque, soportan un sólo punto de entrada, al principio de la  
imagen del kernel[f5]. otros gestores podrán _saltar_ inicio de la dirección `ELF`.  
Ambos esquemas están soportados; `CONFIG_BOOT_RAW=y` y `CONFIG_NO_EXCEPT_FILL=y`, así  
la primera instrucción _salta_ inmediatamente a la función _kernel_entry()_.

Similar al caso `arch/arm`(b), la advertencia del _DT_ -por parte del gestor, espera  
configurar los siguientes registros:

		a0 : 0

		a1 : 0xffffffff

		a2 : puntero físico al bloque del árbol de dispositivo -definido en el capítulo II,  
		en RAM. El árbol de dispositivo podrá localizar en cualquier lugar, los primeros
		`512MB` del espacio de dirección física (0x00000000 - 0x1fffffff), alineados con 
		el límite de 64 bit.
		
El gestor legado, no utilizará ésta convención, y no lo pasará al bloque _DT_. En éste  
caso Linux la própia construcción del _DTB_, seleccionada vía `CONFIG_DT_*`

Convención definida únicamente para sistemas de `32-bit`, puesto que actualmente no hay  
un implementación `64-bit BMIPS`.

#### <a name="i1i5">Punto de entrada para `arch/sh`</a> ####

La compatibilidad del _DT_ con gestores _SH_, prevée proporcionar una dirección física  
al péqueño árbol de dispositivo en `r4`. Dado que éstos gestores legados, no garantizan  
un _registro   de  estado_  inicial  en  particular,  el  kernel  está  contruido para  
_inter-operar_ con anteriores gestores, que deberán utilizar una _construcción DTB_ o,  
seleccionar una opción de placa _legada_ -distinta a `CONFIG_SH_DEVICE_TREE`, que no  
use el árbol de dispositivo. El soporte a ésto último, ha sido deferido en favor del  
árbol de dispositivo.

#### <a name="i2">El formato de bloque en _DT_</a> ####

El capítulo, define el actual formato _nivelado_, para el árbol de dispositivo pasado  
al kernel. Su contenido y requisitos, serán descritos posteriormente. Podrá encontrarse  
ejemplo de código que utilizan éste mformato, en distintos lugares, incluidos:  
`arch/powerpc/kernel/prom_init.c`, el cuál genera un árbol de dispositivo a nivel de  
representaciones _OpenFirmware_ o, la utilidad `fs2t`, parte de las herramienta `kexec`  
que generá _una_, desde la representación del sistema de ficheros.
Es previsible que gestores como _Uboot_, proporcionen algo más de soporte, igualmente  ç
discutido en adelante.

> __nota:__ el bloque debe estar en la memoria principal. Debe ser accesible desde el  
> modo _real_ y _virtual_, sin ningun otro mapa, que el de la memoria principal. Si  
> se escribe un gestor _flash_, debería copiarse el bloque a la RAM, antes de pasarlo  
> al kernel.

#### <a name="i2i1">Cabecera</a> ####

El kernel pasa la dirección física, apuntando a un área de memoria descrita aproxima-  
damente en `include/linux/of_fdt.h`, por la estructura `boot_param_header`:

		struct boot_param_header {
						  u32     magic;                  /* magic word OF_DT_HEADER */
						  u32     totalsize;              /* total size of DT block */
						  u32     off_dt_struct;          /* offset to structure */
						  u32     off_dt_strings;         /* offset to strings */
						  u32     off_mem_rsvmap;         /* offset to memory reserve map
						                                     */
						  u32     version;                /* format version */
						  u32     last_comp_version;      /* last compatible version */

						  /* version 2 fields below */
						  u32     boot_cpuid_phys;        /* Which physical CPU id we're
						                                     booting on */
						  /* version 3 fields below */
						  u32     size_dt_strings;        /* size of the strings block */

						  /* version 17 fields below */
						  u32	size_dt_struct;		/* size of the DT structure block */
		};

Junto a las constantes:

		/* Definitions used by the flattened device tree */
		#define OF_DT_HEADER            0xd00dfeed      /* 4: version,
									 4: total size */
		#define OF_DT_BEGIN_NODE        0x1             /* Start node: full name
									 */
		#define OF_DT_END_NODE          0x2             /* End node */
		#define OF_DT_PROP              0x3             /* Property: name off,
				                                               size, content */
		#define OF_DT_END               0x9

Todos los valores de la cabecera son escritos en formato _big endian_, los distintos  
campos en la _cabecera_ son definidos con detalle más abajo. Todos los valores `offset`  
-_de compensación o referencia_,   son expresados en  `bytes`  desde el principio de la  
_cabecera_; esto es la dirección física base, del bloque DT.

- `magic`   es un valor que _marca_ el principio de bloque DT de cabecera. Contiene el  
valor `0xd00dfeed` y es definido por la _constante_ `OF_DT_HEADER`.

- `totalsize`   es el tamaño total del bloque DT,  incluida la cabecera. El bloque DT  
debería _encerrar_ todos los datos de estructura definidos en este capítulo -quien es  
apuntado por el `offset` en la cabecera. Esto es, la estructura DT, cadenas y, el mapa  
de memoria reservada.

- `off_dt_struct` es un `offset` desde el principio de la cabecera, al comienzo de la  
estructura de datos, parte del DT. Ver _2) árbol de dispositivo_.

- `off_dt_strings` es un `offset` desde en comienzo de la cabecera al principio de las  
`strings`(cadenas), parte del DT.

- `off_mem_rsvmap`   es un `offset` desde el principio de la cabecera al comienzo  del  
mapa de memoria reservada. Este mapa es una lista de pares _enteros_ de `64-bit`. Cada  
par,   es un tamaño y una dirección física.  La lista es terminada por una  entrada de  
tamaño `0`. Este mapa aprovisiona al kernel, con una lista de _áreas físicas de memoria_  
que   son reservadas y, por tanto, no serán usadas para la asignación de memoria,  en  
especial, durante la _inicialización temprana_. El kernel necesita asignar memoria,  
durante   el arranque, para cosas  como el _desnivelado_ en el DT, la asignación   de   
_tablas MMU hash_,   etc. Dichas asignaciones, deben estar hechas de tal manera,  que  
 pueda evitarse sobreescribir datos críticos en, _Open Firmware_, _capable machine_,  
la instancia _RTAS_, o sobre _pSeries_, las tablas _TCE_, usadas por iommu. El mapa  
reservado, debería contener -al menos, el bloque DT en sí mismo -cabecera, tamaño total  
Si se está pasando al kernel un `initrd`, debería reservarse igualmente. Es innecesario  
reservar la imagen del kernel. El _mapa_ debe estar alineado a `64-bit`.

- Version.   Es la versión de la estructura. La versión 1, termina aquí.  La versión 2  
añade un campo adicional `boot_cpuid_phys`. 
La versión 3,   añade el tamaño del bloque cadenas, permitiendo al kernel  reasignarlo  
fácilmente  durante el arranque y, liberar(memoria), la estructura nivelada no  utili-  
zada, después de la expansión. La versión 16, un nuevo y, más compacto formato, para el  
árbol en sí mismo, -de alguna manera, no es compatible con los anteriores. Versión 17,
añade un campo adicional, `size_dt_struct`, permitiendo reasignarla o moverla, aún mas  
facilmente.   Es particularmente útil para los  _gestores de arranque_, que  necesitan  
hacer ajustes al DT, basados sobre información probada. Siempre debería generarse una  
estructura, con el número de versión, más alto, hasta la fecha de la implementación.  
Actualmente,   es la versión 17, a menos que, explícitamente, convenga por razones  de  
compatibilidad.

- `last_comp_version`.   Última versión compatible. Indica esto, hasta qué version -con  
anterioridad,   es compatible el bloque DT. Por ejemplo, versión 2,   es anteriormente  
compatible   con la versión 1 -esto es, la construcción del kernel para la  versión 1,  
podrá  arrancar con el mformato de versión 2. Debería ponerse un `1` en este campo  si  
fue generado un DT con version de `1` a `3`, o `16` si fué generado un DT con versión  
`16` o `17`, usando el nuevo formato de nombre de unidad.

- `boot_cpuid_phys`. Este campo sólo existe en las cabeceras de la _versión 2_. Indica  
cual ID (identificador)   de CPU, está llamando al punto de entrada del kernel.   Es  
utilizado,  entre otros, por `kexec`. Tratándose de un sistema SMP, el valor  debería  
coincidir con el contenido de la propiedad `reg`, del nodo CPU, en el correspondiente  
DT, que hace la llamada al punto de entrada del kernel. Ver capítulos secesivos, para  
más información sobre los requisitos del contenido DT.

- `size_dt_strings`. Este campo sólo existe en la _versión 3_ y, posteriores.  
Proporciona el tamaño de la sección `strings`, del DT. Empieza en el `offset` dado  
por `off_dt_strings`.

- `size_dt_struct`. Aparece únicamente en la _versión 17_ y, posteriores cabeceras.  
Proporciona el tamaño de la sección _estructura_, DT. Empieza en el _offset_ dado por  
`off_dt_struct`.

El  diseño -capa, habitual de un bloque DT -aunque las distintas partes no  necesiten  
estar en ese orden, son similares a esto:

             ------------------------------
     base -> |  struct boot_param_header  |
             ------------------------------
             |      (alignment gap) (*)   |
             ------------------------------
             |      memory reserve map    |
             ------------------------------
             |      (alignment gap)       |
             ------------------------------
             |                            |
             |    device-tree structure   |
             |                            |
             ------------------------------
             |      (alignment gap)       |
             ------------------------------
             |                            |
             |     device-tree strings    |
             |                            |
      -----> ------------------------------
      |
      |
      --- (base + totalsize)

> Las direcciones van desde arriba al fondo.
> (*) Los espacios de alineamiento, no están necesariamente presentes; su presencia
> y tamaño, de varios requisitos de alineamiento, en los datos de bloque individuales.








***************

#### <a name="i99">Referencias y agradecimientos</a> ####

> _nota d.t._ token, ficha, muestra, vale, bono. Aquí traducido cómo prueba
> u objeto, puesto que representa un estracto de código, como contrapartida 
> ante una previa solicitud o petición.

> nota d.t. PCI, componente de interconexión periférica.

> __ppc32/ppc64__: conjunto reducido de instrucciones, para la arquitectura creada por
> IBM, en 1992. _PowerPC_.

<a name="f1">[f1]</a>
__nota d.t.__ a medida que avance la traducción de la documentación, serán referidos  
documentos en castellano, sin embargo, se conservará el nombre de los archivos en su  
lenguaje original.  

<a name="f2">__[f2]__</a>Siglas relacionadas con el árbol de dispositivo:
* __dt__ -- device tree, árbol de dispositivo.
* __dts__ -- device tree structure??, estructura del árbol de dispositivo.
* __dtb__ -- devicee tree binary, binario del árbol de dispositivo.
* __fdt__ -- _standalone_ Flattened device tree, alineado del árbol de dispositivo??
* __dtc__ -- device tree compiler, compilador del árbol de dispositivo.

[f3]valor mágico

[f4] Makefile

[f5] kernel -- para diferenciar el núcleo del sistema operativo y evitar cuaqluier  
ambiguedad, con respecto a otras aplicaciones, por ejemplo, el núcleo de un radiador de  
calor: _a copper core_; será utilizado el término _kernel_ en adelante.

[f6] picadillo de pimientos y tomate.
- mmu -- Memory managemente Unit. Unidad de gestión de memoria.
- hash -- número identificativo único, generado por un algoritmo de cifrado. 


1. (c) 2005 Benjamin Herrenschmidt <benh at kernel.crashing.org>,
    IBM Corp.
2. (c) 2005 Becky Bruce <becky.bruce at freescale.com>,
    Freescale Semiconductor, FSL SOC and 32-bit additions
3. (c) 2006 MontaVista Software, Inc.
    Flash chip node definition
    
    
    <ul id="firma">
    	<li><b>Traductor:</b> Heliogabalo S.J.</li>
    	<li><em>www.territoriolinux.net</em></li>
    </ul>
