<?php
/*
 * Moonify Miner PHP SDK 
 */

@session_start();

$_SESSION['moonify:openSession']=null;

class Moonify {
	
	public $config=array(
		"version" => "0.1",
		"userAgent" => "Moonify PHP SDK",
		"url" => "https://api.moonify.io/0.1/"
	);

	private $integrationCode;
	public $error;
	private $rawData;

	function __construct(){

		$this->integrationCode=new stdClass();
		$this->reset();
	}	

	private function reset(){
		$this->method=null;
		$this->requestMethod=null;
		$this->item=null;
		$this->variables=array();
	}

	/*
	 * Set single parameter
	 */

	public function setParam($param,$value){
		$this->variables[$param]=urlencode($value);
	}

	/*
	 * Set multiple parameters
	 */

	public function setParams($array){
		foreach($array as $param=>$value){
			$this->variables[$param]=urlencode($value);
		}
	}

	private function setMethod($method){
		$this->method = $method;
	}

	private function setRequestMethod($method){
		$this->requestMethod = $method;
	}

	private function setItem($item){
		$this->item = "/".$item;
	}

	/*
	 * Get integration code
	 */

	public function getIntegrationCode(){
		return $this->integrationCode;
	}

	public function getRawData(){
		return $this->rawData;
	}

	public function openSession(){
		
			//set method type
			$this->setMethod("sessions");

			//get deviceID in cookies, create if null
			!empty($_COOKIE['moonify_deviceID']) ? $deviceID = $_COOKIE['moonify_deviceID'] : $deviceID = null;

			$this->setParam("deviceID",$deviceID);
			$this->setRequestMethod("POST");

			$data=$this->send();

			//error handling
			if(empty($data->error)){
				
				$this->tokenID=$data->tokenID;

				$integrationCode = '<script src="https://pkg.moonify.io/moonify.min.js"></script>';
				$integrationCode .= "<script type=\"text/javascript\">Moonify.set({tokenID : '".$data->tokenID."' });</script>";

				$this->integrationCode=$integrationCode;

			} else {
				$this->integrationCode=null;
				$this->error=$data->error;
			}

	}

	public function getUsers($userID=null){

		if($userID==null){

			//set method type
			$this->setMethod("users");
			$this->setParam("tokenID",$this->tokenID);
			$this->setRequestMethod("GET");

			$data=$this->send();

			if(empty($data->error)){
				return $data->users;
			} else {
				$this->error=$data->error;
			}

		} else {

			//set method type
			$this->setMethod("users");
			$this->setParam("tokenID",$this->tokenID);
			$this->setRequestMethod("GET");

			$this->setItem($userID);

			$data=$this->send();

			if(empty($data->error)){
				return $data->user;
			} else {
				$this->error=$data->error;
			}
			
		}
	}

	private function isCurl(){
    	return function_exists('curl_version');
	}

	public function send(){

		$this->error=null;

		//curl connection

		//url-ify POST datas
		$fieldsString="";
		foreach($this->variables as $key=>$value) { $fieldsString .= $key.'='.$value.'&'; }
			
		//test if curl is installed ?
		if($this->isCurl()){
			//open connection
			$ch = curl_init();
		
			//set curl http post method
			if($this->requestMethod=="POST"){
				curl_setopt($ch,CURLOPT_POST, count($this->variables));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fieldsString);
				curl_setopt($ch,CURLOPT_URL, $this->config['url'].$this->method.$this->item);
			} elseif($this->requestMethod=="GET"){
				curl_setopt($ch,CURLOPT_URL, $this->config['url'].$this->method.$this->item."?".$fieldsString);
			}
			
			
			curl_setopt($ch,CURLOPT_HEADER, 0);
			curl_setopt($ch,CURLOPT_USERAGENT,$this->config['userAgent']." (v. ".$this->config['version'].")");
			curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,2);

			//get data + http code
			$data=curl_exec($ch);

			$this->rawData=$data;

			$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

			if( $data === false) {
				
				$returnedData=new stdClass();
				$returnedData->error="CURL Error : ".curl_error($ch);
				return $returnedData;

			} else {
			    
			    if($httpCode==200){
				
				    return json_decode($data);
				
				} else {
				
					$returnedData=new stdClass();
					$returnedData->error="HTTP Error : ".$httpCode;
					return $returnedData;
				
				}

			}

			//close connection

			curl_close($ch);
		} else {
			return false;
		}
		
		$this->reset();

	}

}
?>