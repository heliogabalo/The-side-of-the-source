#### NX-Bit -- No-eXecute
Es usado para evitar la ejucución de código en areas de memoria
determinadas, tanto el almacenamiento de instrucciones del procesador como datos de
almacenamiento.
