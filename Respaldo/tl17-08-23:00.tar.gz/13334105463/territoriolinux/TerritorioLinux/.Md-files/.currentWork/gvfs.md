A1-so/sistemaFicheros/gvfs
## Gvfs

- GIO proporciona una API VFS(virtual file system) para aplicaciones basadas en la
librería _Glib_.

Es capaz de utilizar multitud de protocolos tanto para el control de sistemas locales
como remotos, http, dav, nfs, ftp, sftp son unos pocos ejemplos de ello. También pueden
utilizarse los mismos servicios que utilizariamos con el gestor de cuentas, desde el 
entorno gráfico instalado en el sistema.

## GIO
