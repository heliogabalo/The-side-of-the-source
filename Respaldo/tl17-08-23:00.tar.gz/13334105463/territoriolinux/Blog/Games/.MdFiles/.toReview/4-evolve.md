De los creadores de Left 4 Dead, llega éste bestial título, sorprendiendo a todo el mundo. Evolve.

Un shooter multijugador, ambientado en un mundo futurista, Shear.

Cuatro cazadores armados hasta los dientes, deberán enfrentarse al monstruo, que hará lo posible por deshacerse de ellos, con sobrenatural eficacia ...


			[video]
		[amz] [amz]
