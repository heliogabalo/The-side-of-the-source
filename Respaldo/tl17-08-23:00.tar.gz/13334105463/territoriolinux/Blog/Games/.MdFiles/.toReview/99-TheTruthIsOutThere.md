24/02/15

 No es la primera vez, que desde ésta revista EscenarioDeJuego, hayamos escrito artículos, denunciando el comportamiento deshumanizado y aberrante, de algunos individuos desaprensivos.

Personalmente, pienso que a un niño y a su imaginación, hay que protegerlos, cuidarlos, y en cierto grado, mimarlos. 


Sabemos que los niños, pueden comportarse de forma cruél, entre ellos mismos. Es por tanto, responsabilidad de los mayores, establecer las reglas del "juego".

Esta es la historia de un niño que perdió el sueño, por qué alguien sin demasiados escrúpulos, robó su cuenta "PlayStation4":


Henry, es un niño de 11 años, al que sus padres compraron una consola nuevecita, y decidió abrir una cuenta OnLine, a la que llamó "Kirmit la Rana", KirmitTHEfrog, en Inglés.

Desde la redacción de gameinformer, han recogido un mensaje, de la persona que actualmente poseé la cuenta de Henry. Para mantener el anonimato de esta persona, vamos a referirnos a él, con el nombre de Adam.


Adam, es un chico trabajador, que desafortunádamente ha sufrido una serie de desgraciados accidentes, convirtiendo su vida, en una horrible pesadilla.

Al parecer la madre de Adam, contactó con los redactores de gameinformer, para dar explicaciones, sobre la situación de su hijo.

El 1 de noviembre de 2014, el coche de Adam, colisionó frontalmente con otro vehículo. A sus 23 años de edad, Adam, permaneció convaleciente en su domicilio tras el grave accidente.


La madre, explica que durante todo el tiempo, muchos de los amigos del chico, pasaban por su casa, con el pretexto de visitarlo. Pero aprovecharon su desconcierto, pues éste, tomaba fuertes medicamentos.

Tras varios meses de reposo, Adam volvió al trabajo. Fue entonces cuando descubrió, que enormes facturas, ocasionadas por el abusivo uso de dicha cuenta "KirmitTHEfrog", amenazaban la estabilidad económica del chico y su familia.


Ahora, ninguno de los amigos, que pasaron el rato en su casa, quiere reconocer la deuda que recae sobre el chico, Adam. Todos se desentienden, dejando pendiente una factura enorme.

Los datos relativos al accidente, han podido ser constatados, tras la comprobación del atestado policial. En una conversación con los medios -soy un tipo con suerte, decía Adam, para mi, la vida es distinta ahora -añadía. Confié demasiado en la gente, que venía a pasar el rato.


Adam segura, que pasaba la mayor parte del tiempo durmiendo. Ha dejado de aceptar solicitudes o mensajes de amistad. Ha tenido cientos de ataques en la cuenta, a través de PlayStation Network.

De acuerdo con las explicaciones de la madre, Sony, esta ayudando al chico,

a hacer frente a lo que ellos consideran, ataques de acoso y amenazas.


Algunos mensajes, manifestaban serias amenazas, contra la integridad física, del chico y su familia. Otros, manifestaban el deseo de que contrajera enfermedades como el cáncer.

Es tal, el despropósito de algunos individuos, que en ocasiones la realidad supera a la ficción. Queremos pensar, que los autores de dichos mensajes, desconocían el drama familiar que estaba viviendo Adam.


Información adicional, proporcionada por su madre, desvela un terrible suceso, ocurrido unos años antes. La muerte de su hermana.

Precisamente el cáncer, la apartó de su lado. La familia tuvo que vivir unos momentos aciagos, en una lucha sin tregua, contra la enfermedad.

Lamentablemente, Adam desconoce quién borró los datos de la cuenta de Henry.

Adam reconoce que no quiere que su hermano pequeño, pase por el mismo mal trago que ha pasado Henry. Me siento culpable por lo sucedido -dice.



