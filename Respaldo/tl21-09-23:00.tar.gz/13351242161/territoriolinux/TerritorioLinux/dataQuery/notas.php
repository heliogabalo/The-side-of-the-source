https://territoriolinux.net/TerritorioLinux/dataQuery/


<?php

// ftp://ftp.wayne.edu/ldp/en/PHP-Nuke-HOWTO/config-php-file.html

// https://www.digitalocean.com/community/tutorials/how-to-install-wordpress-with-lamp-on-ubuntu-16-04

// 1.- https://www.tutorialspoint.com/php/php_mysql_login.htm
// https://www.ciudadano2cero.com/pasarelas-y-sistemas-de-pago-online/

// 2. https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php
// https://secure.php.net/manual/en/faq.passwords.php

// https://territoriolinux.net/TerritorioLinux/dataQuery/




// Create config.php:
return array(
    'host' => 'localhost',
    'username' => 'root',
);

//or

<?php
   define('DB_SERVER', 'localhost:3036');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'rootpassword');
   define('DB_DATABASE', 'database');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);


//And then:

$configs = include('config.php');


?>

ALTER TABLE info
ADD password VARCHAR(106) NOT NULL AFTER name;

ALTER TABLE `users` AUTO_INCREMENT = 1;WW


