<?php

    //Show all php Info
    phpinfo();

?>
