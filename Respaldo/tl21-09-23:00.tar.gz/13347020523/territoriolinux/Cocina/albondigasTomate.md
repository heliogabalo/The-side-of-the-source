## ALBONDIGAS CON TOMATE NATURAL

- ½ Kg.  			Carne picada  mitad y mitad  
- ½ Kg.  			Tomate rojo picado fino  
- 1           Cebolla tierna bien picada  
- 1           cucharada de piñones  
- 1           Huevo  
- 2           Rodajas de pan Bimbo mojadas en leche  
- ½ Kg.       Vaso de agua  
- 1           Manojito de perejil o cilantro  
- Sal y pimienta negra
1 hoja de laurel

## PROCEDER

Amasar en un bol la carne, el huevo batido, la pimienta, la sal y el pan bimbo.  
Sofreír la cebolla a fuego lento (evitar que se queme) y mezclar con la carne  
Ir haciendo bolas con la carne y sofreír en el mismo aceite de freir la cebolla,  
añadiendo la cantidad de aceite necesaria (Las bolas al tamaño de cada uno).  

Cuando las albóndigas estén sofritas, Apartar y reservar.  
Poner el tomate, el laurel, la pimienta y sofreir, hasta que el tomate está casi 
hecho. Ese es el momento de incorporar las albondigas y acabar de freir el tomate...  
Pasados unos 4 minutos añadir el ½ vaso de agua y dejar cociendo durante 10 o  
15 minutos a fuego lento, dejar reposar y a servir.  
