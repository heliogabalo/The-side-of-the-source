#### North Bridge
