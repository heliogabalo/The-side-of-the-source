En man initrd aparece una referencia a rdev(8), buscar página de manual.
https://www.redhat.com/en/blog/understanding-l1-terminal-fault-aka-foreshadow-what-you-need-know
