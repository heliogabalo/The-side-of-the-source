
Este mes de Marzo, hay buenos título que merece la pena echarles un vistazo. HellDiver es otro buen ejemplo. Quizás un video de muestra explique algo mas:





3dJuegos hace el análisis...










EscenarioDeJuego



