





A través del menú principal, podremos crear a nuestro personaje, modelándolo en cierto grado.

Algunas voces pueden ser seleccionadas entre unas pocas opciones y multitud de peinados característicos.

¿Alguien se imagina a un gerrero medieval con gafas de sol? ya no tendreís que forzar la imaginación. En Bladestorm : Nightmare es posible.


Dos partes principales dividen el modo historia: Cien años de Guerra y Pesadilla.

    Cien años de guerra, ofrece la misma experiencia que en el título principal. Bladestorm: The Hundred Years' War.
    Nightmare, explora una narrativa original y la posibilidad de enfrentarse a la lucha, en batallas reales simuladas. La protagoniza una malvada Juana de Arco, comandando su ejército de hechiceros y dragones. En el bando francés.


Múltiples personajes  pueden ser creados por los jugadores. Éstos personajes secundarios, aparecen como un único aliado dentro de la taberna, aunque es desplegado a modo de ejercito, una vez nos encontramos inmersos en la refriega.


Cambiar entre cuatro batallones disponibles, con un máximo de doscientos soldados, es recomendable. Organizar la escuadra no resulta demasiado complicado, pero sí, seguir visualmente a la turba enfurecida, llegando a ser algo confuso, distinguir a nuestro héroe. Siempre en el centro de la escena, claro!

Cada unidad tiene un comandante llamado Guardian. Mas fuerte que los quintos.


Las tropas consiguen acumular puntos de habilidad y, aprender nuevas tácticas de soporte. Así lo demuestra la barra de vida y experiencia al progresar. Eliminamos adversarios y avanzamos en la historia. Los puntos de habilidad son obtenidos luchando. Cuando las tropas aumentan de nivel, o tal vez, al consumir tomos de la guerra.


A lomos del corcel, sacudiendo el acero y, dando ordenes a diestra y siniestra, las líneas enemigas, caen vencidas, ante una superioridad táctica, organizada y resuelta. Sin duda, nuestra montura es un caballo de batalla, acostumbrado a arrollar enemigos sin temor a sufrir daños.


Mientras el juego avanza, aparecen distintos mini tutoriales explicando las funciones del mismo. El mapa indica los territorios conquistados, por otros señores de la guerra, con el emblema de su ejercito, grabado en el estandarte.


Completar misiones, en el modo cooperativo, cuenta como progreso, tanto en modo historia, como en éste primero.Los trofeos conseguidos, representan objetivos cumplidos satisfactoriamente, agrupados en cuatro categorias: bronce, plata, oro y platino.


En resumen, el título está bastante bien, es divertido, y la acción es continua. Si los detalles gráficos y la variedad escenográfica, acompañase a la propuesta de Akihiro Suzuki desarrollada por Atsushi Miyauchi, hablaríamos de un gran título.









Amazon

BladeStorm: Nightmare







Género: Táctico en tiempo real.

Plataformas: PC, PS3, PS4, Xbox One.

Lanzamiento: 20/03/2015.



EscenarioDeJuego
