





Nominado a Mejor juego del año (Marzo 2015)




Mode Arena :


Desbloquea todos los héroes para desbloquear el modo Arena.



Clase Mago :


Completa satisfactoriamente el tutorial, para desbloquear la Clase Mago.



Clases Extra :


Derrota una clase en modo Practice(práctica) o Play(juego), para desbloquearla.



Misiones diarias :                                                                                Hearthstone: Heroes Of Warcraft


Gana 50 partidas contra otros jugadores humanos en modo Play, para desbloquear la opción y, empezar las misiones diarias, que además tienen mejores recompensas en oro.



Cartas básicas específicas de clase (Class-Specific Basic Cards) :


Sube de nivel en la clase correspondiente. Las cartas se desbloquean en los niveles: 2, 4, 6 y 8.



Cartas oro Clase-Neutral  básico (Golden Class-Neutral Basic Cards) :


Sube hasta el nivel 60, en cada clase. Las cartas son desbloqueadas en los niveles 53-60 para los magos y guerreros y, en los niveles 51-60 para el resto de clases.



Desbloquea clases adicionales :


Derrota a la clase deseada en modo Play o Practice.



Considerar la cobertura :


Lanzar varias cartas juntas y, esperar ganar, es poco realista. Es necesario un plan. La cobertura debe reflejar la clase con la que jugamos. Hay que asegurarse de tener cartas de daño, cura, convocar a secuaces y, de mejora temporal de las capacidades o características (o  buffs).

Una ronda bien cubierta, significa ganar al héroe enemigo y ganar el oro.



Secuaces :


Los héroes pueden convocar secuaces, para ayudarlos en la batalla. Generalmente, es mejor convocar secuaces, antes de atacar al héroe. Evitará sufrir daño innecesariamente y, podrá medirse la cantidad de energía necesaria en todo momento.




Como conseguir el "WoW Hearthsteed Mount" (Montura de Élite) :


¿Quieres conseguirlo? es fácil.

1.- Para desbloquear la montura, gana 3 partidas de Hearthston(piedra de hogar). Cuenta tanto en modo Play como Arena.

2.- Obtener 3 victorias significará conseguir la recompensa que buscaba "Arriba montura!!"

3.- Habrá que desconectarse del juego y volver a conectar. Entonces recoger el premio en el buzón.


Desbloqueando esta montura gratis, también premia con el logro "Hearthstoned" a toda la cuenta Battle.net.






Invertir en Oro :


Evitar gastar las primeras 100 monedas de oro en paquetes de cartas de experto. En su lugar, invertirlo en en la entrada a la Arena. Incluso perdiendo, se conseguirán nuevos paquetes de cartas y algo de polvo Arcano. Ganar un par de partidas resultará en una inversión muy gratificante.



Héroe Jaina Proudmoore :


Completar satisfactoriamente el tutorial para desbloquear éste héroe.



Golden hero frames :


Ganar 500 partidas en modo Play clasificado, con el correspondiente héroe lo desbloquea.





EscenarioDeJuego
