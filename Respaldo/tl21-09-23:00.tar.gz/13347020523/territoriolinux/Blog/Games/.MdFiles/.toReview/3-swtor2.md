
  Star Wars: The Old Republic


Hay muchas formas de mantener a tu personaje bien equipado y listo para el combate.

A medida que el personaje sube de nivel, también lo hacen sus habilidades, así que utilizar

las mejores herramientas, para comprobar la eficacia de sus golpes, es casi un requisito

imprescindible.


En la siguiente lista de enlaces, podreis calcular de forma rápida y sencilla, como distribuir

los puntos de talento de vuestros heroes y villanos.

    Torhead
     KnoTOR
    Darth Hater DB
    Prima Guides
    SWTOR Spy
    R2-DB


Siéntete libre de probar, cambiar o midificar, esos talentos que tanto trabajo ha costado

conseguir. Dedica unos minutos, a estudiar la mejor forma de sacar rendimiento de tu hoja

de talentos, y conviértete en la envidia de todos.





