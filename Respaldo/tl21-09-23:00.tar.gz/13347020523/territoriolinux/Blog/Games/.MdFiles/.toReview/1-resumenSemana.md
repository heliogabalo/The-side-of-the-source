
Resumen Semanal.


Esta semana quiero destacar el trabajo del equipo de God of War, que ha demostrado a todo el mundo

que la imaginación y creatividad, son cosas del pasado, pero también del presente.

Pandora, Zeus, El hades... El mismísimo Omero, vendría a felicitar al equipo, por su magnífico trabajo, en la recreación visual, de algo que para muchos, permanecia oculto en algún lugar de su imaginativa y recurrente psique.


Entre todas las cartas que han llegado a la redacción de Jugones.Punto.Com, y son muchas, cabe destacar una especialmente. El autor ha pedido, no ser revelada su identidad, así que respetaremos su petición muy a pesar de las constantes peticiones de otros lectores más curiosos.


Jugones.Punto.Com, estrena esta semana la guía rápida de temas, o barra de navegación. Hemos diseñado una barra de navegación, muy visual, que ayudará al lector, a desplazarse por el blog, de manera rápida e intuitiva.

Tal y como aparece, la leyenda de los recursos puede interpretarse así:


- Home- página principal.

- La estrella- Destacados, el resumen de lo más visto y valorado durante la semana.

- Vídeos- la lista de vídeos completa.

- Charkleons- no salga nunca de casa sin ella. Una web donde podrá el lector, encontrar una lista casi infinita de recursos de red.

- Facebook, Youtube, Twitter - presencia en las redes sociales.

- Software- aquí se colgarán todos aquellos enlaces a software y shareware, que ayudará a mantener el equipo informático, en condiciones óptimas. La lista irá actualizándose por lo que personalmente, aconsejaría a todo el mundo a darse una vuelta por el site, de vez en cuando.





