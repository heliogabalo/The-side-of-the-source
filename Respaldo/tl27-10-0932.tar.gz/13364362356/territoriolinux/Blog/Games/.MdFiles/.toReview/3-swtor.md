

Qué es Star Wars: The Old Republic?



Star Wars: The Old Republic es una historia basada en la saga Star Wars. El jugador deberá encarnar una de las muchas razas propuestas. Caballeros Jedi, Señores Sith, Bounty Hunters y más. Enfrentándote a grandes desafíos y, tomando decisiones que determinaran tu camino, embarcarás a tus personajes en una aventura épica.


Disfruta de la experiencia desde el principio, tanto si empiezas en el sistema multijugagor, como si eres un consumado veterano. En esta guía, encontrarás todo lo que necesites saber, antes de empezar tu viaje.




Sistema Multijugador


El multijugador o MMO, de sus siglas en inglés "Massively Multiplayer Online", requiere una conexión a intertet, en todo caso. Piensa que tu PC. es una ventana, dentro de la Vieja República Galáctica. La galaxia en si misma, existe entre la vasta red de ordenadores y, tu PC abre la puerta para que puedas entrar.


Multijugador, no significa otra cosa, más que compartir un espacio de juego, con otros miles de jugadores.De hecho, podrás ver a otros jugadores, poco después de tu primera conexión.


Podrás unirte a ellos en cualquier momento. Aunque si lo prefieres, podras seguir tu propio camino, con muchas partes del juego, énteramente a tu disposición. Por otro lado, mucho del contenido avanzado, está orientado a grupos, así que únete a tus amigos, y dales una oportunidad.


 





Jugando a Rol


Para crear a tu Heroe en Star Wars: The Old Republic, empezarás con una de las ocho clases de arquetipos, Cada personaje tiene sus própio estilo, características, e interacciona con la historia de forma única.


Cuando juegues sólo, el Rol que escojas,  determinará completamente la experiencia de juego. Si escoges jugar como Caballero Jedi, jugarás a través de la historia de los Caballeros Jedi, haciendo frente a los enemigos, con el sable laser y el poder de la fuerza.


Cuando te unas a otros jugadores, la elección de clase, también determinará el rol de tu personaje dentro del grupo. Para alcanzar algunos de los desafios en la Vieja República, el equipo deberá jugar coordinado, donde cada clase, tiene sus puntos fuertes y debilidades.

Un grupo debería incluir tantas clases distintas como sea posible. Esto significa, que si estás planeando jugar con amigos, deberíais coordinaros, para escoger distintas clases. Esto, ayudará al equipo a trabajar mejor, y será más dibertido, puesto que podreis conocer cada una de las clases, dentro y fuera del combate.




El Camino...


En Star Wars™: The Old Republic™, podrá explorarse el rico y extenso universo Star Wars™, tres mil años posterior, a los hechos ocurridos en Star Wars: Knights of the Old Republic™.

En esa era, la galaxia estaba dibidida entre la legendaria República Galáctica y El Lado Oscuro del Imperio. En todas partes reinaba el desasosiego y la incertidumbre. Revueltas civiles, guerras de gansteres y golpes militares, habían generado confusión y conflictos en incontables mundos. Y la frágil paz, entre la República y el Imperio, amenazaba con escribir un título de guerra, para éste período galáctico.



Alianzas


Todo el mundo debería saber donde yace su alinza...




El Imperio Sith, después de miles de años, vuelve desde el exílio.Reclama su planeta de origen en Korriban y, ha conquistado cientos de sistemas solares por toda la galaxia.El Imperio es ahora más fuerte que nunca. Preparado para disolver la tregua con la República, finalmente espera alcanzar su venganza, sometiendo a toda la galaxia, a un dominio imperial.


La República Galáctica, con la ayuda de la orden Jedi, ha permanecido como bastión de paz y tranquilidad durante mas de veinte mil años. Aunque la República ha sido debilitada por una larga y costosa guerra contra el Imperio Sith, permanece fuerte.

Las cicatrices de la última guerra empiezan a sanar y, una nueva generación está preparada para enfrentarse a la amenaza, y defender la República.



Tu saga empieza aquí...





