
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Agony | MadMind Std | http://agonygame.com/ | 300318 | T8 | email-contact | options | ps4-xb1-pc | 11 |
| The Sinking City | frogwares | http://frogwares.com/games/#The_Sinking_City | tba | ? | marketing@frogwares.com | options | PS4,Xbox One,PC | ? |
| The Blackout Club | questionGames | https://www.blackoutclubgame.com/ | 2019 | ? | email-contact | options | PS4,Xbox One,PC | 14 |
| Death Stranding | Kojoma Prod. | http://www.kojimaproductions.jp/en/#index | 18/19 | T3 | email-contact | options | PS4,PC | 14 | 
| Over kill the Walking Dead | Overkill | overkillthewalkingdead.com | 2018 | BG-T3 | email-contact | options | Xb1 PS4 Steam | 20 |
| Gray Dawn | Int. Stone | http://gray-dawn.com/ | 2018 | T8 | hello@interactivestone.ro | options | tba | 21 |

| Daemonical | Fearem | https://fearem.com/ | 2018 | ? | info@fearem.com | pre(steam) | pc | ? |
| World War Z | Saber Int. | www.wwzgame.com | 2018 | ? | email-contact | options | plataforma | week nº |


---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
