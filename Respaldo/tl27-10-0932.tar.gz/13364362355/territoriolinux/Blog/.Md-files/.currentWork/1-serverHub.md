[Server hub](#i1)

[curiosidades](#i88)
[Referencias y agradecimientos](#i99)


### [Server hub](i1) ###

Iniciamos una serie de artículos, dedicados al multiplexador tmux. 
En la sección _curiosidades_, trataremos de acercarnos al mundo del videojuego, desde una perspectiva distinta, a como lo veniamos haciendo hasta el momento. Es _posible_ que esto sea el principio de algo GRANDE. 




### [curiosidades](i88) ###

__Servidores de videojuegos ...__


[Referencias y agradecimientos](i99)

Como es costumbre en Territorio Linux, os dejamos una lista de _fuentes_ que hemos utilizado
-en ingles, _of course_, para construir nuestro "hub". También habilitaremos ciertos enlaces relacionados con material didáctico.

- [Use tmux for a more powerfull terminal](https://fedoramagazine.org/use-tmux-more-powerful-terminal/)
- [4 tips for better tmux sessions](https://fedoramagazine.org/4-tips-better-tmux-sessions/)
- [Add power to your terminal with powerline](https://fedoramagazine.org/add-power-terminal-powerline/)
- [Run a minecraft server with spigot](https://fedoramagazine.org/run-a-minecraft-server-using-spigot/)

- [tmux 2](https://pragprog.com/book/bhtmux2/tmux-2)
- [Documento _oficial_ tmux](http://man.openbsd.org/OpenBSD-current/man1/tmux.1) - igual hasta lo traducimos!
