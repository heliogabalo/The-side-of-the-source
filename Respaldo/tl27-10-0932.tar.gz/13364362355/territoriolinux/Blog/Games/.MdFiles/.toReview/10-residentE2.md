

 Resident Evil: Revelations 2


Su lanzamiento está programado para marzo de 2015. Algunas fuentes indican que será sobre el día 20, aunque precisar la fecha exacta resultaría arriesgado, ya que desde EscenarioDeJuego no disponemos de mas referencias que aclaren este dato.


La historia sitúa los acontecimientos, en un centro penitenciario de una isla abandonada. Alternando elementos de acción y disparos, exploración y rompecabezas.

El porqué de aparecer en el centro penitenciario, a principios de la aventura, habrá que ir descubriéndolo a lo largo de la misma.


Modo Campaña


En el modo campaña hay dos hilos principales:


-Claire Redfield y Moira Burton.

-Barry Burton y Natalia Korda.


Claire empieza buscando a Moira, que permanece atrapada en una de las celdas, "voy a sacarte de ahí como sea" -dice Claire. Esperemos que viva.

Los primeros minutos son de estilo tutorial.

El episodio uno, puede ser superado en 3 horas aproximadamente.


Claire es el componente armado del grupo, mientras que Moira se ocupa de todo lo que tiene que ver con la exploración. Dotada con una habilidad de percepción, mucho más eficaz que su compañera, es capaz de detectar objetos ocultos y deslumbrar a los enemigos con una simple linterna ...


El formato secuencial, que ha elegido Capcon, para lanzar los episodios de Resident Evil: Revelations 2, se divide en cuatro partes. Serán distribuidas digitalmente, y en un futuro podrá conseguirse en formato físico, con todas las partes juntas.

Todo señala al 20 de marzo, fecha oficial de lanzamiento del juego, con soporte en CD o disco.


Modo Asalto


Está más dirigido a la acción. Mejorar puntuaciones, matar enemigos, competir en los rankings online y superar nuestras puntuaciones y la de otros jugadores.

En el vestíbulo podremos seleccionar a nuestro personaje, adaptándolo a las preferencias de cada cuál.

También podrán desbloquearse otros personajes, a medida que avancemos en el modo.


El menú principal, incluye armas, gestos y trajes elegibles. Hay que pasar unos minutos en la campaña antes de desbloquear esta modalidad extra. En el modo asalto, los disparos sobre los enemigos, hacen aparecer los daños en forma de etiquetas, sobre el protagonista. También aparece la barra de vida, mostrando el nivel del enemigo


Las reglas del juego


Como siempre, Resident Evil enfoca su temática dentro del género de Terror. Algunos lo llaman Survival Horror. Esto es así, desde que en 1996, Resident Evil publicase la primera entrega de la franquicia.

Es entonces cuando fue acuñado el término, Survival Horror.  Debido a la gran popularidad que alcanzó el videojuego, otros, de similar argumento, terminaron por ser adscritos al mismo.


Desde EscenarioDeJuego, vamos a seguir utilizando el término terror, que por decirlo de alguna manera, es "apto para todos los públicos".

Así es, un videojuego de terror, que no dejará indiferente a fieles seguidores de la saga y, aguerridos iniciados que pretendan poner a prueba su temple o talante.


Es cierto que pudiesen echarse de menos, escenas terroríficas e inquietantes, muy presentes en otras entregas anteriores. Sin embargo, no hay que olvidar que las escenas violentas, sangrientas y forzosamente brutales, siguen apareciendo en escena. Por esta razón debemos observar, que hay que leer el dorso de los productos -en general, antes de consumirlos. Éste, es uno de esos, que está específicamente dirigido a público adulto.







Resident Evil: R2


















Género: Survival Horror, Terror, Acción.

Plataformas: PC, PS3, PS4, Xbox 360 y Xbox One.

Fuente: 3dJuegos







EscenarioDeJuego
