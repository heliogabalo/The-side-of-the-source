Resident Evil: Revelation - Truco

 

 

Códigos de [residentevil.net]:  



Debe registrarse una cuenta Capcon en Residentevil.net y establecer un enlace con la cuenta de juego. Ahora cuando introduzcas los siguientes códigos (distingue mayúsculas y minúsculas) en residentevil.net,

la correspondiente bonificación, será activada en el juego.


nota: algunos códigos podrían expirar antes que otros. Habrá que introducirlos nuevamente, para que continúe su efecto. Hay que introducir los códigos sin comillas.



M92F Level 1 Slot 4                              - Introducir 'abyss'

G36 'Light Weight' Level 3 Slot 4           - Introducir 'albert'

M92F 'Short Range' Level 1 Slot 3         - Introducir 'beach'

Pale Rider Level 3 Slot 5                        - Introducir 'bioterrorism'

M92F 'Easy Grip' Level 3 Slot 4             - Introducir 'dido'

P-90 Level 1 Slot 6                                - Introducir 'farfarello'

Windham Level 1 Slot 4                         - Introducir 'ghiozzo'

PC356 Level 1 Slot 6                            - Introducir 'globster'

M40A1 'Speed Load' Level 3 Slot 4      - Introducir 'hell'

L. Hawk 'Short Range' Level 1 Slot 2    - Introducir 'herb'

G36 'Speed Shot' Level 5 Slot 5            - Introducir 'keith'

L. Hawk Level 1 Slot 3                         - Introducir 'lansdale'

L. Hawk 'Short Range' Level 5 Slot 4   - Introducir 'mayday'

Muramasa Level 3 Slot 6                     - Introducir 'originaleleven'

M3 'Easy Grip' Level 1 Slot 3              - Introducir 'promenade'

P-90 'Short Range+' Level 5 Slot 6      - Introducir 'queen'

Python Level 3 Slot 5                           - Introducir 'revelations'

Python 'Short Range+' Level 3 Slot 4    - Introducir 'scagdead'

Python 'Speed Load' Level 5 Slot 5      - Introducir 'unveiled'

High Roller 'Speed Load' Level 1 Slot 5 - Introducir 'zombie'



Desbloquear Armas


Completa las siguientes tareas para desbloquear la correspondiente arma.


PC356 Handgun     - Derrota 150 enemigos.

Hydra Shotgun        - Completa el juegoen dificultad Normal o superior.

Infinite Launcher      - Completa el juego en modo Infierno(pesadilla).





EscenarioDeJuego
