## Ser objetivo, las Roms

>> __Identificaión de los dispositivos susceptibles__
>> Al margen de la capacidad económica o cualquier otro criterio técnico, en un equipo  
>> siempre vamos a encontrar un número finito, de alternativas susceptibles de ser  
>> objeto de cambio.  
>> Por lo tanto, el conocimiento de los distintos dispositivos, es una cuestión  
>> primaria a la hora de ejercer un control sobre nuestro sistema.  

>> La historia de la humanidad, ha demostrado que el desconocimiento es siempre objeto  
>> ideático, llevado hasta el extremo de una condición superior o superlativa. En este  
>> marco, no es más que un cuestión de tiempo, el que religiones e ideas políticas,  
>> terminen por caer en un profundo olvido o desuso, debido a su propia naturaleza  
>> imperfecta o desfuncional.  

>> Nos hemos acostumbrado a idealizar al _hacker_ informático o _pirata_, como un  
>> Dios de la lógica de sistema, siguiendo el esquema que ha imbuido la psique humana,  
>> desde el tiempo en que los acólitos, practicaban una fé ciega e irracional, sobre  
>> una doctrina impuesta; con objeto de ejercer un control sobre las masas incautas o  
>> desprovistas.  

>> - Roms  
>> - Rams  
>> - Otros dispositivos de almacenamiento.  

>> Los líderes mundiales, han apostado siempre por un desarrollo técnico que condugese  
>> a sus seguidores y a su discplina, hacia un lugar preferente, capaz procurar una  
>> ventaja mesurable, sobre el enemigo u objetivo en disputa.  

>> Así, nacieron las _Roms_. Con la necesidad de cargar una matriz de sistema, capaz de  
>> ejecutar un _plan_, dificilmente alterable. Memoria de sólo lectura. Algo que pude  
>> leerse, y no puede ser alterado en ningún otro sentido.  

>> Y es así, como su própia decepción, marca el curso de los acontecimientos. Con más  
>> pena que gloria...
>> 						El despertar de la plegaria, Timoteo threephboot.
