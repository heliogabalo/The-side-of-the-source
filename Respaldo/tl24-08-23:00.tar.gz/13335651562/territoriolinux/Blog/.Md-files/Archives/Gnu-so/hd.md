
1. El disco duro
2. El Mbr
2. Tabla de particiones
2. Espacio vacío
3. Particionado de disco
4. Formateo de disco
5. EXPERIMENTAL
  - Técnicas de particionado y formateo
      - Sobre la superficie física de disco
      - Sobre una imagen creada como archivo
6. Agradecimiento
