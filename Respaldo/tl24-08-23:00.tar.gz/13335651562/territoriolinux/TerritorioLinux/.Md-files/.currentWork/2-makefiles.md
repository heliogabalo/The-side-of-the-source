[Tabla de contenidos](#i1)
[Introducción](#i2)
[Quién hace qué](#i3)

[Referencias y agradecimientos](#i99)
--- 

## _Makefiles_ en el kernel de Linux ##

El codumento describe los archivos _Makefiles_ en el kernel de Linux.


### [Tabla de contenidos](i1) ###

- Introducción
- Quién hace qué
- Los archivos _kbuild_
  -	Definición de objetivos
  - Archivos _objeto_ integrados `obj-y`
  - Propósito de los módulos _cargables_ `obj-m`
  - Objetos que exportan _símbolos_
  - Propósito de los archivos _librerías_ `lib-y`
  - Descendiendo a los directorios
  - Compilación de opciones
  - Dependencias de la línea de comandos
  - Seguimiento de las dependencias
  - Reglas especiales
  - Soporte a las funciones `$(CC)`
  - Soporte a las funciones `$(LD)`
- Soporte a programas _Host_
  - Programas _Host_ simple
  - Composición de programas _Host_
  - Empleo de `C++` en programas _Host_
  - Control de las opciones del compilador en programas _Host_
  - Cuándo son construidos los programas _Host_
  - Utilización de `hostprogs-$(CONFIG_FOO)`
- _Kbuild_, infraestructura _limpia_
- Arquitectura de archivos _Makefiles_
  - Configuración de variables, para complementar la construcción de la arquitectura
  - Añadir _prerrequisitos_, a `archheaders:`
  - Añadir _prerrequisitos_, a `archprepare:`
  - Listar directorios que visitar, al descender
  - Imagenes de arranque, específicos de la arquitectura
  - Construcción de objetivos _no-kabuild_
  - Comandos útiles, en la construcción de una imagen de arranque
  - Comando _kbuild_ personalizados
  - Procesando _scripts_ del enlazador
  - Archivos genéricos de cabecera
  - Pasar enlaces _post-link_
- Sintaxis _kbuild_ en cabeceras exportadas
  - Cabeceras no exportables
  - `generic-y`
  - `generated-y`
  - `mandatory-y`
- Variables _kbuild_
- Lenguaje _Makefile_
- Créditos
- `TODO`
  

### [Introducción](i2) ###

Los archivos _Makefiles_ contienen cinco partes:

_Makefile_ 												El principio del archivo.
`.config` 													el archivo de configuración del kernel.
`arch/$(ARCH)/Makefile`  la arquitectura del archivo _Makefile_.
`scripts/Makefile.*`				  reglas comunes etc. para todos los archivos _Makefiles_ en kabuild.
_kbuild Makefiles_						son cerca de 500.

Al principio del archivo Makefile, será leído el archivo `.config`, el cuál proviene del proceso de configuración del kernel.

El principio del archivo, es responsable de la construcción de dos _elementos_ importantes:
`vmlinux`, la imagen residente del kernel y, los módulos -cualquier archivo de módulo.
Todo esto es construido de manera recursiva, descendiendo a los subdirectorios en el _árbol fuente_ del kernel.
La lista de subdirectorios _visitada_, dependerá de la configuración del kernel. El principio del archivo, incluye textualmente, una arquitectura _Makefile_, con el nombre `arch/$(ARCH)/Makefile`. La arquitectura Makefile, porporciona información específica, acerca de la misma indicada al principio del archivo.

Cada subdirectorio, tendrá un _kbuild Makefile_, el cuál sucede los comandos, de forma secuencial; _de arriba a abajo_. El archivo _kbuild Makefile_, utiliza la información del archivo `.config`, para constuir varias listas de archivos, utilizadas por kbuild, para constuir cualquier objetivo modular integrado en la construcción.

`scripts/Makefile.*` contiene todas las definiciones/reglas etc. usada en la construcción del kernel, basado en los archivos _kbuild Makefiles_.


### [Quién hace qué](i3) ###

Las personas, tienen cuatro _relaciones_ distintas, con los Makefiles del kernel.

__Usuarios__: personas que construyen kernels. Aquellos, que escribirían comandos tales como; `make menuconfig` ó `make`. Es habitual que no lean o editen ningún _Makefile_ del kernel -o cualquier otro archivo fuente.

__Desarrollador regular__, trabajan en características tales, como _controladores de dispositivo_, _sistemas de archivo_ y, _protocolos de red_. Estas personas, necesitan _mantener_ los archivos , del subsistema en el que tabajan. Para llevar a cabo esta tarea, es necesario cierto conocimiento acerca de los archivos kbuild Makefiles, además de otros aspectos relacionados con la interfase pública de kbuild.

__Desarrollador de arquitectura__, persnas que trabajan en una _plataforma_ en particular. Como `sparc` o `ia64`. Los desarrollador de plataforma, necesitan conocer tanto el Makefile como los archivos kbuild Makefiles relacionados.

__Desarrollador kbuild__,  trabajan en el _sistema de construcción del kernel_, en sí mismo.
Imprescindible conocer todos los aspectos relativos a los archivos Makefile del kernel.

El presente documento está dirigido al __Desarrollador regular__ y al __Desarrollador de arquitectura__.








[Referencias y agradecimientos](i99)

Objeto, 


---

<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
