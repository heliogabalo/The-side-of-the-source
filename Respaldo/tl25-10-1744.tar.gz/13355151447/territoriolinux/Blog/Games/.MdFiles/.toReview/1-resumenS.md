 Esta semana queremos adelantaros una noticia que sin duda, va a dar de que hablar.

Para no desvelar la sorpresa, solo vamos a decir, que hemos entrevistado a un grupo de desarrolladores

made in Spain, que acaba de terminar uno de sus proyectos mas innovadores y frescos, que seguro, hará las delicias de muchos de sus fans.

Se trata de un juego innovador y lleno de imaginación, donde los participantes tendrán que poner a prueba su ingenio y mucho más...





    Angry Birds mantiene el tipo.
					
					[video]

    Wasteland 2 actualiza el motor de juego "Unity 5". 3dJuegos lo explica.
    GameInformer, comenta la jugada.
    Evolve patch 1.1: Xbox corrige un error al guardar datos de juego.
    Inminente lanzamiento del último capitulo de Battlefield.




















http://escenariodejuego.blogspot.com
