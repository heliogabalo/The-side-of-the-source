11/03/15

Si llegasteis tarde, a la presentación de Gran Turismo®6, esta es vuestra oportunidad de revivir el acontecimiento.




En mayo de 1998, apareció el primer Gran Turismo, llegando a convertirse en el buque insignia de Sony PlayStation.

Uno de los puntos fuertes que ha estado siempre presente en Gran Turismo, es el detalle gráfico, que cautivó a muchos seguidores, desde el primer momento. El elaborado modelo de simulación, ha sabido recrear, con gran exactitud y precisión, coches y escenarios de juego. Sumiendo al jugador, en un ambiente de carrera y competición sin precedente.


El productor de la serie Gran Turismo, Kazunori Yamauchi, desarrollada por Poliphony Digital, ha sabido mantener un alto grado de calidad en todas y cada una de las entregas comercializadas.

Gran Turismo®6, representa el desarrollo continuo de una saga de simuladores de conducción.


En 2008 se llegó a un acuerdo con Nissan, para decubrir a jóvenes promesas, entre los jugadores y fans de Gran Turismo. La GT Academy, ha convertido en verdaderos profesionales, a pilotos de Gran Turismo, y a unos pocos campeones, del mundo del Automovilismo.


El Modo Carrera


Consiste en seis clases de carnet, para las que habrá que superar distintas pruebas de dificultad y, hacerse así, con las licencias. A medida que se progresa, el nivel de dificultad va en aumento, procurando un reto constante.


El objetivo es conseguir todas las licencias y, ganar el acceso a carreras con mayor dificultad.

Para ello habrá que enfrentarse a pruebas de velocidad, ganar estrellas y, créditos. Con el suficiente número de estrellas, desbloquearemos otros eventos, como carreras monomarca, misiones y otras...


El Modo Arcade


Entramos a competir rápidamente. Sin pasar por la Ronda de entrenamiento, ni tener que superar las pruebas de licencia.También podemos retar al coleguita, y comprobar de que pasta está hecho.

El modo arcade es una serie de desafíos, en carrera única, contrarreloj y derrape.


Seleccióna una pista, elige un coche, configura las opciones de conducción y espera a que el semáforo se ponga en verde.


Modificaciones y puesta a punto


Piezas de Tuning, Personalizadas, Puesta a punto en boxes, Equipo de competición y pintura. Accedemos a estos servicios, al entrar en la sección de Modificaciones.

Aquí podemos comprobar los daños que ha sufrido el motor y la carrocería. Un exceso de confianza al trazar las curvas puede ocasionar cierto grado de deterioro en el vehículo.

Si bebes, no conduzcas  y, si destrozas el coche, deberás repararlo en uno de los talleres dedicados.



En resumen, Gran Turismo®6 (GT6™), es uno de esos juegos que nunca pasa de moda, y hace las delicias de una tarde entre amigos. Aún mas, si les ganas y puedes verlos llorar.

El modo OnLine está también disponible, con eventos de temporada y constantes actualizaciones que aportan mas retos y pruebas.

Si algo es bueno! ¿por qué cambiarlo?








Amazon

Gran Turismo 6












EscenarioDeJuego
