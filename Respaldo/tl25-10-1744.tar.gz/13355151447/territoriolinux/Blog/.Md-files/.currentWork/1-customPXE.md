[Preliminares](#i1)

[Referencias y agradecimientos](#i99)


### [Preliminares](i1) ###

Esta es la primera etapa, antes de hacer nada, hay que saber que recursos hay disponibles y, cómo vamos a utiliarlos. En el caso que nos ocupa, a continuación los dispositivos y software relacionado,

- Caja H500 2 ventiladores 200mm RGB -- Mastercase Cooler Master
- Placa base modelo GA-AX370-gaming 5 -- Aorus
- Fuente alimentación, MasterWatt 750 -- Cooler Master
- Procesador Ryzen 5 1500X -- Amd(1ª generación).
- Ventilador MasterRair pro 3 -- Cooler Master
- Memoria sistema 16GB(2x8GB) ddr4 3200Mhz XMP-- HyperX Predator 
- Radeon RX580 PCIe x16 4-8GB GDDR5 Vulcan -- Aorus
- NVNMe SSD 250GB -- Samsung 960 EVO M.2
- WD BLUE ssd 250GB -- Western Digital.
- DVD-RW external CD sopor usb 3.0 -- Marca blanca
- Switch 5-port 10/100 FS105 -- Netgear Prosafe
- DS218+ NAS -- Synology
- Keyboard k70 RapidFire -- Corsair
- Fedora Atomic F28. -- Linux Fedora
- Win Home 10 64Bit Spanish 1p v1709 -- Microsoft







### [Referencias y agradecimientos](i99) ###

- [Synology Pxe](https://www.synology.com/en-us/knowledgebase/DSM/tutorial/General/How_to_implement_PXE_with_Synology_NAS)
- [How many VMs](https://www.synology.com/en-us/knowledgebase/DSM/tutorial/Virtualization/How_many_virtual_machines_can_I_run_on_my_Synology_NAS)



---
<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
