#### RPG 2018 ####

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Ni no Kuni 2 Revenant Kingdom | Bandai Namco | https://www.bandainamcoent.com/games/ni-no-kuni-ii | A | T GcB | email-contact | pre | ps4 | 5 |
| Call of Cthulhu | Cyanide SA | http://callofcthulhu-game.com/en/media | ndf | Gc | email-contact | options | ps4,xb1,pc | 12-13 |
| fade to Silence | Black Forest G. | https://fadetosilence.com/ | ndf | ? | email-contact | earlA. | plataforma | 12-13 |
| Dark souls remastered | FromSoftware | http://www.darksouls.jp/remastered/ | 24/05/18 | T7-G1 | email-contact | options | ps4,xb1,pc-switch | 12-13 |
| Code Vein | BandaiNamco | https://www.bandainamcoent.com/games/code-vein#editions | 31/12/18 | T6 | support@bandainamcoent.com | pre | ps4,xb1,pc | 14 |
| Horizon: Zero Down | Guerrilla G. |  | disponible | Bandera | email-contact | options | plataforma | out |
| Insomnia: the ark | Studio Mono | http://insomnia-project.com | TBA | T4 | mary@herocraft.com | options | pc | 15 |
| System Shock 3 | OtherSide Ent. |  | tba | Gc | email-contact | options | ps4,xb1,pc | 8 |
| Dauntless | Phoenix Labs | https://playdauntless.com/ | 2018 | T1 | press@phxlabs.ca | pre-FreeToPlay | pc | 20 |
| Swtor: knights of the fallen empire | Bioware | http://www.swtor.com/fallen-empire | 01/06/18 | T3 | email-contact | pre | pc | 21 |

| Dangerous Rushers | Goblinz Std. | http://dungeon-rushers.com/en/index-en/ | 25/05/18 | T9 | email-contact | pre | Nintendo Switch | 21 |
| Edge of Eternity | Midgar Std. | http://www.eoegame.com/ | tbc | ? | email-contact | options | ps4,xb1,pc | ? |
| Identity | Asylum Ent. | http://www.identityrpg.com/ | tbc | ? | email-contact | options | PC | ? |
| Dark and Ligh | Snail Games | http://www.playdnl.com/ | tbc | ? | email-contact | pre | PC | ? |
| The elder Scroll Online | ZeniMax Online Std. | https://www.elderscrollsonline.com/ | 05/06/18 | ? | press@bethsoft.com | pre | ps4-xb1-pc | ? |
| Kingdom Come Deliverance | WarHorse Std. | https://warhorsestudios.cz/ | A | ? | email-contact | options | pc | ? |



***************

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|



***************


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>



