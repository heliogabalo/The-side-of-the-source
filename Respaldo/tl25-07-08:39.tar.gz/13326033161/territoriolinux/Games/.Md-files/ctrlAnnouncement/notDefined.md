Soul Calibur							- WoW 
black desert online				- Lineage Eternal (projectTL)
EVE online								-
Blade and Soul						-
Secret World legends			-
RuneScape									-
Tera											-
Final Fantasy XIV					-

--- 
- Death Stranding														- World War Z
- Bayoneta 3
- kingdom come deliverance
- FromSoftware's new project(bloodborne 2?) -Dreams 
- In the valley of gods 										- Battle Royale
- Extintion*																- The Last of Us
- 
- Ghost of Tsushima													-
- Beyond Good & Eveil 2											- The crew 2(ps4,x1,pc)
- Assassin's Creed: Origins 								- Skull and Bones(q4-18-ps4-xb1-pc)
- For Honor										 							- Crackdown 3
- Dragon B. FighterZ ps4(26/01/18)					- Detroit become Human(q1/q2/18)
- Agony(30-03-18) pc-p4-x										- Bloodstained: ritual of the night
- Monster Hunter: World(210108-ps4,x1,pc)											- Anthem*(ps4,x1,pc)
- The las Night															- Death Stranding(ideo kohima?)
- Code Vein																	- DarkSiders*!

- Fist of North Star (18 ps4)



