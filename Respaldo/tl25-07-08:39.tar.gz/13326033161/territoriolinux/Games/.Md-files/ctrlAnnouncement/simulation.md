
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| The Crew 2 | Ivory Tower | https://thecrew-game.ubisoft.com/the-crew-2/en-GB/home/ | 29/06/18 | T | contact@ivory-tower.fr | ErlAcc | ps4-xb1-pc | 9 |
| Pure Farming | purefarminggame | https://purefarminggame.com/ | 130318 | T6 | email-contact | options | ps4,x1,pc | 11 |
| Skull & Bones | Ubisoft | https://www.ubisoft.com/en-us/game/skull-and-bones/#201292399 | 2018 | T7 | email-contact | Beta | ps4 xb1 pc | 11 |
| MX vs ATV all Out | Rainbow Std. | https://mxvsatv.com/ | 270319 | T5 | email-contact | EarlA. | ps4,x1,pc | 12-13 |
| Dual Universe Spring | novaquark | https://www.dualthegame.com/en/ | 2018/2019 | T1 | mailchimp@novaquark.com | pre | PC | 14 |
| Frost Punk | 11 bit Std. | http://www.frostpunkgame.com/ | 24/04/18 | ? | info@11bitstudios.com | options | plataforma | ? | *** EL ESTUDIO NO QUIERE QUE SE PUBLIQUEN SUS JUEGOS
| The Hunter CAll of the Wild | Avalanche Std. | http://callofthewild.thehunter.com/en/ | A | Bandera | email-contact | options | plataforma | A |
| Pro Evolution Soccer 2019 | Konami | https://www.konami.com/wepes/2019/ | 30/08/18 | T1 | email-contact | pre | ps4-xb1-steam | 21 |
| MXGP | Milestone | https://mxgpvideogame.com/ | 29/06/18 | Gi | email-contact | pre | ps4-xb1-pc | 20 |
| Industries of Titan | Brace YourselfGames | http://industriesoftitan.com/ | 2018 | ? | iot@braceyourselfgames.com | pre | TBA | 21 |

| Ace Combat 7 | Bandai Namco | http://acecombat.com/eu/ | 18/19 | ? | email-contact | options | ps4 xb1 pc | ? |
| Tropico 6 | Limbic Ent. | Pagina | 2018 | ? | email-contact | tbc | tbc | ? |
| ONRUSH | Codemasters | http://onrushgame.com/ | 05/06/18 | ? | custservice@codemasters.com | pre | ps4-xb1 | ? |
| Uboot | Deep Water Std. | kick starter! | 2018 | ? | email-contact | options | plataforma | ? |





---

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
