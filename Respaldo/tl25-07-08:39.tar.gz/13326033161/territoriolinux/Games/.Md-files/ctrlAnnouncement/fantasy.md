
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Project Wight | The outsiders | http://theoutside.rs/ | n/d | T | mail | option | 8 |
| Elex| Piranha Bytes | https://elexgame.com/ | n/d | T | mail | option | 8 |
| Wild| WILD SHEEP STUDIO | http://wildsheepstudio.com/ | n/d| T | mail | option | 8 |
| Rune: Ragnarok| Human Head Studios | https://www.runeragnarok.com/media/| n/d | T | mail | option | 9 |
| Attack on Titan 2 | Omega Force | http://www.koeitecmoamerica.com/attackontitan2/gallery.html | 20/03/18 | T9 | email-contact | options | xb1-switch-pc-p4 | 11 |
| Ashes of Creation | Intrepid Std. | https://www.ashesofcreation.com/ | ndf | T8 | pr@intrepidstudios.com | earlA | pc | 12-13 |
| Pine | kickstarter | # | 0/11/18 | ? | email-contact | options | plataforma | 12 |
| Exzore: Rising | Tiny Shark Int. | http://www.exzoretherising.com | 2018 | T9 | email-contact | options | pc-ps4-xb1 | 14 |
| The Last Night | Odd Tales | http://oddtales.net/ | 2018 | T4 | hello@oddtales.net | options | Mac-pc-Xb1 | 14 |






---

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>

