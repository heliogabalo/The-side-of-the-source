| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Spiderman | Imsomniac G. | https://insomniac.games/ | 07/09/18 | T-B | email-contact | options | PS4 | 5-9 | 
| Agents of Mayhem| RAD Games Tools | http://www.aomthegame.com/ | ready| T | info@deepsilver.com | option | | 8 |
| Nioh | Team Ninja |https://www.gamecity.ne.jp/nioh/outline.html | 071118 | T | mail | option | | 8 |
| Yakuza 0 | sega | http://yakuza.sega.com/yakuza0/home.html| 240118 | G | mail | option | | 8 |
| Red Dead Redemption 2 | Rock Star Games | https://www.rockstargames.com/reddeadredemption2/ | 261018 |pre G| mail | option | | 8 |
| fade to Silence | balckForest G. | https://fadetosilence.com/ | fecha | anunciado | info@bfgames.biz | ec/dlc | |8T 11pre |
| A Way Out| EA games | https://www.ea.com/games/a-way-out | 23/03/18 | T | mail | | 9 |
| Days Gone | Bend Studio | http://bendstudio.com/ | n/d | T | mail | ErlAcc/dlc | | 9 |
| CyberPunk 2077 | CdProjekt | http://cyberpunk.net/ | F. lanzamiento | Bandera | marcin.momot@cdprojektred.com | options | plataforma | 11Gc |
| State of Decay | Undead Labs | https://www.stateofdecay.com/ | primavera18 | Bandera | email-contact | options | ps4,x1,pc | 11T1 |z
| God of War | Santa M. std. | http://sms.playstation.com/ | 20/04/18 | Bandera | email-contact | options | PS4 | 11T2 |
| Wild West Online | 612 Games | http://buy.playwwo.com/ | 15/11/18 | Gr | support@playwwo.com | ErlAcc | PC | 11 |
| Golem | highwiregames | https://highwiregames.com/golem/ | 130318 | T3 | email-contact | options | ps4 | 11 |
| Devil May Cry | Capcom | http://www.devilmaycry.com/dmcde/ | 130318 | T4 | email-contact | options | pc,x1,ps4 | 11 |
| The Legend of Zelda: Breath | CompanyName | https://www.zelda.com/breath-of-the-wild/ | Available | -- | email-contact | options | plataforma | out |
| Biomutant | Experiment 101 | https://biomutant.com/ | 31/12/18 | Bandera | email-contact | options | x-pc-p4 | 11G1 |
| Nier Automata | platinum Games | https://niergame.com/ | 18/03/18 | T9 | email-contact | Demo | PS4,PC | 12-13 |
| Dreams | Media Molecule | http://dreams.mediamolecule.com/ | The Future | T1 | email-contact | options | ps4-psx | 12-13 |
| MineCraft | ThePeople | https://minecraft.net/ | 0 | T4 | email-contact | oneLine | all | 12-13 |
| darksiders 3 | Gunfire Games | https://darksiders.com/ | 2018 | Gc | email-contact | options | ps4-xb1-pc | 14 |
| Mutant Year Zero: Road to Eden | Cunmcom | https://www.mutantyearzero.com/#3 | 2018 | T2 | email-contact | options | PS4,Xbox One,PC | 14 |
| Detroit become Human | quanticDream | https://www.playstation.com/en-us/games/detroit-become-human-ps4/ | 25/05/18 | T3 | email-contact | pre | ps4 | 15 |
| Scavengers | Midwinter Ent. | http://www.scavengersgame.com/ | 2018 | T5 | pr@midwinter.net | options | pc | 14 |
| Shadow of the Tomb Raider | Crystal Dynamics | https://www.tombraider.com/en-us | 14/09/18 | T8 | email-contact | pre | ps4,x1,pc | 14 |
| Anthem | Electronic Arts | https://www.ea.com/games/anthem | 2019 | G1 | privacy_policy@ea.com | options | ps4,x1,pc | 15 |
| Extinction | Iron Galxy | http://www.extinction.com/ | 04/10/18 | T1 | jobs@irongalaxystudios.com | pre | ps4,x1,pc | 15 |
| Ghost of Tsushima | suckerpunch | https://www.suckerpunch.com/category/games/ghost-of-tsushima/ | 2018 | T9 | email-contact | options | PS4,XOne,PC | 15 |
| Conan Exiles | Funcom | https://www.conanexiles.com/ | 08/05/18 | T8 | email-contact | pre | pc-ps4-xone | 15 |
| insomnia: The Ark | Std. Mono | http://insomnia-project.com/presskit.php | TBA | T4 | mary@herocraft.com | options | pc xb1 mac | 15 |
| DeathGarden | Behaviour Int. | http://www.deathgardengame.com/ | 2018 | T7-Gd | email-contact | options | pc | 15-20 |
| LEGO The Incredibles | Tt Games | https://linc.wbgames.com/ | 15/06/18 | T9 | email-contact | pre | ps4-pc-xb1 | 20 |
| BlazBlue: Cross Tag Battle | Arc System Works | http://arcsystemworks.com/game/blazblue-cross-tag-battle/ | 05/06/18 | T8 | email-contact | options | Nintendo Switch-ps4-pc | 20 |
| Shaq Fu: A Legend Reborn | Saber Int. | https://www.alegendreborn.com/ | 05/06/18 | T7 | email-contact | options | ps4-xb1-pc | 20 |
| New Gundam Breaker | Bandai Namco | https://www.bandainamcoent.com/games/new-gundam-breaker | 22/05/18 | T6 | email-contact | pre | ps4-pc | 20 |
| Forest Of Liars | Umeshu Lovers  | http://game.forestofliars.com/ | 2018-19 | T5 | contact@umeshulovers.com  | options | ps4-xb1-pc-mac | 20 |
| Vahall | Blackrose Arts | https://www.blackrosearts.com/ | TBA | T4 | email-contact | pre | pc | 20 |
| Rage 2 | idsoftware | https://bethesda.net/ | 2019 | T5 | email-contact | options | ps4-xb1-pc | 21 |

---

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
