[Utilizando el disco de RAM inicial(`initrd`)](#i1)
[Funcionamiento](#i2)
[Opciones de la línea de comado](#i3)
[Imágenes `cpio` comprimidas](#i4)
[Instalación](#i5)
[Cambiando el dispositivo raíz](i6)
[Referencias y agradecimientos](#i99)

### Utilizando el disco de RAM inicial(`initrd`) ###

Escrito por __Werner Almsberger__ en 1996,2000 <werner.almesberger@epfl.ch> y Hans Lermen <lermen@fgan.de>

`initrd` proporciona la capacidad de cargar un disco RAM, por el cargador de arranque.
Éste disco, podrá ser montado como FS raíz, sobre el que podrán correr otros programas. Después de todo, un nuevo FS podrá ser montado desde un distinto dispositivo. El ráiz anteior -desde initrd, es entonces movido a un directorio y, podrá ser subsiguientemente, desmontado.

`initrd` ha sido diseñaado principalmente, para permitir la carga del _sistema de arranque_, en dos fases; donde el kernel inicia con un conjunto de controladores pre-compilados y, donde módulos adicionales serán cargados desde _initrd_.

El documento  muestra un breve repaso, acerca del uso de _initrd_. Una discusión más detallada sobre el proceso de arranque, podrá ser encontrado en [#f1].


### [Funcionamiento](i2) ###

El sistema arranca de la siguiente manera, al utilizar _initrd_:

1. El gestor de arranque carga el kernel y el disco RAM, inicial. 
2. El kernel convierte _initrd_ en un disco RAM "normal", liberando la memoria utilizada por _initrd_.
3. Si el dispositivo raíz no es `/dev/ram0`, es utilizado un procedimiento anterior `change_root` -depreciado. Ver más abajo, la seccion _mecanismo obsoleto_.
4. Es montado el dispositivo raíz, si es `/dev/ram0`; la imagen _initrd_ es montada como raíz.
5. `/sbin/init` es ejecutada -esto puede ser cualquier ejecutable válido, incluyendo _scripts_ de cónsola. Será lanzado con `uid 0` y, práctimamente puede hacer lo mismo que _init_.
6. _init_, monta el sistema de ficheros "real".
7. _init_, sitúa el sistema de ficheros raíz, en el directorio _root_, mediante la llamada al sistema _pivot_root_.
8. _init_ ejecuta `/sbin/init` en el nuevo sistema de ficheros raíz, llevando a cabo la habitual secuencia de arranque.
9. El sistema de ficheros _initrd_ es retirado

__Nota__: cambiar el directorio _root_, no implica desmontarlo. Asi, es posible dejar que otros procesos corran sobre `initrd`, durante el procedimiento. Nótese también, que FS's montados bajo _initrd_ continuarán siendo accesibles.


### [Opciones de la línea de comado](i3) ###

_initrd_ añade las siguientes opciones:

		initrd=<path>    (e.g. LOADLIN)	
		
Carga el archivo especificado, como disco RAM inicial. Cuando es utilizado __LILO__, es necesario especificar el archivo de imagen del disco RAM `/etc/lilo.conf`, mediante la varible de configuración `initrd`.

		noinitrd
		
_initrd_ es preservado, pero no será convertido a disco RAM y, será montado el sistema de ficheros `root`, normal. Los datos_initrd_ podrán ser leídos desde `/dev/initrd`. Añadir, que los datos en _initrd_, podrán tener cualquier estructura en tal caso y, no será necesario que sea una imagen de sistema de ficheros. Es una opción utilizada mayormente para _depurar_.

__Nota__: `/dev/initrd` es de sólo lectura y, únicamente puede ser utilizado _una vez_. Tan pronto como el último proceso termine, todos los datos son liberados y `/dev/initrd` no podrá ser abierto de nuevo.

		root=/dev/ram0

_initrd_ es montado como `root` -usuario administrador, sucediéndose el procedimiento de arranque, con el disco RAM montado como `root`. 


### [Imágenes `cpio` comprimidas](i4) ###

Kernels más recientes, dan soporte  para poblar un _disco ram_, desde un archivo comprimido `cpio`. En éstos sistemas, la creación de una imagen de disco ram, no necesita involucrar dispositivos de bloque espciales, o de retorno -loopback. Sencillamente es creado un directorio en el disco, con el contenido _initrd_deseado, `cd` al directorio y lanzar:

		find . | cpio --quiet -H newc -o | gzip -9 -n > /boot/imagefile.img

Examinar el contenido de un archivo de imagen existente, es tan simple como:

		mkdir /tmp/imagefile
		cd /tmp/imagefile
		gzip -cd /boot/imagefile.img | cpio -imd --quiet


### [Instalación](i5) ###

En primer lugar, debe ser creado un directorio para el FS _initrd_, en el sistema de ficheros raíz, ejemplo:

		# mkdir /initrd

El nombre no es relevante. Más detalles en la página de manual `pivot_root`(2).

Si es creado el FS raíz, durante el proceso de arranque -por ejemplo al constuir un "disco floppy" de instalación,  el procedimiento de crear un FS raíz, debería crear el directorio `/initrd`.

Si _initrd_ no fuese montado en determinados casos, su contenido seguiría siendo accesible de existir el siguiente dispositivo:

		# mknod /dev/initrd b 1 250
		# chmod 400 /dev/initrd

Segundo, ekl kernel deberá ser comilado con soporte para disco RAM y, con soporte a disco RAM de inicio, activado. Igualmente, los componente necesarios para ejecutar programas desde initrd, deberán ser compilados en el própio kernel -ejem, formato ejecutable y sistema de archivo.

Tercero, deberá ser creado un disco de imagen RAM. Mediante la creación de un FS en un dispositivo de bloque, copiando archivos de ser necesario y, copiando el contenido del bloque de dispositivo dentro del archivo _initrd_. En kernels recientes, al menos tres tipos de dispositivos, son válidos para ésto:

- un disco flexible(funcionan en todos lados, aunque de forma dolorosamente lenta).
- un disco RAM(rápido, pero ocupa memoria física).
- un disco de retorno(la solución más elegante).

Describiremos el método con el dispositivo _loopback_:

1. Comprobar que el dispositivo de bloque _loopback_, esté configurado como parte del kernel.
2. Crear un FS vacío de tamaño adecuado, ejemplo:

		# dd if=/dev/zero of=initrd bs=300k count=1
		# mke2fs -F -m0 initrd

De tener poco espacio, podrá utilizarse el FS _Minix_, en lugar de _Ext2_.

3. Montar el FS:

		# mount -t ext2 -o loop initrd /mnt

4. Crear el dispositivo de cónsola:

		# mkdir /mnt/dev
		# mknod /mnt/dev/console c 5 1

5. Copiar todos los archivos necesarios, para utilizar apropiadamente el entorno _initrd_. No debe olvidarse el archivo más importante `/sbin/init`

> __nota__: `/sbin/init` debe tener permisos de ejecución "x".

6. Es posible comprobar el correcto funcionamiento del entorno _initrd_, incluso si reiniciar, con el comando:

		# chroot /mnt /sbin/init

Por supuesto, queda limitado a _initrd_, el cuál no interfier con el estado general del sistema -ejemplo, reconfigurando la interfase de red, sobreescribiendo dispositivos montados, intentando iniciar _demonios_ ya activos, etc. Nótese que es igualmente posible utilizar `pivos_root` en este tipo de entornos _initrd_, "ceacheruteados -chroot'ed".

7. Desmontar el FS:

		# umount /mnt

8. El archivo _initrd_ es ahora _initrd_. Opcionalmente, podrá ser comprimido

		# gzip -9 initrd

Para experimentar con _initrd_, es posible tomar un _disco de rescate_ y, añadir únicamente un enlace simbólico desde `/sbin/init` a `/bin/sh`. Alternativamente, es posible intentar crear un pequeño _initrd desde el entorno experimental _newlib_ [f2](#f2).

Finalmente, deberá arrancarse el kernel y cargar el _initrd_. Prácticamente todos los gestores de arranque _Linux_, soportan _initrd_. Puesto que el proceso de arranque, continúa siendo compatible con viejos mecanismos, los siguientes parámetros para la línea de comandos, deben ser dados:

		root=/dev/ram0 rw

> `rw` es únicamente necesario si se pretende escribir en el FS _initrd_.

Con LOADLIN, símplemente es ejecutado:

		LOADLIN <kernel> initrd=<disk_image>

Ejemplo:

		LOADLIN C:\LINUX\BZIMAGE initrd=C:\LINUX\INITRD.GZ root=/dev/ram0 rw

Con LILO, es añadida la opción, `INITRD=<path>`, tanto en la sección global, como en la respectiva sección del kernel `/etc/lilo.conf`, pasando las opciónes mediante __APPEND__, ejemplo:

		image = /bzImage
			initrd = /boot/initrd.gz
			append = "root=/dev/ram0 rw"

... y lanzar `/sbin/lilo`.

Para otros gestores de arranque, por favor, refiérase a la respectiva documentación.
Ahora ya puede _arrancar_ y, disfrutar utlizando _initrd_.


### [Cambiando el dispositivo raíz](i6) ###

Cuando termina con sus tareas, _init_ cambia habitalmente el dispositivo raíz y, procede con el inicio del sistema Linux , sobre el dispositivo raíz "real".

El procedimiento involucra los siguientes pasos:
- montar el nuevo FS raíz. 
- Cambiando al FS raíz
- Retirar todos los accesos al _viejo initrd_ 
- Desmontar el FS _initrd_ y, _des-asignando_ el disco RAM.

Montar el nuevo FS raíz, es fácil; sólo necesita ser montado en un directorio, bajo raíz activo. Ejemplo:

		# mkdir /new-root
		# mount -o ro /dev/hda1 /new-root

El cambio del _root_, es completado mediante la llamada de sistema `pivot_root`, disponible através de la utilidad `pivot_root`. Ver página de manual(8) `pivot_root`, distribuido junto a `util'linux` versión 2.10 o posterior [f3](#f3). `pivot_root`, meve el _root_ activo a un directorio bajo el nuevo raíz y, coloca el nuevo _root_ en su lugar. El directorio del _viejo raíz_, debe existir antes de llamar a `pivot_root`. Ejemplo:

		# cd /new-root
		# mkdir initrd
		# pivot_root . initrd

Ahora, el proceso _init_, podría continuar teniendo acceso al _viejo raíz_ vía su ejecutable, librerías compartidas, la entrada/salida/error estandar y, el directorio ráiz activo. Todas estas referencias son mostradas por el siguiente comando:

		# exec chroot . what-follows <dev/console >dev/console 2>&1










### <a name="i99">Referencias y agradecimientos</a> ###

[#f1] Almesberger, Werner; "Booting Linux: The History and the Future"
    http://www.almesberger.net/cv/papers/ols2k-9.ps.gz
[#f2] newlib package (experimental), with initrd example
    https://www.sourceware.org/newlib/
[#f3] util-linux: Miscellaneous utilities for Linux
    https://www.kernel.org/pub/linux/utils/util-linux/
