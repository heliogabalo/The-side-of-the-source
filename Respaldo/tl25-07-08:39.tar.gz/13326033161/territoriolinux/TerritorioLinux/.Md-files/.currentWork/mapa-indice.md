So/systemd

## Mapa de temario

- `systemd.service(5)`  
- `systemd.socket(5)`  
- `systemd.device((5)` [-]  
- `systemd.mount(5)`  
- `systemd.automount(5)`  
- `systemd.swap(5)`  
- `systemd.target(5)`  
- `systemd.path(5)`  
- `systemd.timer(5)`  
- `systemd.slice(5)`  
- `systemd.scope(5)`  
- `systemd.unit(5)` [-]  
- `systemd.(5)`  [-]
---
- `udev` [-]
