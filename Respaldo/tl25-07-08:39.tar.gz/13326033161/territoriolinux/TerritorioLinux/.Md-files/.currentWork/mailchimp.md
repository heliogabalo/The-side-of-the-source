# Configuracion MailChimp #

https://mailchimp.com/help/getting-started-with-mailchimp/
