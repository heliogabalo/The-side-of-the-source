grep -rnw 'TerritorioLinux/' -e 'fichero'|less
