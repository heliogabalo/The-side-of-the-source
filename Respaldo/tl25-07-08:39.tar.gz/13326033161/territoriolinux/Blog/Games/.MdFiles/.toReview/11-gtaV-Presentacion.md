

titiulo Rockstar anuncia una nueva entrega del ya clásico GTA.



Rockstar anuncia una nueva entrega del ya clásico GTA. Grand Theft Auto V, cuenta

con multitud de misiones, armas y, un gran número de vehículos. Para aquellos que aun

no han tenido la oportunidad de disfrutar, de este mágnifico juego de acción y aventura.

Va a resultarles un sorprendente soplo de aire fresco.


Es un juego de mecánica fácil, pero que sabe encajar a la perfección la complejidad de

misiones y el estilo libre y abierto, de otros juegos más centrados en ese aspecto, como

los MMORPG. El GTA-V, supone un entorno de juego aún más abierto, que el anterior

GTA. Si, esta vez si podremos meternos en los aeropuertos, robar los aviones, tirarnos

en paracaídas y muchas otras sorpresas...









