 Estimados lectores,


Desde la dirección de Jugones.punto.com, queremos informar a todos los

usuarios, del ataque detectado en nuestra Web.

Estamos trabajando para determinar el daño ocasionado. Sin embargo, es

probable que en los próximos días, experimenteis ciertas dificultades;

puede que la navegación en la página, no resulte todo lo fluida que venía siendo

hasta el momento.


 Al parecer, un "Robot informático", ha invadido gran parte de las librerías, donde

almacenábamos datos de usuario y otras referencias de aplicación. Provocando

el borrado de muchos de esos datos de usuario.


Con objeto de evitar otros daños mayores, hemos tomado la determinación de

establecer una vigilancia escrupulosa, que mantendremos hasta aclarar el

problema.


Nuestras herramientas de seguridad, trabajarán a toda potencia, durante el

proceso de detección y erradicación, de tal software malintencionado.

Garantizando que el usuario no vea comprometido su equipo de ninguna

manera. McAfee, Norton, Panda, bitdefender.


Agradecemos la confianza depositada, en ésta, nuestra revista; animándoos a

usar la biblioteca recientemente incorporada al blog. Donde podréis encontrar

cantidad de recursos útiles, que harán de vuestra experiencia de juego, un

paseo en modo "Easy".


El equipo de Jugones.punto.com, ha incluido una serie de enlaces, a otras

páginas, que guiarán al "jugón", a través del intrincado mundo del videojuego,

donde podréis encontrar guías prácticas a vuestros juegos preferidos, vídeos,

consejos de otros jugadores y, mucho mas...




http://jugonespuntocom.blogspot.com.es/
