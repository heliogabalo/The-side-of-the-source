## Action Adventure Games - Febrero 2018

- gravity Rush 2(T)								- Nier Automata
  gravity Daze 2(japones)					---
- Agents of Mayhem								- Nioh
- Yakuza 0												- Prey (*)
- Horizon: Zero Down (*)					- Super Mario Odyssey
- The Legend of Zelda: Breath			- Red Dead Redemption 2 (*F)
- Sea of Thieves									- Crackdown 3


