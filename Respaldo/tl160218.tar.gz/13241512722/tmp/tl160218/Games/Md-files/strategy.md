## Strategy Games - Febrero 2018

- ancestors													- Jurasic World Evolution*
- Surviving Mars										- The Guild 3
- Ancient Cities										- Anno 1800
- SpellForce 3											- Iron Harvest 1920*
- Age of Empires										- Age of Empires IV*
Definitive Edition
- Age of Mythology									- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*
- ancestors													- Jurasic World Evolution*

