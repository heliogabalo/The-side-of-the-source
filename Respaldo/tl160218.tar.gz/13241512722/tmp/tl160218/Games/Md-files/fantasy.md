## Fantsy Games - Febrero 2018

- Pine													- Rune: Ragnarok
- Valnir Rok										- Exzore: Rising
- Midle Earth:Shadow o'War(*G)	- Ashes of Creation
- Dark and Light								- Elex
- Project Wight*								- Shadow of the colossus remake
- Babylon Project**							- GreedFall (T)
- Monster Hunter: World					- Vampyr (T*)
- Wild*													- Ealdorlight(T*)
- War of rights(T)							- Black Room



