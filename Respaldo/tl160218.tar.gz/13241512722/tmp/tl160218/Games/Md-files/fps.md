## First Person Shooter - Febrero 2018

- War of rights(T)							- Black Room
- Serious Sam										- Witchfire
- Warhammer Vermintide 2				- Hell let Loose
- Deep rock Galactic(T)						- Scorn
- Ready or not									- Atomic Heart II
- GTFO													- Hunt: Showdown
- Border Lands 3								- System Shock (**I-pre) 
- Overkills the Walking Dead		- Escape from Tarkov
- Batalion 1944									- unannonuced Call of Duty -treyarch
- Metro Exodus*									- Far cry 5 (*T)

---
