## Puentes Bus PCI

El standar PCI permite conexiones de múltiples buses PCI independientes através de _puentes bus_,  
estos delegrarán las operacione de un bus a otro, cuando sea necesario. Aún así, el PCI convendcional  
tiende a no usar muchos _puentes de bus_, _PCI Express_ en cambio si lo hace; cada zócalo  
_PCI Express_ aparece  como un bus separado del resto, conectado por un _puente_ con el resto.


> __nota:__ del inglés PCI bus bridges
