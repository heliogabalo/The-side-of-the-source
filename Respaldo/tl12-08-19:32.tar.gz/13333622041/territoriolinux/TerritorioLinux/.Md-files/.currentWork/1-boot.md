[Introducción](#i1)
[Capa de memoria](#i2)

[Referencias y agradecimientos](#i99)
---


## El protocolo de arranque de Linux/86 ##

### [Introducción](i1) ###

En plataformas x86, el kernel de Linux utiliza una serie de convenciones para el arranque. Estas han evolucionado debido a aspectos históricos, así como la intención, en etapas iniciales, de que el kernel en sí mismo, fuese una imagen arrancable, 

el complicado modelo de memoria PC, en un PC
debido al cambio de espectativas en la insdustria del PC
causada por 

efectiva desaparición, muerte, defunción, término
como sistema operativo de
 _rama principal_, línea general


Actualmente, existen las siguientes versiones para el protocolo de arranque de _Linux/86_.

Anteriores kernels: sólo soporte a_zimage/image_. Alguno de los primeros kernels, podrían incluso, no dar soporte a la línea de comandos.

Protocolo 2.00: (kernel 1.3.73) Añadido el soporte a _bzimage_ e _initrd_, así como la formalización de un procedimiento para comunicar al kernel, con el gestor de arranque.
`setup.S` hizo _recolocable_ al miso, aunque el area de configuración tradicional, continúa siendo _escribible_.

Protocolo 2.01: (kernel 1.3.76) Añadida una advertencia, para la _sobrecarga de pila_.

Protocolo 2.02: (kernel 2.4.0-test3-pre3) Nuevo protocolo, para la línea de comandos.
Alcanzado el límite de memoria convencional. No hay sobreescritura en el área de configuración tradicional, facilitando un arranque seguro, en sistemas que utilizan EBDA desde SMM o un punto de entrada en la BIOS de 32-bit. Depreciada _zimage_, aunque mantenido el soporte.

Protocolo 2.03: (kernel 2.4.18-pre1) de forma explícita, se pone initdr a disposición del gestor de arranque, en una dirección lo más alta posible.

Protocol 2.04:	(Kernel 2.6.14) Extendido el tamaño de campo `syssize`, a cuatro bytes.

Protocol 2.05:	(Kernel 2.6.20) Construido el modo, _protegido_ del kernel como _recolocable_. Son introducidos los campos `relocatable_kernel` y `kernel_alignment`.

Protocol 2.06:	(Kernel 2.6.22) Añadido un campo, conteniendo el tamaño de la línea de comandos para el arranque.

Protocol 2.07:	(Kernel 2.6.24) Añadido: _paravirtualización_, como  el protocolo de arranque. Son intorucidas `hardware_subarch`y `hardware_subarch_data` y, las opciones `KEEP_SEGMENTS`	 en `load_flags`.

Protocol 2.08:	(Kernel 2.6.26) Añadida la _suma de comprovación_ `crc32` y el formato ELF de _payload(punto de carga?)_. Introducidos los campor `payload_offset` y `payload_length` para ayudar a localizar el _payload_.

Protocol 2.09:	(Kernel 2.6.26) Añadido un campo tipo _puntero físico_ de 64-bit, en una lista enlazada de `struct	setup_data`.

Protocol 2.10:	(Kernel 2.6.31) Añadido el protocolo para el _alineamiento relajado_, tras añadir `kernel_alignment`, nuevos campos `init_size` y `pref_address`. Añadida la extensión de identificador -ID, al gestor de arranque.

Protocol 2.11:	(Kernel 3.6) Añadido un campo para el _offset_ de EFI asistido, protocolo para el punto de entrada.

Protocol 2.12:	(Kernel 3.8) Añadido el campo `xloadflags` y extensión de campos, en el `struct` -la estrctura, `boot_params`, para _bzImage_ en carga y, el disco ram por encima de los 4G en 64bit.


### [Capa de memoria](i2) ###

El mapa de memoria tradicional para el cargador del kernel, utilizó una Imagen o _zImage_ del kernel, parecida:

			|			 |
		0A0000	+------------------------+
			|  Reserved for BIOS	 |	Do not use.  Reserved for BIOS EBDA.
		09A000	+------------------------+
			|  Command line		 |
			|  Stack/heap		 |	For use by the kernel real-mode code.
		098000	+------------------------+	
			|  Kernel setup		 |	The kernel real-mode code.
		090200	+------------------------+
			|  Kernel boot sector	 |	The kernel legacy boot sector.
		090000	+------------------------+
			|  Protected-mode kernel |	The bulk of the kernel image.
		010000	+------------------------+
			|  Boot loader		 |	<- Boot sector entry point 0000:7C00
		001000	+------------------------+
			|  Reserved for MBR/BIOS |
		000800	+------------------------+
			|  Typically used by MBR |
		000600	+------------------------+ 
			|  BIOS use only	 |
		000000	+------------------------+

Cuando es utilizada _bzImage_, el _modo protegido_ del kernel, recolocó en `0x100000` -memoria alta, 










### [Referencias y agradecimientos](i99) ###

offset,
payload, 



