En man initrd aparece una referencia a rdev(8), buscar página de manual.
