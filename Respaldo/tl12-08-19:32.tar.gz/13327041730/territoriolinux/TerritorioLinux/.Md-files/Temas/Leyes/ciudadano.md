## Ciudadano
Nadie está por enciam de la ley. Ni siquiera los jueces, abogados, legisladores,
incluídos el Rey o el Papa. No cuesta demasiado, darse cuenta de esta verdad 
universal; donde el derecho a la intimidad a ser libre, es un concepto inherente
a cualquier ser humano o persona.

Establecer un puesto de escucha, con el objeto de acosar o vulnerar la intimidad
de cualquier sujeto/a, debe ser perseguido y condenado bajo cualquier circunstancia.
Luego un juez puede determinar tal procedimiento si existen indicios de delito 
punible? 

No soy legislador pero la respuesta es simple, al menos bajo mi punto de vista 
personal y subjetivo. No, no como norma general y aún menos si tal procedimiento
es sostenido en el tiempo y perpetuado por cualquier indivíduo ajeno a la 
fiscalía, departamento de policia adscrito a tal investigación o empresa vinculada
a llevar a cabo dichas investigaciones, con auotrizacíon escrita y firmada por la
autoriadad compentente.

Dicho de otra forma, todo individuo es inocente mientras no se demuestre lo contrario,
por lo que perseguir a un ciudadano, presúntamente inocente, de forma arbitraría o 
irracianal, determinando un tiempo indefinido para tal propósito -o pesquisa policial,
es en sí mismo un delito, que a todos debería preocupar y, por lo tanto, ser una
prioridad que tal proceder fuese condenable ante cualquier tribunal.

Hay algunas reglas que están hechas para romperse, pero ésta, no es una de ellas.


