## CA Territorio Linux

Qué es una Autoridad -o entidad, de Certificado?
Para que sirve?
Puede, o debe uno/a, confiar en estas entidades?
Qué puedo hacer para firmar mis própios certificados?
Cómo incorporo una _CA_ privativa, a mi almacen de certificados(_trust store_)?
Es completamente seguro el protocolo HTTPS, SSL/TLS?
Cómo desintalo el cirteficado?... ya no lo uso!
Cómo utilizo mi própio certificado, para comunicarme con un servidor?
Por qué utilizar un certificado de pago, en lugar de uno _a-granel_?
