
Star Wars: The Old Republic


 Game Update 1.3 is Avalibe On PTS! 


Actualización: El servicio de copia de personajes para el servidor PTS, se mantendrá disponible

hasta la 10am CDT ...


Nos complace anunciar que nuestro servidor PTS, está mas vivo que nunca, con la actualización

1.3: Aliados! ...

... Uno de nuestro mayorers esfuerzos, radica en mantener actualizado el Buscador de  Grupos,

así que nos gustaría incentivar a nuestros jugadores, para que dieran un salto al servidor de prueba,

o PTS y, nos ayudasen a probarlo.

Hay dos títulos* que podrás ganar, ayundándonos a probar la herramienta de Búsqueda de grupos...


Lee el artículo completo en Game Update 1.3 is Avalibe On PTS! 
