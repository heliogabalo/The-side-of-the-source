ARROZ NEGRO (5 personas)

- 1 Kg. Carabineros
- 200    Gr. Chipirones  frescos cortados a cuadritos de 1x1 cm.
- 1        Litro de caldo de pescado 
- 2        Sobres  Tinta de Calamar o sepia
- 4        Dientes de ajo
- 1        Ramito de Cilantro  o  Perejil
- 1        Vaso de vino Txacoli  o  Montilla
- 1         Chorrito de Brandy  o  Ron
- 1         Cucharadita tomate concentrado
- 2         Cebollas bien picadas en pequeño
- 1         Pimiento verde bien picado
- 1         Poco de Cebollino  picado
- 300     Gr. de arroz

			PROCEDER

Hacer un sofrito con las verduras y los ajos, cuando esté dorado,
añadir los chipirones y saltear, incorporar el concentrado de tomate 
y unos minutos  después añadir el vino y el Brandy, dejar haciendo
chus-chus unos minutos para que evapore todo el alcohol.
Echar el arroz y sofreírlo un poco para que suelte el almidón y se cierre
y no se hinche demasiado ( lo que provoca que el arroz se pase en seguida)
Añadir el caldo y cocer durante 18 o 20 minutos.
Dejar reposar 5 minutos y a disfrutarlo.

   Nota! el pescado lo podemos hacer nosotros  o utilizar uno envasado.
