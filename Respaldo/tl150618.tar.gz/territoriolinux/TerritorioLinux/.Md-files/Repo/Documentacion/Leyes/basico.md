## Basico // Borrador

¿Queremos que nuestros derechos más básicos sean vulnerados por cualquiera?
¿En cualquier situación? ¿bajo cualquier circunstancia? ¿sin importar quién,
como, dónde o cuándo?

Edward Snowden, Julian Asange, Baltasar Garzón y muchos, muchos otras; son 
prohombres: aquellos que por su integridad, su dignidad humana, sus invaluables
conocimientos, etc. representan los valores mas significativos e importantes de
de todos nosotros. Ellos representan nuestros derechos más básicos y, si no los
protegemos, si nos olvidamos de ellos, estamos olvidándonos a nosotros mismos.

¿Podemos permitir que el paparazzi de turno, se meta en la casa de nuestro 
presidente, a invadir su intimidad y la de su familia? Por que no estoy hablando
ideales políticos o preferencias políticas de ningún tipo; estoy hablando de
derechos humanos. 

No pueden matarse moscas a cañonazos. Como diría aquel; es la mayor estupidéz
que ha perpetrado nuestra especie, desde el final de la segunda guerra mundial,
contra sí misma.

Estamos dirigiendo la sociedad hacia un punto de no retorno, por todos los cielos,
¿qué nos estamos haciendo ha nosotros mismos? Cuándo censuramos los medios que
un juez, pone en práctica, para esclarecer una investigación -una medida 
absolutamente extraordinaria, estamos mandando el mensaje equivocado.

Cuando impedimos que una noticia, sea expuesta tal y como es y, se persigue
al periodista con objeto de acallarlo, incluso atentando contra su vida, estamos
mandando el mensaje equivocado.

Cuando permitimos que los gobiernos, se apropien de la tecnología, para controlar
filtrar, almacenar, de forma invasiva, e invariablemete indiscriminada contra la 
ciuadadanía; estamos mandando el mensaje equivocado.

Y el mensaje es muy simple y se aloja en el subsconciente de todos, de manera
irreversible y virulenta. Impunidad. Estmos aceptando que el crimen, es un 
medio para alcanzar el objetivo, sin importar cualquier otro criterio.

Si los responsables de gobierno, que nos representan a todos, no entienden
esto; estamos perdidos. Todos estamos perdidos. Por que la ciudadanía si lo
entiende. Y cuando se entra en esta espiral de represión orquestada
al mas alto nivel, ya no queda nada del sistema. Hemos dilapidado nuestras
própias reglas.

No podemos permitir que nuestros intereses, políticos, económicos, etc. 
construyan, nuestros derechos y responsabilidades.
Debemos contruir las reglas en base a los derechos y responsabilidades, 
no al contrario. Por que es ésta, la parte del problema o equación que sí
conocemos. Al contrario de las "reglas", que deben ser acomodadas en función
del entorno, de consideraciones variables, o de cualquier otro criterio sugeto
a una constante evolución.
