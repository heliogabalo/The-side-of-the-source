#!/bin/sh

# --delete
rsync -avr --exclude=sync.* \
	/mnt/LV/Github/territoriolinux/TerritorioLinux/dataQuery/ root@138.68.78.228:/var/www/territoriolinux/TerritorioLinux/dataQuery/ > /tmp/ctrLog 2>&1 
