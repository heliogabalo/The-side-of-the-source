<?php

// PATH TESTING
// 1. https://territoriolinux.net/TerritorioLinux/dataQuery/
// 2. https://territoriolinux.net/TerritorioLinux/dataQuery/Register

// LOGIN SETUP
// 1. https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php
// 2. https://www.tutorialspoint.com/php/php_mysql_login.htm
// 3. https://secure.php.net/manual/en/faq.passwords.php
// 4. ftp://ftp.wayne.edu/ldp/en/PHP-Nuke-HOWTO/config-php-file.html

// PASARELAS DE PAGO
// 1. https://www.ciudadano2cero.com/pasarelas-y-sistemas-de-pago-online/

// APACHE CONFIGURATION
// 1. https://www.digitalocean.com/community/tutorials/how-to-configure-the-apache-web-server-on-an-ubuntu-or-debian-vps

// WORDPRESS INSTALATION
// 1. https://www.digitalocean.com/community/tutorials/how-to-install-wordpress-with-lamp-on-ubuntu-16-04

// PROJECT SCHEME
// 1. https://code.tutsplus.com/tutorials/organize-your-next-php-project-the-right-way--net-5873

// MySQL CONCEPTS
// 3. https://stackoverflow.com/questions/1388025/how-to-get-id-of-the-last-updated-row-in-mysql#1751282


// CONFIG DIGITAL OCEAN API
// 1. https://www.digitalocean.com/docs/api/create-personal-access-token/
// 2. https://github.com/digitalocean/doctl#installing-doctl
// 3. https://www.digitalocean.com/community/tutorials/how-to-secure-web-server-infrastructure-with-digitalocean-cloud-firewalls-using-doctl


?>

You need to CNAME from ugc.domain.com to domain.com

ls -F /et/apache2/sites-available |less



//or


SELECT id, name, email, signup_date FROM info;

ALTER TABLE info
ADD password VARCHAR(106) NOT NULL AFTER name;

ALTER TABLE `users` AUTO_INCREMENT = 1;

DELETE FROM [db_some] WHERE id = [nº];

INSERT INTO info (name, email, password, signup_date) VALUES ("user2", "user2@territoriolinux.net", "somesome", NOW());

UPDATE MyGuests SET lastname='Doe' WHERE id=2

UPDATE sequence SET id=LAST_INSERT_ID(id+1);

REPLACE INTO `sequence` set id=1;



