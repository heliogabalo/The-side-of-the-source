> "All of these news organisations around the world, all of these publishers 
were trying to get a piece of the story. There was only one publisher that 
actually said: We want to help the source, we want to make sure he’s ok, we 
want to make sure that, no matter what happens, he has somebody on his side, 
and that was WikiLeaks." – Edward Snowden

"Ever tried. Ever failed. No matter. Try again. Fail again. Fail better" - Samuel Beckett

***************


¿Por qué adquirir una licencia?

Para poder echarle la culpa a alguien, que sepa más que tu; o que tenga más recursos que tu. Para poder centrar la atención en lo que te interesa realmente. Pero esto tiene muchos _matices_, claro. 

Por la misma razón que en la edad media se utilizaba el sistema simbiótico _señorío<->vasallage_. La diferencia, es que la fuerza bruta, es ahrora verde, o _software propietario_.

Era se una vez, una _persona_, que tenía un archivo. Otro, pensó que también lo quería y, lo robo, se escondió, lo escondió y, se lo dijo a su _amigo_. Un tercero, lo copio, lo guardó, compartió y, el primeró se enteró.

Nació el _bucle_ -loop, en inglés. Por eso existen las reglas; para romperlas. Por que todo vale. Todo, todo... algunas cosas valen más que otras. Por ejemplo, el trabajo de una persona no vale un carajo. Vale, el que lo vale -o el que dice que lo vale, vale.

by free, dom0

***************
