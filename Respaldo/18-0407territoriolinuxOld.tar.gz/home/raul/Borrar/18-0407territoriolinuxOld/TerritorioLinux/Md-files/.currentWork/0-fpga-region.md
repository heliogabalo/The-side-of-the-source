* [Tabla de contenido](#i0)
* [Introducción](#i1)
* [Terminología](#i2)
* [Secuencia](#i3)
* [Zona FPGA](#i4)
* [Modelos de uso soportados](#5)
* [Ejemplo de _árbol de dispositivo_](#i6)
* [Referencias y agradecimientos](#i99)

# FPGA Enlaces de _zona_ para el DT #
__(Region Device Tree Bindings)__


#### <a name="i0">Tabla de contenido</a> ####

1. Tabla de contenido
2. Terminología
3. Secuencia
4. Zona FPGA
5. Modelos de uso soportados
6. Ejemplo de _árbol de dispositivo_
7. Referencias y agradecimientos

#### <a name="i1">Introducción</a> ####

Las _regiones_ FPGA, representan a FPGAs y a zonas de reconfiguración parcial del FPGA, en el árbol de dispositivo. Las regiones FPGA, proporcionan una manera de programar FPGAs _bajo el control del DT_.

Este documento de _vinculaciones_ al _DT_, señala algunos de los puntos más importantes sobre el uso del FPGA y, trata de incluir la terminología utilizada por los fabricantes de tales dispositivos FPGA. No es un reemplazo a las especificaciones de fabricante, en cuanto al uso del FPGA.

#### <a name="i2">Terminología</a> ####

__Reconfiguración completa__
- Es programado el fpga, énteramente.

__Remconfiguración parcial `PR`__
- Es reprogramada una sección FPGA, mientra el resto, no se ve afectada.
- No todas las FPGAs soportan `PR`.

__Región de Reconfiguración Parcial `PRR`__
* También llamada "partición reconfigurable".
* Un `PRR`es una sección específica de una FPGA, reservada para ser reconfigurada.
* Una _imagen_ base -o estática, podrá crear un conjunto de `PRR`, para más tarde poder ser, independientemente reprogramados muchas veces.
* El tamaño y, localización específica de cada `PRR` es _fija_.
* Las _conexiones_ y _extremos_, de cada `PRR` son fijos. La imagen que es cargada en un `PRR`, __debe__ ajustar y utilizar, un subconjunto de conexiones de la región.
* Los _buses_ dentro del FPGA, son separados de tal forma que, cada región obtiene su propia rama, donde poder crear más tarde una puerta, de forma independiente.

__Persona__
* También llamada: _torrente de bit parcial_.
* Una imagen FPGA designada para ser cargada en el `PRR`. Puede haber cualquier número de _personas_ designadas para ajustarse al `PRR`, Pero sólo una a la vez, poodrá ser cargada.
* Una _persona_ podrá crear _otras_ regiones.

__Puente FPGA__
* Puentes FPGA para señales de _buses de puerta_, entre el _host_ y el FPGA.
* Los Puentes FPGA, deberían ser desabilitados mientras el FPGA es programado, para prevenir señales espúrias sobre el _bus_ de la CPU y, el _soft logic[f1]_.
* Los puentes FPGA, podran ser _hardware_ en activo, o _soft logic_ en un FPGA.
* Durante la reconfiguración completa, los puentes de _hardware_, entre el _host_ y el FPGA, serán desactivados.
* Durante la reconfiguración parcial de una región específica, el _puente_ de la misma, será utilizado como _puerta_ a los _buses_. El tráfico a otras regiones no se verá afectado. 
* En algunas implementaciones, el gestor FPGA controla el _enrutado(gating)_ a los buses de manera transparente, evitando la necesidad de mostrar los puentes FPGA de _hardware_, en el árbol de dispositivo.
* Una imagen FPGA, podrá crear un conjunto de regiones reprogramables, cada una, con su própio puente y separación de buses en el FPGA.

__Gestor FPGA__
* Un gestor FPGA es un bloque de _hardware_ que programa un FPGA, bajo el control de un procesador anfitrión.

__Imagen base__
* También llamada "imagen estática".
* Una imagen FPGA, diseñada para reconfigurar al completo el FPGA.
* Una imagen base, podría configurar un conjunto parcial de _regiones de reconfiguración_, para más tarde ser reprogramadas.

    ----------------       ----------------------------------
    |  Host CPU    |       |             FPGA               |
    |              |       |                                |
    |          ----|       |       -----------    --------  |
    |          | H |       |   |==>| Bridge0 |<==>| PRR0 |  |
    |          | W |       |   |   -----------    --------  |
    |          |   |       |   |                            |
    |          | B |<=====>|<==|   -----------    --------  |
    |          | R |       |   |==>| Bridge1 |<==>| PRR1 |  |
    |          | I |       |   |   -----------    --------  |
    |          | D |       |   |                            |
    |          | G |       |   |   -----------    --------  |
    |          | E |       |   |==>| Bridge2 |<==>| PRR2 |  |
    |          ----|       |       -----------    --------  |
    |              |       |                                |
    ----------------       ----------------------------------

> __figura 1__: una configuración FPGA, con una imagen _base_ creando tres regiones. Cada región `PRR0-2`, con buses separados, que son enrutados de forma independiente, por un _puente lógico(soft logic bridge)_ en el FPGA. El contenido de cada `PRR`, podrá ser reprogramado independientemente, mientra el resto del sistema continúa funcionando.

#### <a name="i3">Secuencia</a> ####

Cuando es aplicada una _sobrecarga_ que apunta a una región FPGA, la _región FPGA_, hará lo siguiente:

1. Desactivar los puentes FPGA apropiados.
2. Programar el FPGA utilizando el gestor FPGA.
3. Activar los puentes FPGA.
4. La sobrecarga es aceptada dentro del árbol de dispositivo.
5. Los dispositivos descendentes son definidos.

Al ritirar al sobreposición -o sobregarga, los nodos descendentes seerán retirados y la región FPGA desactivará los puentes.


#### <a name="i4">Zona FPGA</a> ####

La _región FPGA_ represeenta al fpga -matriz de puertas reconfigurble, y a regiones FPGA PR en el DT. Una _región FPGA_ une a los elementos necesarios de un programa, en un sistema en carrera y, añade los dispositivos descendentes.

* Gestor FPGA. 
* Puentes FPGA.
* Información específica de la imagen, necesaria para la programación.
* Nodos descendentes.

El objetivo del _DTO_ es ser utilizado para reprogramar un FPGA, mientras el sistema operativo está en funcionamiento.

Una _Región FPGA_ existente en un _DT_ en activo, refleja su estado. Si el árbol activo, muestra una propiedada `firmware-name`, o nodos descendentes bajo la _Región FPGA_, indicará que el FPGA ya está programado. Un _DTO_ que apunte a una _Región FPGA_, y añada la propiedad `firmware-name`, será tomada como petición para reprogramar el FPGA. Después de la reprogramación tenga éxito, la _sobrecarga_, será aceptada en el _DT_.

La _Región FPGA base_ dentro del DT, representa al FPGA y soportará una reconfiguración completa. Debe incluir un `phandle` a un gestor FPGA. La _Región FPGA base_, será el descendente de uno de los puentes de _hardware_ -el puente que permite el acceso a registros, entre la CPU y el FPGA. Si hubiese más de un puente que controlar, durante la programación del FPGA, la _región_ también contendría una lista de `phandles` a los puentes de _hardware_ FPGA, adicionales.

Para la reconfiguración parcial _PR_, cada _Región PR_, constará con una _Región FPGA_. Estas _Regiónes FPGA_, son descendentes de puentes FPGA, los cuales son descendentes de la _Región FPGA base_. La "reconfiguración completa"




#### <a name="i99">Referencias y agradecimientos</a> ####

[f1] soft logic





__Autor__: Allan Tull 2016

***************

<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
