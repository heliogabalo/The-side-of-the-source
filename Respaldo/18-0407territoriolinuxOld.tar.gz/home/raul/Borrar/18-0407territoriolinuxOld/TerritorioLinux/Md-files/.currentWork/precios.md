RAID controller 

http://www.dell.com/en-us/shop/dell-usb-slim-dvd-rw-drive-dw316/apd/429-aaux/storage-drives-media

1453E

