Soporte al _espacio temprano de usuario_
---------------

> última actualización: 20/12/04

_El espacio temprano de usuario_, son un conjunto de librerías y programas que propor-  
cionan varias piezas de funcionalidad, lo suficientemente importantes, como para estar  
disponibles durante el arranque del _núcleo_, pero que necesitan estar dentro del mismo.  

Consiste en una infraestructura de distintos componentes:  

- `gen_init_cpio`, es un programa que construye un _fichero_ `cpio-format`, conteniendo  
una imagen de sistema de archivo ráiz. Éste fichero está comprimido y, la imagen compri-  
mida está enlazada dentro de la imagen del _núcleo_.  
- `initramfs`,  código que desempaqueta la imagen `cpio` comprimida, en medio del pro-  
ceso de arranque.  
- `klibc`, una librería de `C`, para el _espacio de usuario_ -actualmente empaquetado  
por separado, que es optimizado para mejorar su funcionamiento y minimizar su espacio.

El formato de archivo `cpio` usado por `initramfs` el "newc" -también llamado  
"cpio -H newc". Está documentado en el archivo `buffer-format.txt`[f1](#f1). Hay dos   formas de  
añadir una imagen al _espacio de usuario_: especificando un _fichero_ `cpio` para ser  
usado como imagen, o dejar que el _kernel_ contruya la imagen desde las especifica  -
ciones.  

__Método por fichero `CPIO`.__  

puede crearse un fichero `cpio` conteniendo la imagen del _espacio de usuario temprano_.  
El fichero `cpio`, debería ser especificado en `CONFIG_INITRAMFS_SOURCE`, y será usado  
directamente. Sólo puede ser especificado un archivo `cpio` en `CONFIG_INITRAMFS_SOURCE`  
y el nombre del archivo y del directorio, no está permitido combinarlo con el fichero  
`cpio`.  

__Método por construción de imagen__  

El proceso de construcción del núcleo, puede también construir una imagen de _espacio  
_temprano de usuario _ desde las fuentes, en lugar de suministrar un _fichero_ `cpio`.  
Éste método proporciona una forma de crear imágenes, con permisos de usuario _root_  
-o administrador, incluso cuando la imagen fué construida por un usuario no privile  -  
giado.  

La imagen es especificada como _una_, o más fuentes, en `CONFIG_INITRAMFS_SOURCE`.  
Las fuentes, pueden ser también, _directorios_ o _archivos_. Los ficheros `cpio` no  
están permitidos, cuando se construye desde la _fuente_.  

Un direcotorio de fuentes, tendrá su/sus contenidos empaquetados. El nombre de direc  -
torio especificado será _mapeado_ en `/`. Cuando se empaqueta un directorio, podrá  
traducirse usuarios e _ID_ de grupos no privilegiados. Podrá configurarse  
_INITRAMFS_ROOT_UID_ a un _ID_ de grupo que necesite ser _mapeado_ como grupo  
`root (0)`.  

Un archivo de fuente, debe ser _directivas_, en formato requerido por la utilidad  
`usr/gen_init_cpio`. -ejecutar `usr/gen_init_cpio --help` para obtener el formato de  
archivo. Las directivas en el archivo, serán pasadas directamente a `usr/gen_init_cpio`.  

Cuando son especificados una combinación de directorios y archivos, la imagen  
`initramfs` será agregada a todos ellos. De ésta forma, un usuario podrá crear un  
directorio `root-image` -imagen raíz, e instalar todos los archivos dentro.  
Debido a que archivos de dispositivos especiales, no pueden ser creados por usuarios no  
privilegiados, archivos especiales podrán ser listados en otro archivo `root-file`.  
Ambos; `root-image` y `root-file`, podrán ser listados en `CONFIG_INITRAMFS_SOURCE` y,  
una imagen completa del _espacio temprano de usuario_, podrá ser construida por usuarios  
no privilegiados.

Como nota técnica, cuando directorios y archvos son especificados, se pasará énteramente  
`CONFIG_INITRAMFS_SOURCE` a `scripts/gen_initramfs_list.sh`. Ésto significa que  
`CONFIG_INITRAMFS_SOURCE` podrá ser interpretado como cualquier _argumento legal_ por  
`gen_initramfs_list.sh`. Si es especificado un directorio como argumento, entonces el  
contenido será escaneado, llevándose a cabo _traducciones_ de _uid/gid_, las directivas  
del archivo `usr/gen_init_cpio`, será la salida _-se interpreta fd1_. Si es especificado  
un directorio como argumento a `scripts/gen_initramfs_list.sh`, entonces el contenido  
del archivo, será copiado a la _salida_. Todas las directivas desde elescaneado de  
directorios, al coiado del contenido de un archivo, es procesado por `usr/gen_init_cpio`.





> _[f1]_[__nota d.t.__](f1) en este mismo directorio, territoriolinux lo ha guardado con formato
> `.html` para su apropiada lectura con exploradores.

> __nota d.t.__ en la página [`tmpfs`](kernel/SistemaFicheros/tmpfs.html) se definió el significado de las palabras  
> archivo/fichero, desde una perspectiva _más inglesa!_. Pero como vemos en este  
> documento, se toma una dirección opuesta; __archivo__, es la _unidad mínima_, 
> __fichero__ es el contenedor.

> nota d.t.__mapeado:__ referido a registrar, localizar, situar. 
