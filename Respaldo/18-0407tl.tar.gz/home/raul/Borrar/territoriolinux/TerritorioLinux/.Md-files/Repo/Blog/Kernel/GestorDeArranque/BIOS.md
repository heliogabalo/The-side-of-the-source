TABLA DE CONTENIDOS

  - biosdecode
  - dmidecode
  - flashrom
  - SMBIOS - System management BIOS
  - DMI - Desktop Management Interface
  - DMTF - Desktop Management Task Force
  - PCI - Peripheral Component Interconnect
