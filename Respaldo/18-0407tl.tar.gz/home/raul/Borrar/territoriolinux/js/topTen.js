function myFunction(x) {
    x.classList.toggle("change");
}

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.getElementById("redraw").style.opacity= "0";
    document.getElementById("redraw2").style.opacity= "0";
    document.getElementById("redraw3").style.opacity= "0";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
		document.getElementById("redraw").style.opacity= "1";
		document.getElementById("redraw2").style.opacity= "1";
		document.getElementById("redraw3").style.opacity= "1";
}
