<?php
// Heading
$_['heading_title'] = 'Extensions';

// Text
$_['text_success']  = 'Success: You have modified extensions!';
$_['text_list']     = 'Extension List';
$_['text_type']     = 'Choose the extension type';
$_['text_filter']   = 'Filter';