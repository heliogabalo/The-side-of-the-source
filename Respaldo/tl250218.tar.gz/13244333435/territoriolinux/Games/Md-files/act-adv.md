## Action Adventure Games - Febrero 2018

- gravity Rush 2(T)								- Nier Automata
  gravity Daze 2(japones)					---
- Agents of Mayhem(T)							- Nioh(T)
- Yakuza 0 (G)										- Prey (*)
- Horizon: Zero Down (*)					- Super Mario Odyssey
- The Legend of Zelda: Breath			- Red Dead Redemption 2 (*F)
- Sea of Thieves									- Crackdown 3
- sCumVm													- call of cthulhu
- A Way Out(T)										- fade to Silence
- Days Gone(T)										- Spiderman
- ...															- ...

***************




| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Spiderman | Imsomniac G. | https://insomniac.games/ | n/d 18 | T-pre | email-contact | options | PS4 | 5-9 | 
| Agents of Mayhem| RAD Games Tools | http://www.aomthegame.com/ | ready| T | info@deepsilver.com | option | 8 |
| Nioh | Team Ninja |https://www.gamecity.ne.jp/nioh/outline.html | 071118 | T | mail | option | 8 |
| Yakuza 0 | sega | http://yakuza.sega.com/yakuza0/home.html| 240118 | G | mail | option | 8 |
| Red Dead Redemption 2 | Rock Star Games | https://www.rockstargames.com/reddeadredemption2/ | 261018 |pre G| mail | option | 8 |
| fade to Silence | balckForest G. | https://fadetosilence.com/ | fecha | anunciado | info@bfgames.biz | ec/dlc | 8 |
| A Way Out| EA games | https://www.ea.com/games/a-way-out | 23/03/18 | T | mail | 9 |
| Days Gone | Bend Studio | http://bendstudio.com/ | n/d | T | mail | ErlAcc/dlc | 9 |




---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |
| options -- earlyAccess/DLC |

<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
