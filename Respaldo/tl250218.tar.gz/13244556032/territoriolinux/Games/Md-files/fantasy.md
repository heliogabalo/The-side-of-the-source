## Fantsy Games - Febrero 2018

- Pine													- Rune: Ragnarok*(pre-T)
- Valnir Rok										- Exzore: Rising
- Midle Earth:Shadow o'War(*G)	- Ashes of Creation--FostosMalas
- Dark and Light								- Elex (T)
- Project Wight*								- Shadow of the colossus remake
- Babylon Project**							- GreedFall (T)
- Monster Hunter: World					- Vampyr (T*)
- Wild(T)	muy verde!						- Ealdorlight(T*)
- War of rights(T)							- Black Room

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Project Wight | The outsiders | http://theoutside.rs/ | n/d | T | mail | option | 8 |
| Elex| Piranha Bytes | https://elexgame.com/ | n/d | T | mail | option | 8 |
| Wild| WILD SHEEP STUDIO | http://wildsheepstudio.com/ | n/d| T | mail | option | 8 |
| Rune: Ragnarok| Human Head Studios | https://www.runeragnarok.com/media/| n/d | T | mail | option | 9 |






---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>

