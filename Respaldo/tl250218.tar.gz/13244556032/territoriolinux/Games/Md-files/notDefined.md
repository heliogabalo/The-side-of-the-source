Soul Calibur							- WoW 
black desert online				-
EVE online								-
Blade and Soul						-
Secret World legends			-
RuneScape									-
Tera											-
Final Fantasy XIV					-

--- 
- Death Stranding									- World War Z
- Bayoneta 3
- kingdom come deliverance
- FromSoftware's new project(bloodborne 2?)  -Dreams 
- In the valley of gods 					- Battle Royale
- Extintion*											- The Last of Us
- God of War**
- Ghost of Tsushima								-
- Beyond Good & Eveil 2						- The crew 2(cars simulation?)
- Assassin's Creed: Origins 			- Skull and Bones(q4-18-ps4-xb1-pc)
- For Honor										 		- Crackdown 3
- Dragon B. FighterZ ps4(26/01/18)- Detroit become Human(q1/q2/18)
- Agony(30-03-18) pc-p4-x					- Bloodstained: ritual of the night
- Monster Hunter: World						- Anthem*
- The las Night										- Death Stranding(ideo kohima?)
- Code Vein												- DarkSiders*!
- Biomutant(q1-18)x-pc-p4					-Attack on Titan 2(03-18)xb1-switch-pc-p4
- Shadow of Colossus(remake)			- Fist of North Star (18 ps4)
		02/18/ps4
- Agony(ps4-xb1-pc)								- Days Gone (ps4)
-Jurasi Worl Evolution						- Skull
	(q2-18 ps4-xb1-pc)
