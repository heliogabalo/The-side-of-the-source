-The crew 2													-													-
-...																-													-






***************

| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma |week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| The Crew 2 | Ivory Tower | https://thecrew-game.ubisoft.com/the-crew-2/en-GB/home/ | n/d | T | mail | ErlAcc | 9 |






---
| name | company | page | n/d | anunciado | mail | ErlAcc/dlc | week nº |

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| pre -- BackGroudImg LastWeek |


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
