## ALUBIAS BLANCAS CON VERDURAS
#### 4 personas


#### Ingredientes
- 200  Gr. de Alubias blancas (las que más nos gusten)
- 1 Chorizo de buena calidad   (Extremeño ó un Jabuquito) 
- 1 Pimiento  rojo
- 1 Pimiento  verde
- ½ Cebolla
- ½	Puerro (solo la parte blanca)
- 2 Dientes de ajo
- 4 Cucharadas soperas de aceite AOVE
- Sal y Pimienta al gusto y hoja de laurel




#### PROCEDER

	Poner en remojo la noche anterior las alubias en un recipiente 
  grande y bien cubiertas de agua para que no se sequen.

	Al día siguiente, las ponemos en una cazuela y cubrimos con el mismo 
	agua del remojo.
	Incorporamos el resto de las ingredientes cortados a trozos pequeños, los 
	ajos pelados y con un golpe para aplastarlos.

	Añadimos el aceite AOVE, la sal y la pimienta y cocemos a fuego medio
	durante 50 o 60  minutos, vigilamos la coción  para que se pasen.
	Rectificamos de sal.
	El chorizo incorporarlo las judias lleven 15minutos cociendo.
	Con una espumadera retirar la grasa que suelta el chorizo. Y servir.

     			BUEN PROVECHO
