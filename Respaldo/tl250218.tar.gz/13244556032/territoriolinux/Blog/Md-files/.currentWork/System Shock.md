## System Shock

¿Quien no ha visto en alguna revista la foto de la mujer Robot -SHODAN, con
cables en la cabeza?

Debe ser, junto a la foto de las motos de Tron, uno de los recursos fotográficos
más usados por revistas, foros, programas de TV, etc, en todo el mundo.
Seguro que si apuntásemos el número de veces que se ha reproducido la imagen,
necesitaríamos diez o ciento diez cuadernos, para escribirlo ...

>> ...Nos vigila a través del sistema de seguridad, escuchando nuestras llamadas.
>> Desactiva suficientes computadoras con la tubería de plomo, y SHODAN gruitará
>> frustrada. Anula el terminal equivocado y, su rostro verde, devolverá la 
>> mirada burlándose de tus pequeños esfuerzos humanos...
>> 
>>																									Steven T. Wright
>> https://www.rollingstone.com/glixel/news/why-system-shock-matters-w483835

>> No es una remezcla, es un reinicio!


