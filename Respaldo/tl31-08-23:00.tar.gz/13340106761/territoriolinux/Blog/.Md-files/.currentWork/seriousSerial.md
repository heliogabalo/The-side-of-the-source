

[Referencias y agradecimientos](#i99)

Mailing list -- http://www.linux-usb.org/

  majordomo@vger.kernel.org body--> subscribe
