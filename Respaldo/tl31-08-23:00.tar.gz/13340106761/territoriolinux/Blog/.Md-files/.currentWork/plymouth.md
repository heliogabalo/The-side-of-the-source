## Plymouth


Es un sistema gráfico de arranque. Nunca llegó a funcionar en mi sistema.
Probé de instalar y reinstalar, incluso cargar otros scripts y temas, pero
jamás funcionó. 

Debo añadir para que conste en archivo, que incluso las páginas de manual y
las refencias rápidas por shell son un penoso desastre. Mezclan opciones nuevas? 
viejas?. 

No se si vale la pena leer una sola línea mas sobre este programa o ir directamente
al tipo que mantiene el paquete en la distro y denunciarlo por torpe. Perder el tiempo
por perder el tiempo, es preferible buscar información sobre tal/tales sujetos.


