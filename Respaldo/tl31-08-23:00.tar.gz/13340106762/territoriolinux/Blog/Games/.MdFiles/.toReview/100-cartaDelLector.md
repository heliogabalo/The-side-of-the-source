26/04/11
Hemos recibido un montón de cartas, que han llegado aquí a la redacción de EscenarioDeJuego. Queremos daros las gracias a vosotros, los lectores. Por tomaros el tiempo de escribir cartas como ésta y compartirlas con nosotros.

La cosa esta que arde chicos !!! como sigáis enviando cosas así, vamos a tener que despedir a algún redactor nuestro.



kratos




Kratos, es víctima de sí mismo. Engañado por Ares, comete el más terrible de los actos y mata a su familia. Cuando comprende lo que ha hecho, ya es demasiado tarde. Entonces, la culpa y el arrepentimiento se apoderan de él. Obligándolo a renunciar a su propia vida.


Después de la caída del martillo de bronce, Kratos, olvidó completamente quien fue. Es entonces, cuando emprende una vida entre mortales. Ajeno a los oscuros planes de Ares, rehace su vida, junto a su familia.


Los Dioses conocían las consecuencias de la caída del martillo, por eso abandonan la tierra, antes de que se produzca el acontecimiento. Tártaro, hermano de Caos, Gea y Eros. Tras golpear su gran puño contra el suelo, desencadena la creación. La guerra, la libertad, el origen del bien y del mal…, haciéndola saltar en pedazos.



A medida que la energía liberada en la explosión, pierde fuerza y velocidad, los materiales dispersos se cohesionan, formando así, el Gran martillo. Durante nueve días y sus noches, Kratos, ve caer el pesado metal.


Tártaro. El Dios maligno. Aprovecha el momento, para consolidar su reino.

Marcando una distancia de nueve días y nueve noches, delimita sus dominios y, el Hades. Justo la distancia entre el cielo y la tierra.


Algunos, cuentan que Tártaro, es padre de Kratos, y que fruto de incesto con su hermana Gea, provocan la disruptora energía, capaz de crearlo todo. Por eso Atenea, arriesga su condición de Diosa, presentando a Kratos, ante la corte de Dioses… Otra leyenda sin embargo, explica que Atenea salvó a Kratos, porque era ella su verdadera hermana.


Cronos el titán. Encerró a los cíclopes en el Tártaro. Pero Zeus los liberó. Para lograr su apoyo en la lucha contra los Titanes.

La gran guerra lo llamaron. Kratos los odiaba, los odiaba a todos. Por convertir su vida en un infierno. Así pues, consagró su existencia a perseguirlos. Kratos pensó que arrojándose al acantilado del olvido, lograría llegar rápidamente al Tártaro.


Mientras su cuerpo, dolorido por la guerra, aceleraba la caída, los brazos de Atenea, alcanzaron oportunamente el cuerpo inerte de Kratos. Rescatándolo de las fauces de un terrible desenlace.


Atenea, llevó a Kratos al Olimpo. Después de ser nombrado sucesor, del Dios de la Guerra, el resto de Dioses empezaron a cuestionar sus acciones. Y decidieron no aceptarlo entre ellos.

Kratos fue humano una vez. Así, los otros Dioses reprocharon su humanidad. Aludiendo a un vil argumento. - Cualquier candidato, a la sucesión de un Dios, deberá poseer sus mismas cualidades, o dones.


Kratos fue repudiado, por los Dioses, y castigado por su crimen. Fue arrojado al Tártaro. Tal y como él quería, antes de que Atenea lo rescatase.

Esta vez, llevaba consigo la espada del Caos, cuya empuñadura fue tallada en bronce y, su memoria recuperada. Tuvo que salir de allí, aprovechando el momento en que Zeus, liberaba a los Cíclopes, en su lucha contra los titanes. Y de regreso a la tierra, pidió a las Hermanas del Destino, que le dejasen usar el telar mágico, y llegar al memento justo.


Vio como su lucha se situaba en terreno de nadie. En medio de todo. Acosado por un fuego cruzado, que provenía de ambas direcciones.

La guerra entre Dioses y Titanes. Era su terreno de juego. Su campo de batalla. El Hades. Una porción del Inframundo, antesala del averno. Lugar sombrío y oscuro, donde la única luz, es la que proviene de las llamas abrasadoras, que despiden los ríos de lava.









