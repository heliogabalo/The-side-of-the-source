colage de imagenes

	[foto]
[foto][foto]
		[foto]
[foto][foto]
	[foto]



