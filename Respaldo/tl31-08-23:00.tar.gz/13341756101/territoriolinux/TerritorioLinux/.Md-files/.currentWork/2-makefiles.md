[Tabla de contenidos](#i1)
[Introducción](#i2)
[Quién hace qué](#i3)
[Los archivos _kbuild_](#i3i1)
[Definición de objetivos](#i3i1i1)
[Archivos _objeto_ integrados `obj-y`](#i3i1i2)
[Propósito de los módulos _cargables_ `obj-m`](#i3i1i3)
[Objetos que exportan _símbolos_](#i3i1i4)
[Propósito de los archivos _librerías_ `lib-y`](#i3i1i5)
[Descendiendo a los directorios](#i3i1i6)
[Compilación de opciones](#i3i1i7)
[Seguimiento de las dependencias](#i3i1i9)
[Reglas especiales](#i3i1i10)
[Soporte a las funciones `$(CC)`](#i3i1i11)

[Listar directorios que visitar, al descender](#i6i4)

[Referencias y agradecimientos](#i99)
--- 

## _Makefiles_ en el kernel de Linux ##

El codumento describe los archivos _Makefiles_ en el kernel de Linux.


### [Tabla de contenidos](i1) ###

- Introducción
- Quién hace qué
- Los archivos _kbuild_
  -	Definición de objetivos
  - Archivos _objeto_ integrados `obj-y`
  - Propósito de los módulos _cargables_ `obj-m`
  - Objetos que exportan _símbolos_
  - Propósito de los archivos _librerías_ `lib-y`
  - Descendiendo a los directorios
  - Compilación de opciones
  - Dependencias de la línea de comandos
  - Seguimiento de las dependencias
  - Reglas especiales
  - Soporte a las funciones `$(CC)`
  - Soporte a las funciones `$(LD)`
- Soporte a programas _Host_
  - Programas _Host_ simple
  - Composición de programas _Host_
  - Empleo de `C++` en programas _Host_
  - Control de las opciones del compilador en programas _Host_
  - Cuándo son construidos los programas _Host_
  - Utilización de `hostprogs-$(CONFIG_FOO)`
- _Kbuild_, infraestructura _limpia_
- Arquitectura de archivos _Makefiles_
  - Configuración de variables, para complementar la construcción de la arquitectura
  - Añadir _prerrequisitos_, a `archheaders:`
  - Añadir _prerrequisitos_, a `archprepare:`
  - Listar directorios que visitar, al descender
  - Imagenes de arranque, específicos de la arquitectura
  - Construcción de objetivos _no-kabuild_
  - Comandos útiles, en la construcción de una imagen de arranque
  - Comando _kbuild_ personalizados
  - Procesando _scripts_ del enlazador
  - Archivos genéricos de cabecera
  - Pasar enlaces _post-link_
- Sintaxis _kbuild_ en cabeceras exportadas
  - Cabeceras no exportables
  - `generic-y`
  - `generated-y`
  - `mandatory-y`
- Variables _kbuild_
- Lenguaje _Makefile_
- Créditos
- `TODO`
  

### [Introducción](i2) ###

Los archivos _Makefiles_ contienen cinco partes:

_Makefile_ 												El principio del archivo.
`.config` 													el archivo de configuración del kernel.
`arch/$(ARCH)/Makefile`  la arquitectura del archivo _Makefile_.
`scripts/Makefile.*`				  reglas comunes etc. para todos los archivos _Makefiles_ en kabuild.
_kbuild Makefiles_						son cerca de 500.

Al principio del archivo Makefile, será leído el archivo `.config`, el cuál proviene del proceso de configuración del kernel.

El principio del archivo, es responsable de la construcción de dos _elementos_ importantes:
`vmlinux`, la imagen residente del kernel y, los módulos -cualquier archivo de módulo.
Todo esto es construido de manera recursiva, descendiendo a los subdirectorios en el _árbol fuente_ del kernel.
La lista de subdirectorios _visitada_, dependerá de la configuración del kernel. El principio del archivo, incluye textualmente, una arquitectura _Makefile_, con el nombre `arch/$(ARCH)/Makefile`. La arquitectura Makefile, porporciona información específica, acerca de la misma indicada al principio del archivo.

Cada subdirectorio, tendrá un _kbuild Makefile_, el cuál sucede los comandos, de forma secuencial; _de arriba a abajo_. El archivo _kbuild Makefile_, utiliza la información del archivo `.config`, para constuir varias listas de archivos, utilizadas por kbuild, para constuir cualquier objetivo modular integrado en la construcción.

`scripts/Makefile.*` contiene todas las definiciones/reglas etc. usada en la construcción del kernel, basado en los archivos _kbuild Makefiles_.


### [Quién hace qué](i3) ###

Las personas, tienen cuatro _relaciones_ distintas, con los Makefiles del kernel.

__Usuarios__: personas que construyen kernels. Aquellos, que escribirían comandos tales como; `make menuconfig` ó `make`. Es habitual que no lean o editen ningún _Makefile_ del kernel -o cualquier otro archivo fuente.

__Desarrollador regular__, trabajan en características tales, como _controladores de dispositivo_, _sistemas de archivo_ y, _protocolos de red_. Estas personas, necesitan _mantener_ los archivos , del subsistema en el que tabajan. Para llevar a cabo esta tarea, es necesario cierto conocimiento acerca de los archivos kbuild Makefiles, además de otros aspectos relacionados con la interfase pública de kbuild.

__Desarrollador de arquitectura__, persnas que trabajan en una _plataforma_ en particular. Como `sparc` o `ia64`. Los desarrollador de plataforma, necesitan conocer tanto el Makefile como los archivos kbuild Makefiles relacionados.

__Desarrollador kbuild__,  trabajan en el _sistema de construcción del kernel_, en sí mismo.
Imprescindible conocer todos los aspectos relativos a los archivos Makefile del kernel.

El presente documento está dirigido al __Desarrollador regular__ y al __Desarrollador de arquitectura__.


### [Los archivos _kbuild_](i3i1) ###

La mayoría de _Makefiles_[f1](#f1) parte del kernel, son archivos tipo _Makefile_, que hará uso de la infraestructura _kbuild_. Este capítulo intruduce la sintaxis utilizada en tales archivos -_kbuild Makefiles_.
El nombre preferido para estos archivos _kbuild_, es _Makefile_, aunque _kbuild_ es igualmente usado. Si ambos archivos existen, será empleado _kbuild_.

La Sección [Definición de objetivos](#i3i1i1) es una rápida introducción, otros capítulos proporcionan más detalle, con ejemplos reales.

### [Definición de objetivos](i3i1i1) ###

La definición de objetivos es la parte principar -el corazón, del los archivos _kbuiild_.
Estas líneas, definen los archivos a ser construidos, cualquier opción de compilación y, cualquier subdirectorio al que _entrar recursivamente_.

El archivo makefile kbuild mas simple, contiene una línea:

Ejemplo,

		obj-y += foo.o

Esto dice a kbuild que hay un objeto en el directorio, llamado `foo.o` a ser construido desde `foo.c` o `foo.S`.

Si `foo.o` debiera ser construido como módulo, será empleada la variable `obj-m`.
Consecuentemente, será utilizado el siguiente patrón.

Ejemplo,

		obj-$(CONFIG_FOO) += foo.o

`$(CONFIG_FOO)` evalua tanto `y` -como parte de, o `m` -por módulo.
Si `CONFIG_FOO` no es ni `y` ni `m`, entonces el archivo no será compilado o enlazado.


### [Archivos _objeto_ integrados `obj-y`](i3i1i2) ###

El Makefile kbuild, especifica archivos de objeto en la `vmlinux` con la lista `$(obj-y)`. Esta lista, depende de la configuración del kernel.

Kbuild compila todos los archivos `$(obj-y)`. Después llama a `$(AR) rcSTP`, para mezclar todos los archivos en un archivo `integrado.a`.
Es un pequeño _fichero_, sin tabla de símbolos, el cuál resulta impracticable, como entrada al enlazador.

El escrito -_script_, `scripts/link-vmlinux.sh` hará después un agregado con `${AR} rcsTP`, el cuál crea un archivo _ligero_, con una tabla de símbolos y un índice, convirtíendolo en una entrada válida, para la imagen final `vmlinux`.

El orden de los archivos en `$(obj-y)` es imortante. Están permitidos los duplicados: la primera instancia, será enlazada dentro del `integrado.a`, sucesivas instancias ignoradas.

El orden de enlace es importante, por que ciertas funciones `module_init() __initcall` serán llamadas durante el arranque, en orden de aparición. Recordar, que cambiar el orden de los enlaces, podría cambiar el orden en el que los controladores SCSI fuesen detectados, _reenumerando_ los discos.

Ejemplo:

		#drivers/isdn/i4l/Makefile
		# Makefile for the kernel ISDN subsystem and device drivers.
		# Each configuration option enables a list of files.
		obj-$(CONFIG_ISDN_I4L)         += isdn.o
		obj-$(CONFIG_ISDN_PPP_BSDCOMP) += isdn_bsdcomp.o


### [Propósito de los módulos _cargables_ `obj-m`](i3i1i3) ###

`$(obj-m)` especifica archivos objeto, los cuales serán construidos como módulos _cargables_ por el kernel.

Un módulo, podría ser construido desde un archivo fuente o varios. En el primer caso, el makefile kbuild, simplemente añadirá el archivo a `$(obj-m)`.

Ejemplo:

		#drivers/isdn/i4l/Makefile
		obj-$(CONFIG_ISDN_PPP_BSDCOMP) += isdn_bsdcomp.o

> __Nota__: en este ejemplo `$(CONFIG_ISDN_PPP_BSDCOMP)` evalua `m`.

Si un módulo del kernel es construido desde distintas fuentes, la forma de especificar cómo constuir el módulo, es la misma; aunque kbuild, necesitará saber qué _archivos objeto_, participarán en la construcción del módulo, así que habrá que especificarlo, mediante la variable `$(<module_name>-y)`.

Ejemplo,

		#drivers/isdn/i4l/Makefile
		obj-$(CONFIG_ISDN_I4L) += isdn.o
		isdn-y := isdn_net_lib.o isdn_v110.o isdn_common.o

En el ejemplo, el nombre del módulo será `isdn.o`. Kbuild compilará los objetos listados en `$(isdn-y)`, después ejecutará `$(LD) -r` sobre la lista de esos archivos, para generar `isdn.o`.

Dado que kbuild reconoce `$(<module_name>-y)` en la composición de objetos, es posible utilizar el valor de un `CONFIG_ symbol`, para opcionalmente incluir un archivo de objeto, como parte de la composición de un objeto.

Ejemplo:
		#fs/ext2/Makefile
	        obj-$(CONFIG_EXT2_FS) += ext2.o
		ext2-y := balloc.o dir.o file.o ialloc.o inode.o ioctl.o \
			  namei.o super.o symlink.o
	        ext2-$(CONFIG_EXT2_FS_XATTR) += xattr.o xattr_user.o \
						xattr_trusted.o

En este ejemplo, `xattr.o xattr_user.o` y `xattr_trusted.o` sólo _son parte_ en la composición del objeto `ext2.0` si `$(CONFIG_EXT2_FS_XATTR)` evalua `y`.

> __Nota__: por supuesto, al construir objetos dentro del kernel, la sintaxis de arriba, también funcionará. Por tanto, si la opción es `CONFIG_EXT2_FS=y`, kbuild construirá un archivo `ext2.o` al margen de partes individuales, enlazando entonces, con `integrado.a`; tal y como cabría esperar.

### [Objetos que exportan _símbolos_](i3i1i4) ###

Notaciones requeridas en los makefiles, no son necesarias para los módulos que esportan símbolos.


### [Propósito de los archivos _librerías_ `lib-y`](i3i1i5) ###

Los objetos listados con `obj-*`, son utilizados para los módulos, o combinados en un `integrado.a`, que especifique el directorio.
Aparece la posibilidad de listar objetos, incluyéndolos en una librería `lib.a`.
Todos los objetos listados con `lib-y, serán combinados en una librería única, para ese directorio.
Objetos listados en `obj-y`, adicionalmente listados en `lib-y`, no serán incluidos en la librería, ya que podrán ser accedidos de igual forma.
En cuánto a consistencia; los objetos listados en `lib-m` serán incluidos en `lib.a`.

> __Nota__: algunos makefile kbuild, podrían listar archivos por _construir en_ y, que fuesen parte de una librería. Tanto más, el mismo directorio podría contener ambos; `integrado.a` y `lib.a`.

Ejemplo,
		#arch/x86/lib/Makefile
		lib-y    := delay.o
		
Esto creará un librería `lib.a` basada en `delay.o`. Para que kabuild reconozca que está siendo construida `lib.a`, el directorio deberá ser listado en `libs-y`.
Ver  también [Listar directorios que visitar, al descender](i6i4).

El uso de `lib-y` es normalmente restringido a `lib/` y a `arch/*/lib`.


### [Descendiendo a los directorios](i3i1i6) ###

Un _Makefile_ sólo es responsable de construir objetos en su própio directorio. Archivos en subdirectorios, deberían ser tenidos en cuenta por los _Makefiles_ en respectivos directorios. El sistema de construcción invocará `make`, de manera recursiva, en los subdirectorios indicados.

Para ésto será utilizado `obj-y` y `obj-m`.
`ext2` _vive_ en un directorio separado. El _Makafile_ presente en `fs/` indica a kbuild, _cómo_ descender, utilizando la siguiente asignación:

Ejemplo,

		#fs/Makefile
		obj-$(CONFIG_EXT2_FS) += ext2/

Si `CONFIG_EXT2_FS` es configurado con `y` -<kbd>integrado</kbd> o `m` <kbd>modular</kbd>, será empleada la correspondiente variable `obj-` y, kbuild descenderá al directorios `ext2`.
Kbuild sólo usa esta información para decidir _cuándo_ visitar el directorio. El Makefile situado en tal directorio, especificará _qué es modular_ y, _qué es integrado_.

Es una buena práctica utilizar la variable `CONFIG_`, en la asignación de nombres de directorios. Esto permitirá a kbuild omitir el directorio, si la correspondiente opción `CONFIG_`, contiene `y`, `m`, o ninguna de ellas.


### [Compilación de opciones](i3i1i7) ###

`ccflags-y, asflags-y` y `ldflags-y`, Estas tres opciones -banderas, _flags_, únicamente son aplicables al makefile kbuild asignado. Son utilizadas en todas las invocaciones a`cc` -para compilar y, `ld` -para enlazar, sucedidas durante la construcción recursiva.

> __Nota__: opciones con un comportamiento similar, dónde fueron previamente nombradas: `EXTRA_CFLAGS, EXTRA_AFLAGS` y `EXTRA_LDFLAGS`; continuarán siendo soportadas, aunque su empleo es depreciado -obsoleto.

		ccflags-y specifies options for compiling with $(CC)

Ejemplo,
		# drivers/acpi/acpica/Makefile
		ccflags-y			:= -Os -D_LINUX -DBUILDING_ACPICA
		ccflags-$(CONFIG_ACPI_DEBUG)	+= -DACPI_DEBUG_OUTPUT

Esta variable es necesaria, por que el Makefiles _ostenta_ la variable `$(KBUILD_CFLAGS)` y, la utiliza como opción de compilación, en todo el directorio.

`asflags-y` especifica la opción de ensamblado, mediane `$(AS)`.

Ejemplo,
		#arch/sparc/kernel/Makefile
		asflags-y := -ansi

`ldflags-y` especifica la opción de enlazado, mediane `$(LD)`.

Ejemplo,
		#arch/cris/boot/compressed/Makefile
		ldflags-y += -T $(srctree)/$(src)/decompress_$(arch-y).lds

`subdir-ccflags-y, subdir-asflags-y`. Las dos opciones listadas arriba, son similares a `ccflags-y` y ` asflags-y`. La diferencia es que la variante `subdir-`, tiene efecto sobre el archivo kbuild, donde estén presentes y, en todos los subdirectorios.
Las opciones especificadas mediante `subdir-*` son añadidas a la _línea de comando_, antes de especificar la opción, por medio de variantes de _non-subdir_.

Ejemplo,
		subdir-ccflags-y := -Werror
		
		CFLAGS_$@, AFLAGS_$@

`CFLAGS_$@` y `AFLAGS_$@`, únicamente son aplicables, a comandos en el makefile kbuild activo.

`$(CFLAGS_$@)` especifica opciones por archivo, con `$(CC)`. La parte `$@`, tiene un valor literal, el cuál especifica el archivo para el que és.

Ejemplo,
		# drivers/scsi/Makefile
		CFLAGS_aha152x.o =   -DAHA152X_STAT -DAUTOCONF
		CFLAGS_gdth.o    = # -DDEBUG_GDTH=2 -D__SERIAL__ -D__COM2__ \
				     -DGDTH_STATISTICS

Estas dos líneas especifican las opciones de compilación para `aha152x.o` y `gdth.o`.

`$(AFLAGS_$@)` es una característica similar, para los archivos fuente, en lenguaje ensamblador.

Ejemplo,
		# arch/arm/kernel/Makefile
		AFLAGS_head.o        := -DTEXT_OFFSET=$(TEXT_OFFSET)
		AFLAGS_crunch-bits.o := -Wa,-mcpu=ep9312
		AFLAGS_iwmmxt.o      := -Wa,-mcpu=iwmmxt
		

### [Seguimiento de las dependencias](i3i1i9) ###

Kbuild _sigue las dependencias_, así:
- 1. Todos los archivos requeridos(tanto `*.c` como `*.h`).
- 2. Todas las opciones `CONFIG_`, en archivos requeridos.
- 3. La líne de comandos utilizada, para compilar el objetivo.

Por tanto, de cambiar la opción `$(CC)`, todos los archivos afectados serán recompilados.


### [Reglas especiales](#i3i1i10) ###

Son utilizadas reglas especiales cuando la infraestructura kbuild, no proporcione el soporte requerido. Un ejemplo típico, son los archivos de _cabecera_ generados durante el proceso de construcción.
Otro ejemplo, son los Makefiles específicos de la _arquitectura_, los cuales necesitan reglas especiales, en la _composición_ de imágenes de arranque etc.

Las reglas especiales, son escritas como reglas normales Make.
Kbuild no será ejecutado en el directorio, donde el Makefile es localizado, así que las _reglas especiales_, deberían proporcionar una ruta relativa a archivos _pre-requeridos_ y _archivos objetivo_.

Son utilizadas dos variables en el momento de definir una regla especial:

		$(src)
`$(src)` es una ruta relativa, la cuál apunta al directorio donde está localizado el Makefile. Utilizar siempre `$(src)`, al referir alrchivos localizados en el _árbol_ `src` -fuente.

		$(obj)
`$(obj)` es una ruta relativa, la cuál apunta al directorio donde está guardado el objetivo. Utilizar siempre `$(obj)`, al referir alrchivos generados.

Ejemplo,
		#drivers/scsi/Makefile
		$(obj)/53c8xx_d.h: $(src)/53c7,8xx.scr $(src)/script_asm.pl
			$(CPP) -DCHIP=810 - < $< | ... $(src)/script_asm.pl

Es esta una regla especial; siguiendo la sintaxis habitual requerida por make.
El _objetivo_, depende de dos _pre-requisitos_ de archivo. Referencias al _archivo objetivo_, añaden el prefijo `$(obj)`, referencias a _pre-requisitos_, añaden `$(src)` -puesto que no son archivos generados.

		$(kecho)
Presentar información al usuario mediante una _regla_, resulta una buena práctica, pero al ejecutar `make -s`, no cabe esperar ver ninguna salida, exceptuando _avisos/errores_ -warning/errors.
Para dar soporte a lo anterior, kbuild define `$(kecho)`, presentando el texto seguido de `$(kecho)` sobre la salida estandar(fd1), salvo si es utilizado `make -s`.

Ejemplo,
		#arch/blackfin/boot/Makefile
		$(obj)/vmImage: $(obj)/vmlinux.gz
			$(call if_changed,uimage)
			@$(kecho) 'Kernel: $@ is ready'
			

### [Soporte a las funciones `$(CC)`](i3i1i11) ###

El kernel podría ser construido junto a distintas versiones `$(CC)`, cada una de ellas, con soporte a un único grupo de características y opciones.
Kbuild proporciona soporte básico a la comprobación de opciones válidas de `$(CC)`.
`$(CC)`, habitualmente el compilador `gcc`. También disponibles, otras alternativas.

		as-option
`as-option`, es utilizada para comprobar si `$(CC) --`, fue empleada para compilar archivos ensamblador `*.S`, soportan la opción dada. Una segunda opción alternativa, podría ser especificada si la primera opción no fuese soportada.

Ejemplo,

		#arch/sh/Makefile
		cflags-y += $(call as-option,-Wa$(comma)-isa=$(isa-y),)

En el ejemplo de arriba, `cflags-y` será asignada la opción `-Wa$(comma)-isa=$(isa-y)`, si es soportada por `$(CC)`.
El segundo argumento es opcional y, de ser porporcionado, será utilizado si el primer argumento no tiene soporte.

		cc-ldoption
`cc-ldoption`, es utilizado para comprobar si `$(CC)` fue empleado para enlazar _archivos objeto_, soportados por una determinada opción. Podrá ser indicada una segunda alternativa, de no haber soporte a la primera.

Ejemplo,
		#arch/x86/kernel/Makefile
		vsyscall-flags += $(call cc-ldoption, -Wl$(comma)--hash-style=sysv)
		
En el ejemplo anterior, `vsyscall-flags` asignará la opción `-Wl$(comma)--hash-style=sysv`, si hay soporte a `$(CC)`. El segundo argumento es opcional. Podrá ser indicada una segunda alternativa, de no haber soporte a la primera.

		as-instr
`as-instr` comprueba si el ensamblador, informa acerca de una instrucción específica, imprimiendo tanto la _opción1_ como _opción2_.
_Secuencias de escape_ C, tienen soporte en la _instrucción de ensayo_.

> __Nota__: la opción `as-instr`, utiliza `KBUILD_AFLAGS` en las opciones `$(AS)` -ensamblador.

		cc-option
`cc-option`, es utilizada para comprobar si `$(CC)` da soporte a determinada opción, si no es así, será utilizada una segunda alternativa opcional.

Ejemplo,
		#arch/x86/Makefile
		cflags-y += $(call cc-option,-march=pentium-mmx,-march=i586)

En el ejemplo de arriba, `cflags-y` asignará la opción `-march=pentium-mmx` si es soportado por `$(CC)`, de cualquier otra forma, `-march=i586`.
El segundo argumento a la alternativa `cc-option`, es opcional. Si es omitida, `cflags-y` no asignará ningún valor, de no haber soporte a la primera opción.

> __Nota__: `cc-option` utiliza `KBUILD_CFLAGS` en opciones `$(CC)`.

		cc-option-yn
`cc-option-yn`, es utilizada para comprobar si `gcc` soporta determinada opción, retornando <kbd>y</kbd> en caso afirmativo, <kbd>n</kbd> en caso contrario.

Ejemplo,
		#arch/ppc/Makefile
		biarch := $(call cc-option-yn, -m32)
		aflags-$(biarch) += -a32
		cflags-$(biarch) += -m32

En el ejemplo anterior, `$(biarch)` establece <kbd>y</kbd>, si `$(CC)` soporta la opción `-m32`. Siempre que `$(biarch)` sea igual a <kbd>y</kbd>, las variables _expandidas_ `$(aflags-y)` y `$(cflags-y)`, asignarán los valores `-a32` y `-m32`, respectivamente.

> __Nota__: `cc-option-yn` utiliza `KBUILD_CFLAGS` en opciones `$(CC)`.

		cc-disable-warning
`cc-disable-warning` comprueba si `gcc` da soporte a _advertencias_, retorna el _conmutado de línea_, para desactivarlo. Esta función especial, es necesaria puesto que `gcc v4.4` y posteriores, aceptan cualquier opción `-Wno-*` desconocida y, sólo avisa de ello, si algúna otra advertencia en el archivo fuente.

Ejemplo,
		KBUILD_CFLAGS += $(call cc-disable-warning, unused-but-set-variable)

El ejemplo añade `-Wno-unused-but-set-variable` a la variable `KBUILD_CFLAGS`, sólo si `gcc` la acepta realmente.

		cc-version
`cc-version`, retorna una versión numérica, de la versión del compilador `$(CC)`.
El formato es `<mayor><menor>`, dónde ambos son dígitos. Por ejemplo, `gcc 3.41` retornará <kbd>0341</kbd>.
`cc-version`, resulta útil cuando una versión específica de `$(CC)`, es erronea en determinda área, por ejemplo, `-mregparm=3` resultó _rota_ en algunas versiones `gcc`, incluso siendo aceptada por el mismo.

Ejemplo,
		#arch/x86/Makefile
		cflags-y += $(shell \
		if [ $(cc-version) -ge 0300 ] ; then \
			echo "-mregparm=3"; fi ;)

El ejemplo de arriba, `-mregparm=3` sólo es utilizado en versiones 3.0 de `gcc`, o posteriores.

		cc-ifversion
`cc-ifversion` _prueba_ la versión de `$(CC)`, e iguala(`:=`) el cuarto parámetro si la _expresión de versión_ es _cierta_, o la quinta -de ser aportada, si la _expresión de versión_ es _falsa_.

Ejemplo,
		#fs/reiserfs/Makefile
		ccflags-y := $(call cc-ifversion, -lt, 0402, -O1)

> __n. de t.__: `ccflags-y <u>:=</u> $(call cc-ifversion, -lt, 0402, <u>-O1</u>)`.

En este ejemplo, `ccflags-y` asignará el valor `-01` si la versión `$(CC)` es menor a 4.2.
`cc-ifversion` toma todos los operadores de _shell_:
`-eq, -ne, -lt, -le, -gt, and -ge`
El tercer parámetro podría ser un texto, como lo és, en aquí, aunque podría ser una variable _expandida_ o una _macro_.






### [Referencias y agradecimientos](i99) ###


__[f1](f1)Makefile__, archivo constructor.
Objeto, 
Objetivo,
to break, romper; "la secuencia normal en un programa, rompe su ejecución debido a un error en el código".
---

<ul id="firma">
	<li><b>Traducción:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
