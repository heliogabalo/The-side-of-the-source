#### SouthBridge
Suele implementar las capacidades mas "lentas" de la placa,
integra la CMOS. También llamado ICH - I/O Controller Hub

El puente sur, es el encargado de manejar las funciones de entrada y salida,
como un USB, el audio, puertos serie, el sistema BIOS o el BUS ISA, el controlador
de interrupciones y los canales IDE.
