



Battlefield: Heardline, será presentado el próximo 19 de marzo de 2015. Todo apunta a que será una de las grandes producciones del año.

De la mano de Visceral Games y Ea Digital Illusion CE, el juego a generado grandes expectativas entre los apasionados del género.


En esta entrega de Battlefiel: Hardline, el protagonista es un detective residente en Miami, Nick Mendoza.

Bajo una trama indudablemente policial, deberá desenvolverse entre policías corruptos y una peligrosa  red, de criminales.


Battlefield :Heardline promete ser un referente del género de acción, colocando al jugador en situaciones trepidantes, que deberá resolver enfrentándose a sus adversarios, fuertemente armados y adiestrados.


Género: Acción, Shooter, Acción en primera persona, Bélico

Modo de juego: Un jugador, Multijugador.

Plataformas: Microsoft Windows, PlayStation3, PlayStation4, Xbox One, Xbox 360.



EscenarioDeJuego
