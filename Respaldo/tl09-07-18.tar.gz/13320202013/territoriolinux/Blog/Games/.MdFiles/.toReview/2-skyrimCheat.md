
Quieres subir rápidamente la habilidad Herrería?


Sólo necesitas unas 1000 monedas de oro. Dirígete a cualquier  
vendedor de lingotes de hierro y tiras de cuero. El primer  
edificio a la derecha al entrar en Whiterun(Carrera Blanca) es  
mejor para esto. Compra tantos lingotes de hierro y tiras de  
cuero como puedas. A continuación, hay que construir tantas  
dagas de hierro como se pueda. La habilidad herrería aumentará  
su valor en 1, por para cada daga forjada. Esto es, ganar un  
nivel de habilidad. Pero ojo, hay que empezar a subir la  
habilidad pronto, pues para subir el nivel de la habilidad, se  
necesitará crear tantas dagas, como niveles tenga el personaje.  

Es decir, si tu personaje está en nivel 1, necesitas crear 1  
daga, para subir 1 nivel la habilidad herrería.  

En nivel 2(personaje), se necesitan crear 2 dagas, para subir 1  
nivel la habilidad herrería.  

... y así sucesivamente.

Después vende las dagas que hayas creado, al mismo vendedor.  

Lógicamente, las existencias del mercader se terminan antes, que  
las ganas de pasar de nivel.  

Aquí es donde hay que aplicar la estrategia, hay dos opciones  
para optimizar este proceso.  

__1º Método__ El pueblo donde empiezas después de la presenta-  
ción, tiene lo necesario para conseguir el objetivo.  

En la serrería, podremos cortar leña y venderla. Acércate al  
tocón y coge el hacha, apunta con la mira, hacia el "árbol ya  
cortado" y repite el proceso tantas veces, como leña (kilos)  
puedas cargar.  
La leña puede venderse al encargado de la serrería. Está justo  
al lado. Hay que dejar pasar 24-48 horas, para que el vendedor  
renueve las existencias.  

Muy cerca,   está  también  la herrería,   donde podrás seguir  
haciendo dagas, para subir la habilidad.  

__2º Método__ Abre la cónsola con el botón que hay justo debajo  
de la tecla ESC, `º`. Si tienes teclado inglés la tecla es `~`.  

Ahora únicamente tienes que escribir el siguiente código:  

`player.additem 0000000f 500`  

Fíjate que entre la `m` de additem, y el cero de `itemID` hay  
un espacio. Entre la `f` de `itemID` y la pasta `num` hay otro  
espacio.  

Este código añadirá 500 monedas en tu haber.  
