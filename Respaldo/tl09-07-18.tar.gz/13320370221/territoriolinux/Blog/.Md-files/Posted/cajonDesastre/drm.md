
DRM - Direct Rendering Manager. Gestor de renderización directa. Es decir, digital right manager
o gestión digital de derechos, __no__ es lo mismo. Es como si nos empeñamos en decir que USA,
significa, utilizar algo.
Si hiciese esa afirmación, estaría engañando a la gente. Aunque sea yo venezolano, sé
perfectamente que USA, significa, United States of America. Un país.

Una idea, organización, sociedad, etc, que por su importancia, debe respetarse, la asociación
del acronimo a su significado; universalmente conocido.

... Y qué es el DRM? pués sin entrar demasiado en tecnicismos, o jerga de programación, por sí
mismo se explica. La livertad. La fraternidad, el amor por el pŕogimo como por uno mismo,
sin importar, las fronteras, los países o el color de la caja de ordenador -la mía es negra.

Es el renderizado del código binario, sobre el monitor. Expresado de forma simplista, ésto es,
evitar el _Uso_ de complejos subsistemas, como motores gráficos. Con el objeto de conseguir
un ahorro en recursos, que más tarde, podrán ser usados para obtener mayor eficiencia, desde una
perspectiva global de sistema.

Los motores gŕaficos, son algo positivo. Aportan funcionalidad, centralizando los recursos,
desde donde serán administrados. Evitan que los usuarios, tengan que manipular complejos
archivos de configuración, para llevar a cabo tareas, que hoy en día, están muy automatizadas.

Los _pros_ y los _contras_ de los _motores_, son tan variados como humanos hay en el planeta.
Conocemos, Xorg, DirectX, Open AL/GL, pero hay más.

Receintemente, ha llegado a mi oídos, la caída de uno de los grandes, y con amarga
decepción, tuve que desistir de mis _investigaciones_ y _pesquisas_.
Un grupo Alemán, estaba trabajando en un _motor_, basado en este tipo de tecnología, DRM, pero
al parecer, en 2013 el proyecto llegó a su fin.

DFB, Direct Frame Buffer. Personalmente, es muy satisfactorio ver que concretamente desde ese país,
Alemania, se gestase algo de ese calibre. Eso significa, que hay gente _buena de verdad_ en todos
lados, y que desgraciadamente; la vida, tiene un precio que todos debemos pagar. Por que así son
las cosas.

Desde los gobiernos; los centros de poder, debe encontrarse una _formula_ para reconciliar
el altruísmo personal, derechos y obligaciones de los ciudadano y, los mecacinsmos que usamos
para enriquecernos o morirnos de hambre. Son conceptos que hoy en día, viven pelados como el
_perro y el gato_.

Los intereses de las grandes corporaciones, imperan sobre cualquier otra idea o directriz.
Es verdad que en determinadas ocasiones, _resurgen de las cenizas como el fenix_ proyectos tan
antiguos como el _sol_, DFB es un ejemplo.

También es verdad que otros proyectos, amenazan la existencia de la vida en armonía, por el
simple hecho, de borrar del mapa cualquier atisbo de gobierno. ¿Es posible imaginar, un mundo
dominado por los tecnócratas?. Durante la historia de la humanidad, el más mínimo avance en
la disciplina de gobierno, ha implicado incuantificable sacrificio. ¿Cómo podemos borrar
todo eso? No puede ser.

Algún día llegaremos a Venus, pero no será hoy y, tampoco sin que lo sepa el gobierno.
