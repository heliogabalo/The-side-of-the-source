17/02/15


Desde hace unos meses, los dispositivos móviles también pueden disfrutar de

los mapas en alta resolucion para estas tres ediciones del juego, GTA. "Vice

City Anniversary Edition",  "San Andreas" y, "Grand Theft Auto trilogy".


Ahora con "Liberty City Stories" y "Vice City Stories, junto a la trilogía original

para PS2 Classics, está disponible la descarga para PSN. Las imágenes de alta

calidad en los mapas, vendrá empaquetada junto al juego original, para que

puedas descargalo e imprimirlo.


 

Download original de los mapas(.jpg):

Liberty City Stories | Vice City Stories




Puedes leer el artículo completo en Inglés aquí:

High res Maps for Liberty City S. &amp; Vice City S.
































