SWTOR - Notas del parche 1.3.1
