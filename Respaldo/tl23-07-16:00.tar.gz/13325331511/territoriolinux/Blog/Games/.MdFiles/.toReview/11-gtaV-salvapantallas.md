colage de imagenes

	[foto]
[foto][foto]
		[foto]
[foto][foto]
	[foto]





El equipo Rockstar nos presenta dos nuevas imagenes, que pasarán a engrosar, la galería de arte.

Uno de los puntos fuertes de Gta, es sin lugar a duda la variada oferta de transporte, a la que nos tienen habituados.

Tampoco será distinto en esta ocasión. Además de la ya mítica "Sanchez" mejorada en detalle, podremos hacer uso de otros muchos vehículos.

No vayas a San Fernando andando, usa el transporte "publico"...





