
| GameName | CompanyName | Pagina | F. lanzamiento | Bandera | email-contact | options | plataforma | featuredIndieGame | week nº |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| The Great Zoo scape 2 | Sibling Rivalry G. | http://www.siblingrivalrygames.com/ | A | G1 | sibrivalrygames@gmail.com | options | iOS and Android | puzzle |12-13 |
| In the valley of gods | Campo Santo | https://inthevalleyofgods.com/ | nbd | ? | support@camposanto.com | options | tbc | action/adventure | T6 |
| Way To The Woods | Anthony Tan | http://www.waytothewoodsgame.com/ | 2019 | T6 | email-contact | options | ps4,x1,pc | action/adventure | 15 |

| Planet Alpha | Team 17 | https://www.planetalpha-game.com/ | 2018 | ? | email-contact | options | ps4-xb1-pc-switch | platform/Action | ? |
| FAR: Lone Sails | Okomotive | http://www.far-game.com/ | 17/05/18 | ? | mail@mixtvision-digital.de | options | PS4,Xbox One | postApocalíptico | ? |
| Abandon Ship | FireBlade Soft. | http://abandonshipgame.com/ | 18/19 | ? | press@firebladesoftware.com | pre | PC | aventura | ? |


---

| Leyenda |
|:--|
| *  -- Ineteresante |
| ** -- Muy interesante |
| G -- Index |
| T -- topTen |
| c -- Tema central G. |
| B -- BackGroudImg LastWeek |
| pre -- ErlAcc/dlc |
|tba -- to be announced|
|tbc -- to be confirmed|
|tbd -- to be determined|
| A -- Available|


<ul id="firma">
	<li><b>Traductor:</b> Heliogabalo S.J.</li>
	<li><em>www.territoriolinux.net</em></li>
</ul>
